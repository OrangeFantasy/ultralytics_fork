#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Get config dict for quantization from .cfg file.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import OrderedDict
from google.protobuf import text_format  # pylint: disable=E0401
from hotwheels.amct_pytorch.common.utils.util import find_repeated_items
from hotwheels.amct_pytorch.parser.om_config_parser import OmConfigParser
from hotwheels.amct_pytorch.proto import retrain_config_pb2  # pylint: disable=relative-beyond-top-level
from hotwheels.amct_pytorch.utils.log import LOGGER  # pylint: disable=relative-beyond-top-level
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_TYPES

DT_INT4 = 'INT4'
DT_INT8 = 'INT8'
DT_UNKNOWN = 'UNKNOWN'


class RetrainProtoConfig():
    """
    Function: Cope with simple config file from proto.
    APIs: get_skip_layers,
          get_override_layers,
          read_override_config,
          read_conv_calibration_config,
          read_fc_calibration_config
    """

    def __init__(self, config_file, capacity=None):
        self.config_file = config_file
        self.proto_config = self._read()
        self.override_config_proto = {}
        self.override_type_proto = {}
        self.capacity = capacity
        if self.capacity is not None:
            self.quantizable_type = QUANTIZABLE_TYPES
          
    @staticmethod
    def _parse_data_type(data_type_proto):
        if data_type_proto == 0:
            return DT_INT4
        if data_type_proto == 1:
            return DT_INT8
        return DT_UNKNOWN

    @classmethod
    def _get_ulq_retrain_data_config(cls, config_item):
        retrain_data_params = OrderedDict()
        retrain_data_params['algo'] = 'ulq_retrain'
        retrain_data_config = config_item.ulq_retrain
        retrain_data_params['num_bits'] = retrain_data_config.num_bits
        if retrain_data_config.HasField('clip_max_min'):
            clip_max = retrain_data_config.clip_max_min.clip_max
            clip_min = retrain_data_config.clip_max_min.clip_min
            retrain_data_params['clip_max'] = clip_max
            retrain_data_params['clip_min'] = clip_min
        if retrain_data_config.HasField('fixed_min'):
            retrain_data_params['fixed_min'] = \
                retrain_data_config.fixed_min
        return retrain_data_params
    
    @classmethod
    def _get_luq_retrain_data_config(cls, config_item):
        retrain_data_params = OrderedDict()
        retrain_data_params['algo'] = 'luq_retrain'
        retrain_data_config = config_item.luq_retrain
        retrain_data_params['num_bits'] = retrain_data_config.num_bits
        return retrain_data_params

    @classmethod
    def _get_fixed_quant_param_retrain_data_config(cls, config_item):
        retrain_data_params = OrderedDict()
        retrain_data_params['algo'] = 'fixed_quant_param_retrain'
        retrain_data_config = config_item.fixed_quant_param_retrain
        retrain_data_params['num_bits'] = retrain_data_config.num_bits
        retrain_data_params['scale_d'] = retrain_data_config.scale_d
        retrain_data_params['offset_d'] = retrain_data_config.offset_d
        return retrain_data_params

    @classmethod
    def _get_arq_retrain_weight_config(cls, config_item):
        retrain_weight_params = OrderedDict()
        retrain_weight_params['algo'] = 'arq_retrain'
        retrain_weight_config = config_item.arq_retrain
        retrain_weight_params['num_bits'] = retrain_weight_config.num_bits
        if retrain_weight_config.HasField('channel_wise'):
            retrain_weight_params[
                'channel_wise'] = retrain_weight_config.channel_wise
        return retrain_weight_params

    @classmethod
    def _get_ulq_retrain_weight_config(cls, config_item):
        retrain_weight_params = OrderedDict()
        retrain_weight_params['algo'] = 'ulq_retrain'
        retrain_weight_config = config_item.ulq_retrain
        retrain_weight_params['num_bits'] = retrain_weight_config.num_bits
        if retrain_weight_config.HasField('channel_wise'):
            retrain_weight_params[
                'channel_wise'] = retrain_weight_config.channel_wise
        return retrain_weight_params

    @classmethod
    def _get_luq_retrain_weight_config(cls, config_item):
        retrain_weight_params = OrderedDict()
        retrain_weight_params['algo'] = 'luq_retrain'
        retrain_weight_config = config_item.luq_retrain
        if retrain_weight_config.HasField('num_bits'):
            retrain_weight_params['num_bits'] = \
                retrain_weight_config.num_bits
        return retrain_weight_params

    @classmethod
    def _get_lnq_retrain_weight_config(cls, config_item):
        retrain_weight_params = OrderedDict()
        retrain_weight_params['algo'] = 'lnq_retrain'
        retrain_weight_config = config_item.lnq_retrain
        if retrain_weight_config.HasField('channel_wise'):
            retrain_weight_params[
                'channel_wise'] = retrain_weight_config.channel_wise
        if retrain_weight_config.HasField('num_bits'):
            retrain_weight_params['num_bits'] = \
                retrain_weight_config.num_bits
        if retrain_weight_config.HasField('clip_max'):
            retrain_weight_params['clip_max'] = \
                retrain_weight_config.clip_max
        if retrain_weight_config.HasField('cluster_freq'):
            retrain_weight_params['cluster_freq'] = \
                retrain_weight_config.cluster_freq
        if retrain_weight_config.HasField('max_iteration'):
            retrain_weight_params['max_iteration'] = \
                retrain_weight_config.max_iteration
        if retrain_weight_config.HasField('min_distance'):
            retrain_weight_params['min_distance'] = \
                retrain_weight_config.min_distance
        return retrain_weight_params

    def get_proto_config(self):
        """parse proto config"""
        global_config = OrderedDict()
        if hasattr(self.proto_config, 'batch_num'):
            global_config['batch_num'] = self._get_batch_num()
        return global_config

    def get_retrain_data_quant_config(self):
        """ Get default data quant params """
        data_quant_config = self.proto_config.retrain_data_quant_config
        return self._get_retrain_data_config(data_quant_config)

    def get_retrain_weights_config(self):
        """get weights config"""
        retrain_weight_config = self.proto_config.retrain_weight_quant_config
        return self._get_retrain_weight_config(retrain_weight_config)

    def get_skip_layers(self):
        """ Get the list of skip_layers. """
        skip_layers = list(self.proto_config.skip_layers)
        repeated_layers = find_repeated_items(skip_layers)
        if repeated_layers:
            LOGGER.logw("Please delete repeated items in skip_layers, "
                        "repeated items are %s " % repeated_layers,
                        module_name="Configuration")
        skip_layers = list(set(skip_layers))
        return skip_layers

    def get_skip_layer_types(self):
        """ Get the list of skip_layers. """
        skip_layer_types = list(self.proto_config.skip_layer_types)
        repeated_types = find_repeated_items(skip_layer_types)
        if repeated_types:
            LOGGER.logw("Please delete repeated items in skip_layer_types, "
                        "repeated items are %s " % (repeated_types),
                        module_name="Configuration")
        skip_layer_types = list(set(skip_layer_types))

        # handle mindspore if RETRAIN_MAP_TYPES exists
        if self.capacity.get_value('RETRAIN_MAP_TYPES') is None:
            return skip_layer_types
        return self._transform_layer_types(skip_layer_types)
    
    def get_om_config(self):
        if self.proto_config.HasField('om_config'):
            om_config = self.proto_config.om_config
            om_config_file = om_config.mapping_file
            return OmConfigParser.parse_activation_quant_config(om_config_file)
        return OrderedDict()

    def get_override_layers(self):
        """ Get the list of override_layers. """
        # get retrain_override_layers
        retrain_override_layers = [
            config.layer_name
            for config in self.proto_config.override_layer_configs
        ]
        # check repated items in retrain_override_layers
        repeated = find_repeated_items(retrain_override_layers)
        if repeated:
            raise ValueError(
                "Please delete repeated items in retrain_override_layers, "
                "repeated items are %s " % (repeated))
        for config in self.proto_config.override_layer_configs:
            self.override_config_proto[config.layer_name] = config
        return retrain_override_layers

    def read_override_config(self, override_layer):
        """ Read the config of one override_layer. """
        layer = self.override_config_proto[override_layer]
        retrain_data_params = self._get_retrain_data_config(
            layer.retrain_data_quant_config)
        retrain_weight_params = self._get_retrain_weight_config(
            layer.retrain_weight_quant_config)

        return retrain_data_params, retrain_weight_params

    def get_override_layer_types(self):
        """ Get the list of override_layer_types. """
        # get override_layer_types
        override_layer_types = [
            override_layer_type.layer_type
            for override_layer_type in self.proto_config.override_layer_types
        ]
        # check repated items in override_layer_types
        repeated_types = find_repeated_items(override_layer_types)
        if repeated_types:
            raise ValueError(
                "Please delete repeated items in override_layer_types,  "
                "repeated items are %s " % repeated_types)

        # handle mindspore if RETRAIN_MAP_TYPES exists
        if self.capacity.get_value('RETRAIN_MAP_TYPES') is None:
            # match name and config
            for override_layer_type in self.proto_config.override_layer_types:
                self.override_type_proto[override_layer_type.layer_type] = \
                    override_layer_type
            return override_layer_types
        override_types = []
        for override_layer_type in self.proto_config.override_layer_types:
            layer_type = override_layer_type.layer_type
            layer_type_list = self._transform_layer_types(layer_type)
            for layer_type in layer_type_list:
                if layer_type not in self.quantizable_type:
                    raise ValueError("Layer type {} does not support "
                                     "quantize.".format(layer_type))
                self.override_type_proto[layer_type] = \
                    override_layer_type
                override_types.append(layer_type)

        return override_types

    def read_override_type_config(self, override_layer_type):
        """ Read the config of one override_layer. """
        layer_type = self.override_type_proto[override_layer_type]
        retrain_data_params = self._get_retrain_data_config(
            layer_type.retrain_data_quant_config)
        retrain_weight_params = self._get_retrain_weight_config(
            layer_type.retrain_weight_quant_config)

        return retrain_data_params, retrain_weight_params

    def _read(self):
        """ Read config from config_file. """
        proto_config = retrain_config_pb2.AMCTRetrainConfig()
        with open(self.config_file, 'rb') as cfg_file:
            pbtxt_string = cfg_file.read()
            text_format.Merge(pbtxt_string, proto_config)

        return proto_config

    def _get_retrain_data_config(self, config_item):
        if hasattr(config_item, 'ulq_retrain') and config_item.HasField(
                'ulq_retrain'):
            return self._get_ulq_retrain_data_config(config_item)
        elif hasattr(config_item, 'luq_retrain') and \
                config_item.HasField('luq_retrain'):
            return self._get_luq_retrain_data_config(config_item)
        elif hasattr(config_item, 'fixed_quant_param_retrain') and \
                config_item.HasField('fixed_quant_param_retrain'):
            return self._get_fixed_quant_param_retrain_data_config(config_item)
        else:
            return OrderedDict()

    def _get_retrain_weight_config(self, config_item):
        if config_item.HasField('arq_retrain') and \
                config_item.HasField('arq_retrain'):
            return self._get_arq_retrain_weight_config(config_item)
        elif hasattr(config_item, 'ulq_retrain') and \
                config_item.HasField('ulq_retrain'):
            return self._get_ulq_retrain_weight_config(config_item)
        elif hasattr(config_item, 'luq_retrain') and \
                config_item.HasField('luq_retrain'):
            return self._get_luq_retrain_weight_config(config_item)
        elif hasattr(config_item, 'lnq_retrain') and \
                config_item.HasField('lnq_retrain'):
            return self._get_lnq_retrain_weight_config(config_item)
        else:
            return OrderedDict()

    def _get_batch_num(self):
        if self.proto_config.HasField('batch_num'):
            return self.proto_config.batch_num
        return None

    def _get_mapped_type(self, layer_type, map_types):
        if layer_type not in map_types:
            raise ValueError(
                'Unrecognized layer type:{}, only support {}'.format(
                    layer_type, map_types))
        return self.quantizable_type[map_types.index(layer_type)]

    def _transform_layer_types(self, layer_types):
        map_types = self.capacity.get_value('RETRAIN_MAP_TYPES')
        if map_types is None:
            return layer_types

        ret = []
        if not isinstance(layer_types, list):
            if layer_types == 'nn.Conv2D':
                return ['Conv2D', 'DepthwiseConv2dNative']
            ret.append(self._get_mapped_type(layer_types, map_types))
            return ret

        for item in layer_types:
            if item == 'nn.Conv2D':
                ret += ['Conv2D', 'DepthwiseConv2dNative']
            else:
                ret.append(self._get_mapped_type(item, map_types))
        return ret

