# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Common data definition module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import torch
from hotwheels.amct_pytorch.capacity import CAPACITY
import torch.nn.functional as F
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_TYPES
CUR_DIR = os.path.split(os.path.realpath(__file__))[0]

CHANNEL_WISE_TYPES = CAPACITY.get_value('CHANNEL_WISE_TYPES')
CHANNEL_WISE_ONNX_TYPES = CAPACITY.get_value('CHANNEL_ONNX_WISE_TYPES')
FUSE_ONNX_TYPES = CAPACITY.get_value('FUSE_ONNX_TYPES')

AMCT_OPERATIONS = ('IFMR', 'AscendQuant', 'AscendDeQuant', 'QuantIdentity',
    'LSTMMarkedQuantizableModule', 'MarkedQuantizableModule')
AMCT_RETRAIN_OPERATIONS = ('CompModuleConv2d', 'CompModuleConvTranspose2d',
    'CompModuleLinear', 'CompModuleWithoutWeight')

MULTI_INPUT_ONNX_TYPES = ('Add', 'Mul', 'Div', 'Concat', 'LSTM', 'GRU', 'RNN', 'MatMul', 'Sub')
MULTI_INPUT_TYPES = ('LSTM', 'GRU', 'RNN', 'MatMul')
RNN_ONNX_TYPES = ('LSTM', 'GRU', 'RNN',)
RNN_TYPES = ('LSTM', 'GRU', 'RNN',)

NON_INSIST_ONNX_TYPES = ('Concat', 'Split', 'Reshape', 'Flatten', 'Slice', 'Transpose', 'Tile', 'Squeeze')

NODE_WITH_OPTIMIZE_INPUT = ('Reshape', 'Resize', 'Flatten', 'Gather', 'Slice')

RETRAIN_MODULE_TYPES = ('CompModuleConv2d', 'CompModuleConvTranspose2d',
    'CompModuleLinear')
NO_WEIGHT_RETRAIN_MODULE_TYPES = ('CompModuleWithoutWeight',)
TO_FUSE_ONNX_TYPES = ('BatchNormalization',)
CONV_BN_FUSION_TYPES = ('Conv',)
TO_FUSE_TYPES = ('BatchNorm2d',)
CONV_BN_TYPES = ('Conv2d',)

CUBE_OPERATIONS = ('Conv', 'Gemm', 'ConvTranspose', 'MaxPool', 'AveragePool',
                    'GlobalMaxPool', 'GlobalAveragePool')

DEFAULT_DATA_RETRAIN_ALGO = 'luq_retrain'
DEFAULT_WEIGHT_RETRAIN_ALGO = 'arq_retrain'
DEFAULT_UNQUANTIZE_ONNX_TYPES = CAPACITY.get_value('DEFAULT_UNQUANTIZE_ONNX_TYPES')
CALI_QUANT_MODULE_TYPES = ('CaliQuantBase', 'CaliQuantConcat',
    'CaliQuantLSTM', 'CaliQuantMultiInput')
AICPU_LAYER = ('Pad', )
ARQ_WEIGHT_BIT_NUM = 8
SNQ_WEIGHT_BIT_NUM = 4
WEIGHT_NUM_BIT_SET = (SNQ_WEIGHT_BIT_NUM, ARQ_WEIGHT_BIT_NUM)
DATA_BIT_NUM_RANGE = [8, 16]
BN_MOMENTUM_RANGE = [0, 1]
DATA_DEFAULT_BIT_NUM = 12
CLIBRATION_BIT = 8
QUANT_BIAS_BITS = 32
ZERO = 0.0
ONE = 1.0
BASE = 2
EPSILON = 1E-6
FLT_EPSILON = 1.19209290 * 1e-7
SCALE_W_EPSILON = FLT_EPSILON * 10
CLIP_MAX = 3.0
CLUSTER_FREQ = 400
MIN_ALPHA = 0.00038928920371275036

QUANT_LAYER_SUFFIX = ('.quant', '.dequant', '.anti_quant')

ACTIVATION_QUANT_PARAMS = 'activation_quant_params'
WEIGHT_QUANT_PARAMS = 'weight_quant_params'
RETRAIN_WEIGHT_CONFIG = 'retrain_weight_config'
RETRAIN_DATA_CONFIG = 'retrain_data_config'
QUANT_ENABLE = 'quant_enable'
RETRAIN_ENABLE = 'retrain_enable'
OFFLINE_OPTIMIZE_LAYER_TYPES = ('Constant', 'ConstantOfShape',
    'Identity', 'Shape', 'initializer')
ONNX_SPLIT_OP_TYPE = (torch.nn.SiLU,)
SKIP_QUANT_INDEX = "SKIP_QUANT_INDEX"
X_WEIGHT = 'weight_ih_l0'
X_BIAS = 'bias_ih_l0'
H_WEIGHT = 'weight_hh_l0'
H_BIAS = 'bias_hh_l0'
X_WEIGHT_REVERSE = 'weight_ih_l0_reverse'
X_BIAS_REVERSE = 'bias_ih_l0_reverse'
H_WEIGHT_REVERSE = 'weight_hh_l0_reverse'
H_BIAS_REVERSE = 'bias_hh_l0_reverse'
NON_REPLACEABLE_TYPES = (F.batch_norm, F.conv2d, F.conv_transpose2d)
OP_SET_VERSION = 13


_TMP_REGISTER_QUANT_TYPES = []


def register_no_weight_quant_type(type_name):
    _TMP_REGISTER_QUANT_TYPES.append(type_name)


def get_no_weight_quant_type():
    return (_TMP_REGISTER_QUANT_TYPES + NO_WEIGHT_QUANT_TYPES)


def clear_tmp_register_quant_type():
    _TMP_REGISTER_QUANT_TYPES = []


def find_torch_version():
    """ find torch's valid version """
    version = torch.__version__
    for support_version in SUPPORT_TORCH_VERSIONS:
        if version.startswith(support_version):
            return support_version
    raise RuntimeError("amct_pytorch cannot support torch %s" % (version))


SUPPORT_TORCH_VERSIONS = ['1.8.1']
TORCH_VERSION = find_torch_version()
