#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fakequant weight from int8 to int9.

"""
import numpy as np

from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import RETRAIN_WEIGHT_CONFIG
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.custom_op.lnq_retrain.lnq_retrain import lnq_cali_fake_quant

from hotwheels.amct_pytorch.configuration.check import GraphChecker


class WeightFakequantPass(BaseFusionPass):
    """
    Function: Fakequant weight from int8 to int9
    APIs: match_pattern, do_pass
    """

    def __init__(self, records, is_retrain):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        if is_retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()
        self.records = records
        self.is_retrain = is_retrain

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if not GraphChecker.check_onnx_quantize_type(node):
            return False

        if node.type in RNN_ONNX_TYPES:
            return False

        if node.name not in self.records:
            return False

        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual quantization and node's weight is changed to int9.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        weight_param = QuantOpInfo.get_weight_node(object_node)
        weight_helper = TensorProtoHelper(weight_param.proto)
        # get data
        int8_weight = weight_helper.get_data()
        weight_helper.clear_data()

        layer_config = self.conf.get_layer_config(object_node.name)
        if self.is_retrain:
            wts_param = layer_config.get(RETRAIN_WEIGHT_CONFIG)
            wts_algo = wts_param['algo']
        else:
            wts_param = layer_config.get(WEIGHT_QUANT_PARAMS)
            wts_algo = wts_param['wts_algo']
        if wts_algo == 'lnq_retrain' or wts_algo == 'snq_quantize':
            int8_weight = lnq_cali_fake_quant(int8_weight, 
                self.records.get(object_node.name).get('params'))
            int8_weight = int8_weight.cpu().numpy()
        weight_offset = self.records.get(object_node.name).get('weight_offset')
        int8_weight = int8_weight.reshape([-1])

        weight_helper.set_data(int8_weight, 'FLOAT')

        LOGGER.logd("Fakequant weight from int8 to int9 for layer '{}' "
                    "success!".format(object_node.name), 'WeightFakequantPass')
