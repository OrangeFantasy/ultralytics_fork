#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

rnn utils

"""
from hotwheels.amct_pytorch.proto import quant_param_record_pb2
from hotwheels.amct_pytorch.common.utils.util import get_data_cal_type
from hotwheels.amct_pytorch.common.utils.util import get_weights_cal_type
from hotwheels.amct_pytorch.custom_op.utils import get_offline_optimize_index
import torch


class BaseRnnHelper():
    _ori_type = ''
    _input_num = 0

    def __init__(self, node):
        if node.type not in self.supported_types():
            raise RuntimeError('Unspported layer'
                               ' type {}'.format(node.type))

        self._name = node.name
        self._input_x_idx = 0
        self._input_h_idx = 1
        self._input_c_idx = 2
        self._node = node

        self._weights_count = 0
        self._scale_shape = []
        self._scale_length = 0

        self._x_fc_list = []
        self._h_fc_list = []
        self._s_fc_list = []
        self._x_fc_index_list = []
        self._h_fc_index_list = []

        self.bidirectional = 'direction' in [i.name for i in node.proto.attribute]

    @classmethod
    def ori_type(cls):
        return cls._ori_type

    @classmethod
    def supported_types(cls):
        return [cls.ori_type()]

    @staticmethod
    def _fill_rnn_input_param(record, idx, layer_param):
        """
        Function: Fill input param to rnn layer
        Parameters:
            record: record in record file
            idx: the index of input
            layer_param: layer_param added for quant param record file
        Return: None
        """
        input_param = layer_param.quant_param.input[idx]
        input_param.ClearField('scale')
        input_param.ClearField('offset')
        record_d = record.value.record_d[idx]
        input_param.data_type = \
            get_data_cal_type(record_d.num_bits_d)
        input_param.scale.append(record_d.scale_d)
        input_param.offset.append(record_d.offset_d)

    def weights_count(self):
        return self._weights_count

    def scale_shape(self):
        return self._scale_shape

    def scale_length(self):
        return self._scale_length

    def input_num(self):
        return self._input_num

    def adjust_weight_order(self, weight):
        """
        Function: adjust rnn weight shape
        Inputs: weight: original weight in pytorch model
        Returns: None
        """
        return weight

    def refresh_param_for_input_nodes(self, quant_param_records):
        """
        Function: refresh input layer param
        Parameters:
            quant_param_records: quant param record file
        Return: None
        """
        for layer_param in quant_param_records.layer:
            if layer_param.name != self._name:
                continue
            for idx in range(len(self._node.input_anchors)):
                if self._node.get_input_anchor(idx). \
                        get_peer_output_anchor() is None:
                    continue
                input_node = self._node.get_input_anchor(idx). \
                    get_peer_output_anchor().node
                if input_node.type != 'graph_anchor' and input_node.type != 'ConstantOfShape':
                    continue
                if idx > 0:
                    idx = idx - get_offline_optimize_index(self._node)
                input_param = layer_param.quant_param.input[idx]
                for layer in quant_param_records.layer:
                    if layer.name != input_node.name:
                        continue
                    layer.quant_param.input[0].CopyFrom(input_param)

    def generate_quant_params(self, quant_param, layer_param, item):
        """
        Function: generate quant params for rnn layer
        from original format:
        record {
            key: "lstm"
                value {
                    record_d {
                        scale_d: 
                        offset_d: 
                        index:
                        num_bits_d: 
                    }
                    record_d {
                        scale_d:
                        offset_d:
                        index:
                        num_bits_d:
                    }
                    scale_w:
                    ...
                    offset_w:
                    ...(8 scale_ws/offset_ws for lstm, 6 for GRU, 2 for RNN )
                    num_bits_w:
                    }
                }
        to: 
        layer {
            name: "lstm"
            quant_param {(3 inputs for lstm/gru, 2 inputs for rnn)
                input {
                    data_type: S8
                    scale:
                    offset:
                }
                input {
                    data_type: F16
                    scale:
                    offset:
                }
                input {
                    data_type: F16
                    scale:
                    offset:
                }
            }
            sub_layer {
                layer {(4 x_fcs for lstm, 3 for gru, 1 for rnn)
                    name: "fc_lstm_ix"
                    quant_param {
                        input {
                            data_type: S8
                            scale:
                            offset:
                        }
                        weight {
                            data_type: S8
                            scale:
                        }
                    }
                }
                layer {
                    name: "fc_lstm_ox"
                    ...
                }
                layer {
                    name: "fc_lstm_fx"
                    ...
                }
                layer {
                    name: "fc_lstm_cx"
                    ...
                }
                layer { (4 i_fcs for lstm, 3 for gru, 1 for rnn)
                    name: "fc_lstm_ih"
                    calc_data_type: S8
                    quant_param {
                        input {
                            data_type: F16
                            scale:
                            offset:
                        }
                        weight {
                            data_type:S8
                            scale:
                        }
                    }
                }
                layer {
                    name: "fc_lstm_oh"
                    ...
                }
                layer {
                    name: "fc_lstm_fh"
                    ...
                }
                layer {
                    name: "fc_lstm_ch"
                    ...
                }
            }
        }
        Inputs: quant_param: The quant_param added for current layer
                item: record in original record file
        Returns: None
        """
        for index in range(len(item.value.record_d)):
            for record_d in item.value.record_d:
                if record_d.index != index:
                    continue
                input_param = quant_param.input.add()
                input_param.data_type = get_data_cal_type(
                    record_d.num_bits_d)
                input_param.scale.append(1 / record_d.scale_d)
                input_param.offset.append(record_d.offset_d)
        self._fill_rnn_x_fc_param(item, layer_param)
        self._fill_rnn_input_param(item, self._input_x_idx, layer_param)
        self._fill_rnn_h_fc_param(item, layer_param, quant_param_record_pb2.F16)
        self._fill_rnn_input_param(item, self._input_h_idx, layer_param)
        layer_param.quant_param.input[self._input_h_idx].data_type = \
            quant_param_record_pb2.F16

    def _fill_rnn_x_fc_param(self, record, layer_param):
        """
        Function: Fill x_fc param to rnn layer
        Parameters:
            record: record from record file
            layer_param: layer_param added for quant param record file
        Return: None
        """
        for idx, name in enumerate(self._x_fc_list):
            sub_layer_param = layer_param.sub_layer.layer.add()
            sub_layer_param.name = name
            quant_param = sub_layer_param.quant_param
            input_param = quant_param.input.add()
            record_d = record.value.record_d[self._input_x_idx]
            input_param.data_type = get_data_cal_type(record_d.num_bits_d)
            input_param.scale.append(record_d.scale_d)
            input_param.offset.append(record_d.offset_d)

            weight_param = quant_param.weight
            weight_param.data_type = get_weights_cal_type(record.value.num_bits_w)
            if record.value.params:
                weight_param.params = record.value.params
            weight_param.scale.append(record.value.scale_w[self._x_fc_index_list[idx]])

    def _fill_rnn_h_fc_param(self, record, layer_param, fixed_data_type):
        """
        Function: Fill h_fc param to rnn layer
        Parameters:
            record: record from record file
            layer_param: layer_param added for quant param record file
            fixed_data_type: set a fixed data type for c of lstm input
        Return: None
        """
        for idx, name in enumerate(self._h_fc_list):
            sub_layer_param = layer_param.sub_layer.layer.add()
            sub_layer_param.name = name
            quant_param = sub_layer_param.quant_param
            input_param = quant_param.input.add()
            record_d = record.value.record_d[self._input_h_idx]
            input_param.data_type = fixed_data_type
            sub_layer_param.calc_data_type = get_data_cal_type(record_d.num_bits_d)
            input_param.scale.append(record_d.scale_d)
            input_param.offset.append(record_d.offset_d)

            weight_param = quant_param.weight
            weight_param.data_type = get_weights_cal_type(record.value.num_bits_w)
            if record.value.params:
                weight_param.params = record.value.params
            weight_param.scale.append(record.value.scale_w[self._h_fc_index_list[idx]])


class RnnHelper(BaseRnnHelper):
    _ori_type = 'RNN'
    _input_num = 2

    def __init__(self, node):
        super(RnnHelper, self).__init__(node)
        self._weights_count = 1
        self._x_fc_list = ['fc_rnn_x']
        self._h_fc_list = ['fc_rnn_h']
        self._x_fc_index_list = (0,)
        self._h_fc_index_list = (1,)
        self._scale_shape = [2, 1, 1, 1]
        self._scale_length = 2
        if self.bidirectional:
            self._weights_count = 2
            self._x_fc_list = ('fc_rnn_x', 'fc_rnn_x_reverse')
            self._h_fc_list = ('fc_rnn_h', 'fc_rnn_h_reverse')
            self._x_fc_index_list = (0, 1)
            self._h_fc_index_list = (2, 3)
            self._scale_shape = [4, 1, 1, 1]
            self._scale_length = 4


class LstmHelper(BaseRnnHelper):
    _ori_type = 'LSTM'
    _input_num = 3

    def __init__(self, node):
        super(LstmHelper, self).__init__(node)

        self._weights_count = 4
        self._x_fc_list = ['fc_lstm_ix', 'fc_lstm_ox', 'fc_lstm_fx', 'fc_lstm_cx']
        self._h_fc_list = ['fc_lstm_ih', 'fc_lstm_oh', 'fc_lstm_fh', 'fc_lstm_ch']
        self._x_fc_index_list = list(range(self._weights_count))
        self._h_fc_index_list = list(range(self._weights_count,
                                           self._weights_count * 2))
        self._scale_shape = [self._weights_count * 2, 1, 1, 1]
        self._scale_length = self._weights_count * 2
        if self.bidirectional:
            self._x_fc_list.extend(
                ['fc_lstm_ix_reverse', 'fc_lstm_ox_reverse',
                 'fc_lstm_fx_reverse', 'fc_lstm_cx_reverse'])
            self._h_fc_list.extend([
                'fc_lstm_ih_reverse', 'fc_lstm_oh_reverse',
                'fc_lstm_fh_reverse', 'fc_lstm_ch_reverse'])
            self._x_fc_index_list = list(range(self._weights_count * 2))
            self._h_fc_index_list = list(range(self._weights_count * 2,
                                               self._weights_count * 4))
            self._scale_shape = [self._weights_count * 4, 1, 1, 1]
            self._scale_length = self._weights_count * 4
            self._weights_count *= 2

    def adjust_weight_order(self, weight):
        """
        Function: adjust lstm weight shape
        in pytorch, fc is in [ingate, forgetgate, cellgate, outgate] order
        in onnx, fc is in [ingate, outgate, forgetgate, cellgate]
        as the scale_w is calculated in pytorch, and used in onnx, the order 
        should be adjusted
        Inputs: weight: original weight in pytorch model
        Returns: None
        """
        weight_device = weight.device
        if len(weight) != self._weights_count and not self.bidirectional:
            raise RuntimeError('Each fc in {} should have {} scales, '
                'current number of scales is {}!'.format(
                    self._ori_type, self._weights_count, len(weight)))
        elif self.bidirectional and len(weight) != self._weights_count // 2:
            raise RuntimeError('Each fc in bidirectional {} should have {} scales, '
                               'current number of scales is {}!'.format(
                self._ori_type, self._weights_count // 2, len(weight)))
        weight = weight.cpu().numpy()
        combined_weight = [weight[0], weight[3], weight[1], weight[2]]
        return torch.tensor(combined_weight).to(weight_device)


class GruHelper(BaseRnnHelper):
    _ori_type = 'GRU'
    _input_num = 2

    def __init__(self, node):
        super(GruHelper, self).__init__(node)

        self._weights_count = 3
        self._x_fc_list = ['fc_gru_zx', 'fc_gru_rx', 'fc_gru_hx']
        self._h_fc_list = ['fc_gru_zh', 'fc_gru_rh', 'fc_gru_hh']
        self._x_fc_index_list = list(range(self._weights_count))
        self._h_fc_index_list = list(range(self._weights_count,
                                           self._weights_count * 2))
        self._scale_shape = [self._weights_count * 2, 1, 1, 1]
        self._scale_length = self._weights_count * 2
        if self.bidirectional:
            # lstm bid model
            self._x_fc_list.extend(
                ['fc_gru_zx_reverse', 'fc_gru_rx_reverse', 'fc_gru_hx_reverse'])
            self._h_fc_list.extend(
                ['fc_gru_zh_reverse', 'fc_gru_rh_reverse', 'fc_gru_hh_reverse']
            )
            self._x_fc_index_list = list(range(self._weights_count * 2))
            self._h_fc_index_list = list(range(self._weights_count * 2,
                                               self._weights_count * 4))
            self._scale_shape = [self._weights_count * 4, 1, 1, 1]
            self._scale_length = self._weights_count * 4
            self._weights_count *= 2

    def adjust_weight_order(self, weight):
        """
        Function: adjust gru weight shape
        in pytorch, fc is in [reset_gate, input_gate, new_gate] order
        in onnx, fc is in [input_gate, reset_gate, new_gate]
        as the scale_w is calculated in pytorch, and used in onnx, the order 
        should be adjusted
        Inputs: weight: original weight in pytorch model
        Returns: None
        """
        weight_device = weight.device
        if len(weight) != self._weights_count and not self.bidirectional:
            raise RuntimeError('Each fc in {} should have {} scales, '
                'current number of scales is {}!'.format(
                    self._ori_type, self._weights_count, len(weight)))
        elif self.bidirectional and len(weight) != self._weights_count // 2:
            raise RuntimeError('Each fc in bidirectional {} should have {} scales, '
                               'current number of scales is {}!'.format(
                self._ori_type, self._weights_count // 2, len(weight)))
        weight = weight.cpu().numpy()
        combined_weight = [weight[1], weight[0], weight[2]]
        return torch.tensor(combined_weight).to(weight_device)


RNN_UTIL_SET = [RnnHelper, GruHelper, LstmHelper]


def get_rnn_helper(node):
    for util in RNN_UTIL_SET:
        if node.type in util.supported_types():
            return util(node)
    raise RuntimeError('Unspported RNN layer'
        ' type {}'.format(node.type))
