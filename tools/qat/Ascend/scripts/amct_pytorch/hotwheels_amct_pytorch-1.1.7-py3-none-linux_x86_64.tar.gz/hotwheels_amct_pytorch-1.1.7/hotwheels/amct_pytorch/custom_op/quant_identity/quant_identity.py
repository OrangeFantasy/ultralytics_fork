#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

custom op "quant_identiy" register

"""

import torch
from torch.autograd import Function


class QuantIdentity(Function):  # pylint: disable=W0223
    """Function to export onnx op with quantizable op name"""

    @staticmethod
    def forward(ctx, in_data, op_name):
        """QuantIdentity forward method"""
        return in_data.clone()

    @staticmethod
    def symbolic(g, *inputs):  # pylint: disable=C0103
        """QuantIdentity symbolic method"""
        return g.op("reg::QuantIdentity", inputs[0], op_name_s=inputs[1])


class MarkedQuantizableModule(torch.nn.Module):
    """Custom Module to mark quantizable op"""

    def __init__(self, sub_module, layer_name):
        """MarkedQuantizableModule init method"""
        super().__init__()
        self.sub_module = sub_module
        self.layer_name = layer_name

    def mult_input_forward(self, *in_data):
        quant_identity = QuantIdentity.apply
        out_data = []
        for index in range(len(in_data)):
            out_data.append(in_data[index])

        for index in range(len(in_data)):
            if type(in_data[index]).__name__ != 'Tensor':
                in_data_item = in_data[index]
            else:
                in_data_item = quant_identity(in_data[index], self.layer_name)
                out_data[index] = in_data_item
                break
        out_data = self.sub_module(*out_data)
        return out_data

    def forward(self, *in_data):
        """MarkedQuantizableModule forward method
        """
        quant_identity = QuantIdentity.apply

        if len(in_data) > 1:
            out_data = self.mult_input_forward(*in_data)
        else:
            out_data = quant_identity(in_data[0], self.layer_name)
            out_data = self.sub_module(out_data)
        return out_data


class LSTMMarkedQuantizableModule(MarkedQuantizableModule):
    """Custom Module to mark quantizable op"""

    def __init__(self, sub_module, layer_name):
        """LSTMMarkedQuantizableModule init method"""
        super().__init__(sub_module, layer_name)

    def get_lstm_input_item(self, in_data):
        quant_identity = QuantIdentity.apply
        if type(in_data).__name__ == 'Tensor':
            in_data_item = quant_identity(in_data, self.layer_name)
        elif type(in_data).__name__ == 'tuple':
            if len(in_data) < 2:
                raise RuntimeError("Second input of lstm layer {} should be "
                    "combined with two inputs(h0, c0), current is {}.".format(
                    self.layer_name, len(in_data)))
            in_data_item_h = quant_identity(in_data[0], self.layer_name)
            in_data_item_c = in_data[1]
            in_data_item = (in_data_item_h, in_data_item_c)
        else:
            raise RuntimeError("Input type {} of lstm layer {} is not "
                "supported! Only support tensor of tuple!".format(
                    type(in_data).__name__, self.layer_name))
        return in_data_item

    def mult_input_forward(self, *in_data):
        out_data = []
        for in_data_item in in_data:
            in_data_item = self.get_lstm_input_item(in_data_item)
            out_data.append(in_data_item)

        out_data = self.sub_module(*out_data)
        return out_data

    def forward(self, *in_data):  # pylint: disable=W0221
        """MarkedQuantizableModule forward method
        For LSTM, one lstm has two inputs, lstm(input, (h, c))
        first input is a tensor, second is a tuple, h is output of last layer, 
        c saves state, no need to quant, thus, quant_identity only applys to 
        input and h
        """
        out_data = self.mult_input_forward(*in_data)

        return out_data
