#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantization module after conv2d encapsulation

"""
import torch # pylint: disable=E0401
import torch.nn.functional as F # pylint: disable=E0401

from hotwheels.amct_pytorch.custom_op.comp_module.comp_module_base \
    import CompModuleBase


class CompModuleConv2d(CompModuleBase): # pylint: disable=R0903
    """
    Function: Quantization module class after conv2d encapsulation.
    APIs: __init__, forward
    """
    def __init__(self, module,
                act_config=None,
                wts_config=None,
                common_config=None,
                skip_quant=False,
                index=0):
        if wts_config['channel_wise']:
            wts_config['num_scale'] = module.weight.size(0) 
        else:
            wts_config['num_scale'] = 1
        super(CompModuleConv2d, self).__init__(module, 
                act_config=act_config,
                wts_config=wts_config,
                common_config=common_config,
                skip_quant=skip_quant,
                index=index)

    def forward(self, inputs):
        """
        Defines the computation performed at every call.
        Should be overridden by all subclasses.
        """
        compressed_inputs, compressed_weights = \
            super(CompModuleConv2d, self).forward(inputs)

        # Circular padding from compressed inputs
        padding = self.replaced_module.padding

        # Forward
        with torch.enable_grad():
            output = F.conv2d(
                compressed_inputs, compressed_weights,
                self.replaced_module.bias, self.replaced_module.stride,
                padding, self.replaced_module.dilation,
                self.replaced_module.groups)

        return output
