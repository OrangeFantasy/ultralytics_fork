# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

field defination in json config.

"""
from decimal import Decimal
from collections import OrderedDict
from interval import Interval

from hotwheels.amct_pytorch.utils.vars import DATA_BIT_NUM_RANGE
from hotwheels.amct_pytorch.utils.vars import ARQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.utils.vars import SNQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.utils.vars import BN_MOMENTUM_RANGE
from hotwheels.amct_pytorch.utils.vars import ACTIVATION_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import FLT_EPSILON
from hotwheels.amct_pytorch.common.utils.util import find_repeated_items
from hotwheels.amct_pytorch.common.utils.util import check_no_repeated
from hotwheels.amct_pytorch.utils.log import LOGGER # pylint: disable=relative-beyond-top-level

# default parameters for quant config
# global parameters
VERSION = 1
BATCH_NUM = 1
WEIGHT_OFFSET = False
ACTIVATION_OFFSET = True
JOINT_QUANT = False
DO_FUSION = True
SKIP_FUSION_LAYERS = list()
UPDATE_BN = False


# layer's activation quant parameters
MAX_PERCENTILE = 0.999999
MIN_PERCENTILE = 0.999999
SEARCH_RANGE_START = 0.7
SEARCH_RANGE_END = 1.3
SEARCH_STEP = 0.01

# layer's weights quant parameters
NUQ_WITH_OFFSET = False
NUM_STEPS = 32
NUM_OF_ITERATION = 1
MAX_ITERATION = 1000
MAX_ITERATION_RANGE = Interval(500, 2000)
MIN_DISTANCE = 1e-10
MIN_DISTANCE_RANGE = Interval(1e-10, 1e-3)
BN_MOMENTUM = 0.1
BN_UPDATE_ITERATIONS_RANGE = Interval(0, 1000)
BN_UPDATE_ITERATIONS = 30
INIT_ALGO = "uniform"
INIT_ALGO_RANGE = ["uniform", "gaussian", "d2sampling"]


def _check_type(name, variable, typeinfo):
    if not isinstance(variable, typeinfo):
        raise TypeError("Type of %s should be %s, but is %s" \
                        % (name, typeinfo, type(variable)))


class ParamPool():
    '''store parameters used by fields'''
    def __init__(self):
        self._quant_layers = None
        self._supported_layers = None
        self._layer_type = None
        self._layer_name = None
        self._wts_algo = None
        self._supported_no_weight_layers = None
        self._supported_multi_input_layers = None
        self._mult_input_layer_input_num_dict = None
        self._update_bn = False

    def set_update_bn(self, update_bn):
        '''set quant layers used by field'''
        self._update_bn = update_bn

    def get_update_bn(self):
        '''get quant layers'''
        return self._update_bn

    def set_quant_layers(self, quant_layers):
        '''set quant layers used by field'''
        self._quant_layers = quant_layers

    def get_quant_layers(self):
        '''get quant layers'''
        return self._quant_layers

    def set_supported_layers(self, supported_layers):
        '''set supported layers used by field'''
        self._supported_layers = supported_layers

    def set_supported_no_weight_layers(self, supported_no_weight_layers):
        '''set supported no weight layers used by field'''
        self._supported_no_weight_layers = supported_no_weight_layers

    def set_supported_multi_input_layers(self, supported_multi_input_layers):
        '''set supported multi input layers used by field'''
        self._supported_multi_input_layers = supported_multi_input_layers

    def get_supported_layers(self):
        '''get supported layers'''
        return self._supported_layers

    def get_supported_no_weight_layers(self):
        '''get supported no weight layers'''
        return self._supported_no_weight_layers

    def get_supported_multi_input_layers(self):
        '''get supported multi input layers'''
        return self._supported_multi_input_layers

    def set_layer_type(self, layer_type):
        '''set layer type used by field'''
        self._layer_type = layer_type

    def get_layer_type(self):
        '''get layer type'''
        return self._layer_type

    def set_layer_name(self, layer_name):
        '''set layer name used by child field'''
        self._layer_name = layer_name

    def get_layer_name(self):
        '''get layer name'''
        return self._layer_name

    def set_wts_algo(self, wts_algo):
        '''set wgt alg used by child field'''
        self._wts_algo = wts_algo

    def get_wts_algo(self):
        '''get wgt alg'''
        return self._wts_algo

    def set_multi_input_layers_input_num_dict(
        self, mult_input_layer_input_num_dict):
        '''set multi input layers input num'''
        self._mult_input_layer_input_num_dict = mult_input_layer_input_num_dict

    def get_multi_input_layers_input_num_dict(self):
        '''get multi input layers input num'''
        return self._mult_input_layer_input_num_dict

    # Attention! All parameters should be cleared here.
    def clear(self):
        '''clear all parameters'''
        self._quant_layers = None
        self._supported_layers = None
        self._layer_type = None
        self._layer_name = None
        self._wts_algo = None
        self._supported_no_weight_layers = None
        self._supported_multi_input_layers = None
        self._mult_input_layer_input_num_dict = None


PARAM_POOL = ParamPool()


class Field():
    '''base class for field'''
    def __init__(self, capacity):
        self.capacity = capacity
        self.parent = None

    def has_default(self): # pylint: disable=no-self-use
        '''indicate whether this field has default value'''
        return True

    def is_leaf(self): # pylint: disable=no-self-use
        '''indicate whether it is a leaf field'''
        raise RuntimeError('Unimplemented function.')

    def check(self, name, value): # pylint: disable=no-self-use
        '''check the value of this field'''
        raise RuntimeError('Unimplemented function.')

    def set_parent(self, parent):
        '''point to parent node of this field'''
        self.parent = parent


class LeafField(Field):
    """leaf node have no child"""
    def is_leaf(self):
        return True

    def default_value(self): # pylint: disable=no-self-use
        '''the default value of this field if it has default value'''
        raise RuntimeError('Unimplemented function.')


class ContainerField(LeafField):
    """container node can have (container/leaf) child node"""
    def __init__(self, capacity):
        super(ContainerField, self).__init__(capacity)
        self.child = OrderedDict()
        self.child_placeholder = []

    @classmethod
    def set_param_pool(cls, config):
        if config.get('update_bn'):
            PARAM_POOL.set_update_bn(True)

    def is_leaf(self):
        return False

    def add_child(self, name, item):
        '''add child node to this container node'''
        self.child[name] = item
        item.set_parent(self)
        return item

    def get_child(self, name):
        '''get a child from all children'''
        return self.child[name]

    def get_keys(self):
        '''get all children names'''
        return list(self.child)

    def add_placeholder(self, item):
        '''add a specifial container node as child'''
        self.child_placeholder.append(item)
        item.set_parent(self)
        return item

    def fill_default(self, config):
        '''fill default value for all children'''
        self.set_param_pool(config)
        for item in self.get_keys():
            child = self.get_child(item)
            if child.is_leaf() and item in config:
                continue
            if not child.has_default():
                continue
            if not child.is_leaf():
                if config.get(item) is None:
                    config[item] = {}
                child.fill_default(config[item])
            else:
                config[item] = child.default_value()
                LOGGER.logd('fill default value {} for field {}'.
                            format(config[item], item))

        for item in self.child_placeholder:
            item.fill_default(config)

    def check_not_found_msg(self, name, item): # pylint: disable=no-self-use
        '''raise an error if this node is not found'''
        raise ValueError(
            "{} is an invalid layer name or parameter.".format(item))

    def check(self, name, value):
        '''recursive check all children'''
        config = value
        for item in config:
            if item in self.get_keys():
                child = self.get_child(item)
                child.check(item, config[item])
                continue

            for plh in self.child_placeholder:
                if plh.match(item):
                    plh.check(item, config[item])
                    break
            else:
                self.check_not_found_msg(name, item)

    def sort(self, config):
        '''sort all child field'''
        ordered_config = OrderedDict()
        for item in self.get_keys():
            if item in config:
                child = self.get_child(item)
                if child.is_leaf():
                    ordered_config[item] = config[item]
                else:
                    if isinstance(config[item], list):
                        if item not in ordered_config.keys():
                            ordered_config[item] = []
                        for single_config in config[item]:
                            ordered_config[item].append(
                                child.sort(single_config))
                    else:
                        ordered_config[item] = child.sort(config[item])

        for plh in self.child_placeholder:
            match_list = []
            for item in config:
                if item in ordered_config:
                    continue
                if plh.match(item):
                    match_list.append(item)

            match_list.sort()
            for item in match_list:
                ordered_config[item] = plh.sort(config[item])

        return ordered_config


class PlaceholderField(ContainerField):
    '''a specifial container node'''
    def match(self, name):
        '''indicate whether input name match this placeholder'''
        raise RuntimeError('Unimplemented function.')


class DataBitNumField(LeafField):
    '''an object for data bit num field'''
    def default_value(self):
        return DATA_BIT_NUM_RANGE[0]

    def check(self, name, value):
        _check_type(name, value, int)
        if value != -1 and (value > DATA_BIT_NUM_RANGE[1] \
                or value < DATA_BIT_NUM_RANGE[0]):
            raise ValueError("The %s must either be -1 or in %s."
                             % (name, DATA_BIT_NUM_RANGE))


class WeightBitNumField(LeafField):
    '''an object for weight bit num field'''

    def has_default(self):
        return True

    def default_value(self):
        if PARAM_POOL.get_wts_algo() == 'snq_quantize':
            return SNQ_WEIGHT_BIT_NUM
        return ARQ_WEIGHT_BIT_NUM

    def check(self, name, value):
        _check_type(name, value, int)
        if PARAM_POOL.get_wts_algo() == 'snq_quantize':
            if value != SNQ_WEIGHT_BIT_NUM:
                raise ValueError(
                    "The %s must be %s." %
                    (name, SNQ_WEIGHT_BIT_NUM))
        else:
            if value != ARQ_WEIGHT_BIT_NUM:
                raise ValueError("The %s must be %s." % \
                    (name, ARQ_WEIGHT_BIT_NUM))


class VersionField(LeafField):
    '''an object for version field'''

    def default_value(self):
        return VERSION

    def check(self, name, value):
        _check_type(name, value, int)
        if value != 1:
            raise ValueError("The %s must be 1." % (name))


class BatchNumField(LeafField):
    '''an object for batch_num field'''

    def default_value(self):
        return BATCH_NUM

    def check(self, name, value):
        _check_type(name, value, int)
        if value <= 0:
            raise ValueError("The %s must be greater than zero." % (name))


class ActOffsetField(LeafField):
    '''an object for activation_offset field'''

    def default_value(self):
        return ACTIVATION_OFFSET

    def check(self, name, value):
        _check_type(name, value, bool)


class WtsOffsetField(LeafField):
    '''an object for weight_offset field'''

    def default_value(self):
        return WEIGHT_OFFSET

    def check(self, name, value):
        _check_type(name, value, bool)


class DoFusionField(LeafField):
    '''an object for do_fusion field'''

    def default_value(self):
        return DO_FUSION

    def check(self, name, value):
        _check_type(name, value, bool)


class SkipFusionLayersField(LeafField):
    '''an object for skip_fusion_layers field'''

    def default_value(self):
        return SKIP_FUSION_LAYERS

    def check(self, name, value):
        _check_type(name, value, list)

        for layer in value:
            _check_type('layer %s in ' % (layer) + name, layer, str)

        repeated_items = find_repeated_items(value)
        check_no_repeated(repeated_items, 'skip_fusion_layers')

        fuse_types = self.capacity.get_value('FUSE_ONNX_TYPES')
        layer_type = PARAM_POOL.get_layer_type()
        for layer in value:
            if layer not in layer_type:
                raise ValueError('Layer "{}" in skip_fusion_layers does not '
                                 'exist in the graph.'.format(layer))
            if layer_type[layer] not in fuse_types:
                raise ValueError('Skip fusion layer "{}"\'s type not in '
                                 'supported list {}'.format(layer, fuse_types))


class UpdateBnField(LeafField):
    '''an object for update_bn field'''
    def default_value(self):
        return UPDATE_BN

    def check(self, name, value):
        _check_type(name, value, bool)


class BnUpdateConfigPlhField(PlaceholderField):
    def match(self, name): # pylint: disable=no-self-use
        '''indicate whether input name match this placeholder'''
        return name == 'bn_update_config'

    def fill_default(self, config):
        if not PARAM_POOL.get_update_bn():
            return
        key = 'bn_update_config'
        LOGGER.logd('fill default value for {} '.format(key))
        if config.get(key) is None:
            config[key] = {}
        bn_config = config[key]

        for item in self.get_keys():
            child = self.get_child(item)
            if child.is_leaf() and item in bn_config:
                continue
            if not child.has_default():
                continue
            if child.is_leaf():
                bn_config[item] = child.default_value()
                LOGGER.logd('fill default value {} for field {}'.\
                    format(bn_config[item], item))


class BnMomentumField(LeafField):
    '''an object for do_fusion field'''
    def default_value(self):
        return BN_MOMENTUM_RANGE

    def check(self, name, value):
        if value is None:
            raise ValueError("bn momentum should not be Nonetype!")
        if float(value) < BN_MOMENTUM_RANGE[0] or float(value) > \
            BN_MOMENTUM_RANGE[1]:
            raise ValueError("The %s must be between 0 and 1.0" % (name))


class BnUpdateIterField(LeafField):
    '''an object for do_fusion field'''
    def default_value(self):
        return BN_UPDATE_ITERATIONS

    def check(self, name, value):
        _check_type(name, value, int)
        if value not in BN_UPDATE_ITERATIONS_RANGE:
            raise ValueError("The %s must be in %s"
                             % (name, BN_UPDATE_ITERATIONS_RANGE))


class LayerPlhField(PlaceholderField):
    '''a container field for layer params'''

    def match(self, name):
        if name in PARAM_POOL.get_layer_type():
            return True
        return False

    def check_not_found_msg(self, name, item):
        '''raise an error if a field is not found'''
        raise ValueError("Unknown parameter {}".format(item))

    def get_input_num(self, name):
        input_num = 1
        if name in PARAM_POOL.get_supported_multi_input_layers():
            input_num = \
                PARAM_POOL.get_multi_input_layers_input_num_dict()[name]
        return input_num

    def check_config_num(self, name, value):
        input_num = self.get_input_num(name)
        if len(value) > 1 and input_num != len(value):
            raise ValueError("layer {} should have {} "
                             "number of activation quant params in "
                             "config.".format(name, input_num))

    def check(self, name, value):
        config = value
        if name not in PARAM_POOL.get_supported_layers():
            raise ValueError("layer {} does not support quant.".format(name))
        PARAM_POOL.set_layer_name(name)
        try:
            for item in config:
                if item not in self.get_keys():
                    self.check_not_found_msg(name, item)
                    continue
                child = self.get_child(item)
                if item == ACTIVATION_QUANT_PARAMS:
                    self.check_config_num(name, config[item])
                    child.check(item, config[item])
                else:
                    child.check(item, config[item])
        except ValueError as error:
            error_info = str(error.args[0]) + " in layer " + name
            raise ValueError(error_info) from None
        except TypeError as error:
            error_info = str(error.args[0]) + " in layer " + name
            raise TypeError(error_info) from None

    def fill_single_default(self, layer, config):
        for item in self.get_keys():
            child = self.get_child(item)
            if child.is_leaf() and item in config:
                continue
            if not child.has_default():
                continue

            if item == WEIGHT_QUANT_PARAMS and \
                layer in PARAM_POOL.get_supported_no_weight_layers():
                if item in config:
                    del config[item]
                continue
            if item == ACTIVATION_QUANT_PARAMS:
                input_num = self.get_input_num(layer)
                if item not in config:
                    config[item] = [{}] * input_num
                elif len(config[item]) == 1 and input_num > 1:
                    config[item] = config[item] * input_num
                child.fill_default(config[item])
                continue

            if child.is_leaf():
                config[item] = child.default_value()
                LOGGER.logd('fill default value {} for field {}'.
                            format(config[item], item))
            else:
                if config.get(item) is None:
                    config[item] = {}
                child.fill_default(config[item])
        for item in self.child_placeholder:
            item.fill_default(config)

    def fill_default(self, config):
        for layer in PARAM_POOL.get_supported_layers():
            PARAM_POOL.set_layer_name(layer)
            LOGGER.logd('fill default value for layer {}'.format(layer))
            if config.get(layer) is None:
                config[layer] = {}
            self.fill_single_default(layer, config[layer])


class QuantEnableField(LeafField):
    '''an object for quant_enable field'''

    def default_value(self):
        layer_name = PARAM_POOL.get_layer_name()
        quant_layers = PARAM_POOL.get_quant_layers()
        return layer_name in quant_layers

    def check(self, name, value):
        _check_type(name, value, bool)


class ActQuantParamsField(ContainerField):
    '''an object for activation_quant_params field'''

    def check_not_found_msg(self, name, item):
        '''raise an error if this node is not found'''
        raise ValueError("Unknown parameter %s in %s" % (item, name))

    def fill_default(self, value):
        '''fill default value for activation_quant_param'''
        for single_act_config in value:
            super(ActQuantParamsField, self).fill_default(single_act_config)

    def check(self, name, value):
        for config in value:
            super(ActQuantParamsField, self).check(name, config)
            if 'search_step' in config:
                if 'search_range' in config:
                    search_range = config['search_range']
                else:
                    search_range = self.get_child(
                        'search_range').default_value()
                search_step = Decimal(str(config['search_step']))
                search_len = Decimal(str(search_range[1])) - \
                    Decimal(str(search_range[0]))
                if search_step > search_len:
                    raise ValueError(
                        'The search_step must be less than or equal'
                        ' to (search_range[1] - search_range[0])')


class MaxPercentileField(LeafField):
    '''an object for max_percentile field'''

    def default_value(self):
        return MAX_PERCENTILE

    def check(self, name, value):
        value = float(value)
        if value <= 0.5 or value > 1.0:
            raise ValueError("The %s must be greater than 0.5 "
                "and less than or equal to 1.0" % (name))


class MinPercentileField(MaxPercentileField):
    '''an object for min_percentile field'''

    def default_value(self):
        return MIN_PERCENTILE


class SearchRangeField(LeafField):
    '''an object for search_range field'''

    def default_value(self):
        return [SEARCH_RANGE_START, SEARCH_RANGE_END]

    def check(self, name, value):
        _check_type(name, value, list)
        if len(value) != 2:
            raise ValueError("The %s must have two floating-point number"
                             % (name))

        search_start = value[0]
        search_end = value[1]
        if search_start <= 0:
            raise ValueError("%s[0] must be greater than zero" % (name))
        if search_start >= search_end:
            raise ValueError("%s[0] must be less than %s[1]" % (name, name))


class SearchStepField(LeafField):
    '''an object for search_step field'''

    def default_value(self):
        return SEARCH_STEP

    def check(self, name, value):
        if float(value) <= 0:
            raise ValueError("The %s must be greater than zero" % (name))


class WithOffsetField(LeafField):
    '''an object for with_offset field'''
    @classmethod
    def default_value(cls):
        return ACTIVATION_OFFSET

    @classmethod
    def has_default(cls):
        return False

    @classmethod
    def check(cls, name, value):
        _check_type(name, value, bool)
        layer_type = PARAM_POOL.get_layer_type()
        if layer_type == 'MatMul' and value:
            raise ValueError('The {} must be False for layer type {}'.format(
                name, layer_type))


class WgtQuantParamsField(ContainerField):
    '''an object for weight_quant_params field'''

    @staticmethod
    def _check_params(config):
        arq_params = []
        snq_params = []
        for item in config:
            if item in ['max_iteration', 'min_distance', 'init_algo']:
                snq_params.append(item)
        if config.get('wts_algo') == 'arq_quantize':
            arq_params.append('wts_algo')
        if config.get('wts_algo') == 'snq_quantize':
            snq_params.append('wts_algo')

        if arq_params and snq_params:
            raise ValueError('{} and {} can not appear at same time'.format(
                arq_params, snq_params))
        if snq_params:
            PARAM_POOL.set_wts_algo('snq_quantize')
        else:
            PARAM_POOL.set_wts_algo('arq_quantize')

    def check_not_found_msg(self, name, item):
        '''raise an error if this node is not found'''
        raise ValueError("Unknown parameter %s in %s" % (item, name))

    def fill_default(self, config):
        self._check_params(config)
        super(WgtQuantParamsField, self).fill_default(config)

    def check(self, name, value):
        self._check_params(value)
        super(WgtQuantParamsField, self).check(name, value)


class ChannelWiseField(LeafField):
    '''an object for channel_wise field'''

    def default_value(self):
        layer_name = PARAM_POOL.get_layer_name()
        layer_type = PARAM_POOL.get_layer_type()
        channel_wise_types = self.capacity.get_value('CHANNEL_WISE_TYPES') +\
            self.capacity.get_value('CHANNEL_WISE_ONNX_TYPES')
        return layer_type[layer_name] in channel_wise_types

    def check(self, name, value):
        _check_type(name, value, bool)
        layer_name = PARAM_POOL.get_layer_name()
        layer_type = PARAM_POOL.get_layer_type()
        channel_wise_types = self.capacity.get_value('CHANNEL_WISE_TYPES') +\
            self.capacity.get_value('CHANNEL_WISE_ONNX_TYPES')
        if layer_type[layer_name] not in channel_wise_types and value:
            raise ValueError('The {} must be False for layer type {}'.format(
                name, layer_type[layer_name]))


class WtsAlgoField(LeafField):
    '''an object for wts_algo field'''
    def default_value(self):
        return PARAM_POOL.get_wts_algo()

    def check(self, name, value):
        if value not in ('arq_quantize', 'snq_quantize'):
            raise ValueError('wts_algo must be either arq_quantize or ' \
                'snq_quantize')


class SnqAlgField(LeafField):
    '''a base object for nuq field'''
    def has_default(self):
        if PARAM_POOL.get_wts_algo() != 'snq_quantize':
            return False
        return True


class MaxIterationField(SnqAlgField):
    '''an object for max iteration field'''
    def default_value(self):
        return MAX_ITERATION

    def check(self, name, value):
        _check_type(name, value, int)
        if value not in MAX_ITERATION_RANGE:
            raise ValueError(
                'max_iteraion is {}, '
                'which must be in {}'.format(
                    value, MAX_ITERATION_RANGE))


class MinDistanceField(SnqAlgField):
    '''an object for min distance field'''
    def default_value(self):
        return MIN_DISTANCE

    def check(self, name, value):
        value = float(value)
        if (abs(value - MIN_DISTANCE_RANGE.lower_bound) < FLT_EPSILON) or \
           (abs(value - MIN_DISTANCE_RANGE.upper_bound) < FLT_EPSILON):
            return
        if value not in MIN_DISTANCE_RANGE:
            raise ValueError("min_distance is {}, which must be in {}".format(
                value, MIN_DISTANCE_RANGE))


class InitAlgoField(SnqAlgField):
    '''an object for init algorithm field'''
    def default_value(self):
        return INIT_ALGO

    def check(self, name, value):
        _check_type(name, value, str)
        if value not in INIT_ALGO_RANGE:
            raise ValueError("init_algo is {}, which must be in {}".format(
                value, INIT_ALGO_RANGE))

