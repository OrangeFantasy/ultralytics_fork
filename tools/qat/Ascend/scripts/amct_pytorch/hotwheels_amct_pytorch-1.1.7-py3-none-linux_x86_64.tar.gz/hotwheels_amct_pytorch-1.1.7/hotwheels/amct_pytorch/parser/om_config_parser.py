import json
from collections import OrderedDict
from hotwheels.amct_pytorch.common.utils.util import check_no_repeated
from hotwheels.amct_pytorch.common.utils.util import find_repeated_items


class OmConfigParser:
    """ Helper of om json
    """

    def __init__(self, om_config):
        self.__om_config = om_config

    @staticmethod
    def parse_activation_quant_config(om_config_file):
        def _detect_repetitive_key_hook(lst):
            '''a hook function for detect repeated key in config file.'''
            keys = [key for key, value in lst]
            repeat_keys = find_repeated_items(keys)
            check_no_repeated(repeat_keys, om_config_file)
            result = {}
            for key, value in lst:
                result[key] = value
            return result

        with open(om_config_file, 'r') as fid:
            om_config = json.load(
                fid, object_pairs_hook=_detect_repetitive_key_hook)
        if 'graph' not in om_config.keys():
            raise RuntimeError('key \'graph\' not in om_config, please check'
                               'the om format!')
        om_graph = om_config['graph']
        om_json = OrderedDict()
        for om_seg in om_graph:
            if 'op' not in om_seg.keys():
                raise RuntimeError('key \'op\' not in om_config, please check'
                                   'the om format!')
            om_op = om_seg['op']
            for item in om_op:
                item_name = item['name']
                input_type = []
                for type_item in item['data_flow']['input']:
                    input_type.append(type_item['type'][0])
                om_json[item_name] = input_type
        return om_json
