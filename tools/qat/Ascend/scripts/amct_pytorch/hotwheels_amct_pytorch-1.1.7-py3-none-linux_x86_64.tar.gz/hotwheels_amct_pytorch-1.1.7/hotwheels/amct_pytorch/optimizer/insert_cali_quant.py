#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert CaliQuant in model for quantizable layer

"""
from collections import OrderedDict
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.custom_op.cali_quant.cali_quant import \
    CaliQuantBase
from hotwheels.amct_pytorch.custom_op.cali_quant.cali_quant_concat import \
    CaliQuantConcat
from hotwheels.amct_pytorch.custom_op.cali_quant.cali_quant_lstm import \
    CaliQuantLSTM
from hotwheels.amct_pytorch.custom_op.cali_quant.cali_quant_multi_input \
    import CaliQuantMultiInput

from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import ACTIVATION_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import OFFLINE_OPTIMIZE_LAYER_TYPES
from hotwheels.amct_pytorch.custom_op.utils import down_skip_pad_anchor
from hotwheels.amct_pytorch.utils.vars import NON_INSIST_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import MULTI_INPUT_ONNX_TYPES


class InsertCaliQuantPass(BaseFusionPass):
    """
    Function: Insert CaliQuant for quantizable module
    APIs: match_pattern, do_pass
    """

    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.conf = Configuration()

    @staticmethod
    def get_record_layer_and_index(object_node):
        record_layers = []
        record_layer_indexes = []

        if object_node.type == 'Split':
            for output_anchor in object_node.output_anchors:
                index = output_anchor.index
                peer_input_anchor = output_anchor.get_peer_input_anchor()[0]
                peer_input_anchor = down_skip_pad_anchor(peer_input_anchor)
                output_node = peer_input_anchor.node
                if output_node.type in OFFLINE_OPTIMIZE_LAYER_TYPES:
                    continue
                record_layers.append(output_node.name)
                record_layer_indexes.append(index)
        return record_layers, record_layer_indexes

    @classmethod
    def get_insert_ifmr_after_concat_list(cls, graph, act_config, object_node):
        """
        Function: Find ifmr position of concat.
        case1: all inputs of concat layer is one out one referenced
                conv1 conv2 conv3
                  \     |     /
                   \    |    /
                    \   |   /
                     \  |  /
                      concat
                        |
                      conv4
                        |
        in this case, the ifmr layer will be added before conv4, no ifmr
        layer will be added before concat layer
                conv1 conv2 conv3
                  \     |     /
                   \    |    /
                    \   |   /
                     \  |  /
                      concat
                     /  |
                    /   |
                 ifmr   |
        case2: one input of concat layer is non inst layer
              concat1 conv2 conv3
                 /\     |     /
                /  \    |    /
              ifmr  \   |   /
                     \  |  /
                      concat2
                      / |
                     /  |
                   ifmr |
        in this case, one ifmr layer will be added after concat1, if concat1 
        is replaced to other non inst layer like split or reshape, the ifmr
        layer will also be added at the same way, it calculate the quant param
        between concat1 and concat2, for conv2 and conv3, it uses the quant
        param after concat2, so another ifmr layer is added after concat2
               concat1 conv2 conv3
                  \     |     /
                   \    |    /
                    \   |   /
                     \  |  /
                      concat2
                        |
                      conv4
                        |
        case3: one input of concat layer is one out multiple referenced
                conv1 conv2 conv3
                  \     |     /\ 
                   \    |    /  \ 
                    \   |   /    \ 
                     \  |  /    conv5
                      concat
                        |
                        |
        in this case, conv3 is one out two referenced, one ifmr layer will be 
        added after concat, it calculates the quant param between conv3 and
        concat, for conv1 and con3, they are one in one referenced layer, it
        uses the quant param after concat2, so another ifmr layer is added 
        after concat2
                conv1 conv2 conv3
                  \     |     /\
                   \    |    /  \
                    \   |   /\   \ 
                     \  |  /  \  conv5
                      concat   \ 
                      / |      ifmr
                     /  |
                   ifmr |
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        concat_ifmr_position = [False] * len(act_config)
        offline_optimize_index = 0
        for input_anchor in object_node.input_anchors:
            # case1, only one ifmr layer inserted after concat layer by default
            insert_ifmr_after_concat = True
            index = input_anchor.index
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            input_node = peer_output_anchor.node
            if input_node.type in OFFLINE_OPTIMIZE_LAYER_TYPES:
                offline_optimize_index = index - 1
                continue
            input_node = peer_output_anchor.node
            # case2, one input of concat layer is non inst layer
            if input_node.type in NON_INSIST_ONNX_TYPES:
                insert_ifmr_after_concat = False
            # case3, one input of concat layer is one out multiple
            # referenced
            if len(peer_output_anchor.get_peer_input_anchor()) > 1:
                insert_ifmr_after_concat = False
            index = index - offline_optimize_index
            concat_ifmr_position[index] = insert_ifmr_after_concat
        return concat_ifmr_position

    @classmethod
    def get_cali_quant_module(cls, node):
        if node.type == 'Concat':
            return CaliQuantConcat
        elif node.type == 'LSTM':
            return CaliQuantLSTM
        elif node.type in MULTI_INPUT_ONNX_TYPES:
            return CaliQuantMultiInput
        else:
            return CaliQuantBase

    def match_pattern(self, node, graph):
        """
        Function:Match the module to be quantized in model
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure, not necessary
        Return: True: matched
                False: mismatch
        """
        if node.type not in (NO_WEIGHT_QUANT_ONNX_TYPES +
                             QUANTIZABLE_ONNX_TYPES):
            return False
        if node.name not in self.conf.get_quant_config():
            return False
        if node.type == 'BatchNormalization':
            if len(node.input_anchors) > 1:
                if node.get_input_anchor(0).get_peer_output_anchor().node.type == 'Conv':
                    return False
        return True

    def do_pass(self, graph, object_node, model):
        """
        Function: Do actual Insert CaliQuant module
        Parameters: model: torch.nn.Module, the model to be modified.
                    object_module: module to process
                    object_name: name of object_module
                    graph: graph structure, not necessary
        Return: None
        """
        model_helper = ModuleHelper(model)
        object_name = object_node.name
        act_config = self.conf.get_layer_config(object_name)[ACTIVATION_QUANT_PARAMS]

        # Step1: find module's parent
        parent_module = model_helper.get_parent_module(object_name)
        object_module = model_helper.get_module(object_name)
       
        # Step2: construct a new module
        cali_quant_module = self.get_cali_quant_module(object_node)
        ifmr_module = cali_quant_module(object_name, object_module, act_config)
        if object_node.type == 'Concat':
            ifmr_after_concat_list = self.get_insert_ifmr_after_concat_list(
                graph, act_config, object_node)
            ifmr_module.set_ifmr_after_concat_list(ifmr_after_concat_list)

        # Step3: replace new model
        setattr(parent_module, object_name.split('.')[-1], ifmr_module)

        LOGGER.logd(
            "Insert CaliQuant module to '{}' success!".format(object_name),
            'InsertCaliQuantPass')

    def run(self, graph, model):
        """
        override function
        """
        self.set_up()
        # Step1: match pattern and record first matched node
        matched_nodes = []
        for node in graph.nodes:
            if self.match_pattern(node, graph):
                matched_nodes.append(node)
        # Step2: do each matched node fusion operation
        for node in matched_nodes:
            self.do_pass(graph, node, model)
        # Step3: do topoligical sort
        graph.topologic_sort()
        self.tear_down()
