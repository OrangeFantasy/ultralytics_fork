/*
 * Copyright (c) CompanyNameMagicTag
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief util head file
 *
 * @file util.h
 *
 * @version 1.0
 */

#ifndef UTIL_H
#define UTIL_H

#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <functional>
#include "quant.h"

using Status = int;

#define RAW_PRINTF        printf
#define LOG_DEBUG(fmt, arg...) RAW_PRINTF("[DEBUG][%s][%d] " fmt, __FUNCTION__, __LINE__, ## arg)
#define LOG_INFO(fmt, arg...) RAW_PRINTF("[INFO][%s][%d] " fmt, __FUNCTION__, __LINE__, ## arg)
#define LOG_ERROR(fmt, arg...) RAW_PRINTF("[ERROR][%s][%d] " fmt, __FUNCTION__, __LINE__, ## arg)

namespace util
{
    Status ProcessScale(float& currentScale);
    Status ProcessScale(double& currentScale);
}

#endif /* UTIL_H */
