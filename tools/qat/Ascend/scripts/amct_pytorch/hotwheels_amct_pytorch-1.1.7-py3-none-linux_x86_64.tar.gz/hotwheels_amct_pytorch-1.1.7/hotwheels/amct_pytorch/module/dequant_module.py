#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Add fakequant dequant pattern in graph.

"""

from onnx import onnx_pb # pylint: disable=E0401
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.utils.onnx_initializer_util import \
    TensorProtoHelper
from hotwheels.amct_pytorch.utils.attrs_list import \
    ATTR_NODE_EQUIVALENT_OBJECT_LAYER


def add_fake_dequant(graph, layer_name, dqscale, object_node):
    """
    Function: Add fakequant "dequant" pattern in graph
    """
    ori_object_name = object_node.get_attr('object_node')
    layer_name = '.'.join([layer_name, 'fakedequant'])
    # add scale, offset, clip_min, clip_max
    dqscale_node = graph.add_node(
        _construct_fake_dequant_dqscale(layer_name, dqscale))

    # add mul
    mul_node = graph.add_node(_construct_fake_dequant_mul(layer_name))
    mul_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, ori_object_name)

    # add links
    graph.add_edge(dqscale_node, 0, mul_node, 1)

    return mul_node


def _construct_fake_dequant_pow(layer_name):
    '''construct pow op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'pow_dequant_layer'])
    node_proto.op_type = 'Pow'
    node_proto.doc_string = 'pow of the Fake dequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'pow_base.output0']),
        '.'.join([layer_name, 'shifit_bit.output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'pow.output0'])])

    return node_proto


def _construct_fake_dequant_div(layer_name):
    '''construct div op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'div_dequant_layer'])
    node_proto.op_type = 'Div'
    node_proto.doc_string = 'div of the Fake dequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'div.input0']),
        '.'.join([layer_name, 'pow.output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'div.output0'])])

    return node_proto


def _construct_fake_dequant_floor(layer_name):
    '''construct floor op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'floor_dequant_layer'])
    node_proto.op_type = 'Floor'
    node_proto.doc_string = 'floor of the Fake dequant'
    node_proto.input.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'div.output0'])])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'floor.output0'])])

    return node_proto


def _construct_fake_dequant_clip(layer_name):
    '''construct clip op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'clip_dequant_layer'])
    node_proto.op_type = 'Clip'
    node_proto.doc_string = 'clip of the Fake dequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'floor',
                  'output0']), '.'.join([layer_name, 'min_val', 'output0']),
        '.'.join([layer_name, 'max_val', 'output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'clip', 'output0'])])

    return node_proto


def _construct_fake_dequant_mul(layer_name):
    '''construct mul op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'mul_dequant_layer'])
    node_proto.op_type = 'Mul'
    node_proto.doc_string = 'mul of the Fake dequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'clip', 'output0']),
        '.'.join([layer_name, 'dqscale', 'output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'mul', 'output0'])])

    return node_proto


def _construct_fake_dequant_dqscale(layer_name, dqscale):
    '''construct dqscale op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'dqscale_dequant_layer'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'scale of the Fake dequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'dqscale', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data(
        dqscale.reshape([-1]).tolist(), 'FLOAT', list(dqscale.shape))

    return node_proto


def _construct_fake_dequant_shift_bit(layer_name, shift_bit):
    '''construct shift_bit op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'shift_bit_dequant_layer'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'shift_bit of the Fake dequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'shift_bit', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data(
        shift_bit.reshape([-1]).tolist(), 'FLOAT', list(shift_bit.shape))

    return node_proto


def _construct_fake_dequant_clip_min(layer_name, clip_min):
    '''construct clip's min op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.doc_string = 'clip min of the Fake dequant'
    node_proto.name = '.'.join([layer_name, 'min_val_dequant_layer'])
    node_proto.op_type = 'Constant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'min_val', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([clip_min], 'FLOAT')

    return node_proto


def _construct_fake_dequant_clip_max(layer_name, clip_max):
    '''construct clip's max op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.doc_string = 'clip max of the Fakequant'
    node_proto.name = '.'.join([layer_name, 'max_val_dequant_layer'])
    node_proto.op_type = 'Constant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'max_val', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([clip_max], 'FLOAT')

    return node_proto


def _construct_fake_dequant_pow_base(layer_name, pow_base):
    '''construct pow's base op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'pow_base_dequant_layer'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'pow_base of the Fake dequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'pow_base', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([pow_base], 'FLOAT')

    return node_proto
