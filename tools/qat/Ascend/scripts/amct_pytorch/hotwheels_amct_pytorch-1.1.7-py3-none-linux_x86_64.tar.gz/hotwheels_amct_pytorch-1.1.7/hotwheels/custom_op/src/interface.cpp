/*
 * Copyright (c) CompanyNameMagicTag
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0. You may not use
 * this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief arq_quant algorithm custom op C++ implement
 *
 * @file interface.cpp
 *
 * @version 1.0
 */

#include "interface.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("arq_cali", &ArqCali, "ARQ calibration to find dcale and offset");
    m.def("arq_real", &ArqReal, "ARQ real to quant input to int8");
    m.def("ifmr_forward", &IfmrForward, "IFMR forward");
    m.def("ulq_retrain_forward", &UlqRetrainForward, "ULQ retrain forward");
    m.def("ulq_retrain_backward", &UlqRetrainBackward, "ULQ retrain backward");
    m.def("arq_retrain_forward", &ArqRetrainForward, "ARQ retrain forward");
    m.def("arq_retrain_backward", &ArqRetrainBackward, "ARQ retrain backward");
    // lnq
    m.def("lnq_retrain_forward", &LnqRetrainForward, "LNQ retrain forward");
    m.def("lnq_retrain_backward", &LnqRetrainBackward, "LNQ retrain backward");
    m.def("lnq_export_param", &LnqExportParam, "LNQ export param");
    m.def("lnq_dequant", &LnqDequant, "lnq dequant");
    m.def("lnq_quant", &LnqQuant, "lnq quant");
    py::class_<LnqParam>(m, "LnqParam").def(py::init<int, bool, bool, int, int, float>());
    // luq
    m.def("acts_luq_retrain_forward", &ActsLuqRetrainForward, "activation luq retrain forward");
    m.def("wts_luq_retrain_forward", &WtsLuqRetrainForward, "weight luq retrain forward");
    m.def("luq_retrain_backward", &LuqRetrainBackward, "luq retrain backward");
    // snq
    py::class_<SnqParam>(m, "SnqParam").def(py::init<bool, int, double, int>());
    m.def("snq_calibration", &SnqCali, "snq calibration");
}
