#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

BatchNorm scale symbol reverse to keep scale positive

"""
import torch
from hotwheels.amct_pytorch.optimizer.base_module_fusion_pass import \
    BaseModuleFusionPass
from hotwheels.amct_pytorch.proto import scale_offset_record_pb2
from google.protobuf import text_format
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.optimizer.conv_bn_fusion_pass import \
    ConvBnFusionPass


class ScaleSymbolReversePass(BaseModuleFusionPass):
    """
    Function: Find the channel with negative weight in the BatchNorm layer,
            set the value in the channel to positive,
            and then reverse the weights of these channels in the conv,
            bn and other layers in front of the scale
            that need to be fused with the weight of the scale.
    APIs: match_pattern, do_pass, get_np_array_from_scale
    """
    def __init__(self, is_retrain=False):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseModuleFusionPass.__init__(self)
        if is_retrain:
            self.config = RetrainConfig()
        else:
            self.config = Configuration()
        self.structure = {}
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.record_file_path = self.config.get_record_file_path()

    def set_up(self):
        """
        Function: Open the record file
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def match_pattern(self, module, name, graph=None):
        """
        Function:Match the bn module to be fused in model
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure
        Return: True: matched
                False: mismatch
        """
        if not ConvBnFusionPass().match_pattern(module, name, graph):
            return False
        bn_node = graph.get_node_by_name(name)
        peer_out_anchor = bn_node.get_input_anchor(0).get_peer_output_anchor()
        conv_node = peer_out_anchor.node
        self.structure[name] = {'conv': conv_node.name,
                                'bn' : bn_node.name}
        return True

    @torch.no_grad()
    def do_pass(self, model, object_module, object_name, graph=None):
        """
        Function: Do actual "Convolution" layer and "BatchNorm" layer
                  fusion operation
        Parameters: model: torch.nn.Module, the model to be modified.
                    object_module: module to process
                    object_name: name of object_module
                    graph: graph structure
        Return: None
        """
        conv_name = self.structure[object_name]['conv']
        # conv and bn must be in eval state
        try:
            conv_module = ModuleHelper(model).get_module(conv_name)
        except RuntimeError as e:
            LOGGER.logi('Cannot find "%s" in model, cannot do scale symbol '
                        'reverse.' % (conv_name))
            raise RuntimeError('Cannot find "%s" in model, cannot do scale '
                        'symbol reverse.' % (conv_name)) from e

        cmp_ans = object_module.weight < 0
        if cmp_ans.any():
            for index in range(len(cmp_ans)):
                if cmp_ans[index]:
                    object_module.weight[index] = -object_module.weight[index]
                    object_module.running_mean[index] = \
                        -object_module.running_mean[index]
                    conv_module.weight[index] = -conv_module.weight[index]
                    if conv_module.bias is not None:
                        conv_module.bias[index] = -conv_module.bias[index]

        LOGGER.logd(
            'Do conv:\'{}\' + bn:\'{}\' symble reverse success!'.format(
                conv_name, object_name), 'ScaleSymbolReversePass')