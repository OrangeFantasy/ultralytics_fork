#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Used for update scale, offset in custom record file

"""
import os
import numpy as np
from google.protobuf import text_format
from hotwheels.amct_pytorch.proto import scale_offset_record_pb2
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    read_weights_scale_offset
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    record_weights_scale_offset
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    record_activation_scale_offset
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    read_activation_scale_offset
from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.utils.vars import MULTI_INPUT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import RETRAIN_DATA_CONFIG
import torch
from hotwheels.amct_pytorch.custom_op.utils import process_weight_scale_np
from hotwheels.amct_pytorch.custom_op.utils import process_data_scale_np
from hotwheels.amct_pytorch.custom_op.utils import up_skip_pad_layer
from hotwheels.amct_pytorch.custom_op.utils import down_skip_pad_node
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_FLAG
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_MODE

from hotwheels.amct_pytorch.common.utils.record_file_operator import WeightQuantParam, ActivationQuantParam


def update_all_records(records, is_retrain):
    for record in records.record:
        if not record.value.record_d:
            continue
        layer_name = record.key
        for record_d in record.value.record_d:
            scale_d_array = np.array(record_d.scale_d)
            offset_d_array = np.array(record_d.offset_d)
            num_bits = record_d.num_bits_d
            if is_retrain:
                activation_quant_with_offset = True
            else:
                activation_quant_with_offset = Configuration(). \
                    get_quant_config()['activation_offset']
            scale_d_array, offset_d_array = \
                process_data_scale_np(scale_d_array, offset_d_array,
                                      activation_quant_with_offset, num_bits,
                                      layer_name)

            record_d.scale_d = scale_d_array.item()
            record_d.offset_d = offset_d_array.astype(np.int32).item()
        if not record.value.scale_w:
            continue
        scale_w_array = np.array(record.value.scale_w)
        offset_w_array = np.array(record.value.offset_w)
        params = None if not record.value.params else record.value.params
        num_bits = 8
        weight_quant_with_offset = False
        weight_quant_param = WeightQuantParam(scale=scale_w_array, offset=offset_w_array, num_bits=num_bits)
        scale_w_array, offset_w_array = process_weight_scale_np(weight_quant_param, layer_name,
                                                                weight_quant_with_offset, params)
        record.value.scale_w[:] = scale_w_array
        record.value.offset_w[:] = offset_w_array


def _split_records(input_anchor, config, records, node):
    peer_output_anchor = input_anchor.get_peer_output_anchor()
    if peer_output_anchor is None:
        return
    peer_output_node = peer_output_anchor.node
    peer_output_node = up_skip_pad_layer(peer_output_node)
    if peer_output_node.type != 'Split':
        return
    if peer_output_node.name not in config.get_quant_config():
        return
    if not config.quant_enable(peer_output_node.name):
        return
    scale_d, offset_d, num_bits_d = \
        read_activation_scale_offset(records, peer_output_node.name, index=0)
    activation_quant_param = ActivationQuantParam(scale=scale_d, offset=offset_d,
                                                  index=input_anchor.index, num_bits=num_bits_d)
    record_activation_scale_offset(records, node.name, activation_quant_param)


def _update_records_of_layer_after_split(graph, config, records):
    '''
    case1: one input and one reference layer is connected to split
              |
            split
            /   \
           /     \
          /       \
        conv1   conv2
        the quant layer will be added as follows, conv1 and conv2 uses quant 
        params from split
              |
            quant
              |
            split
            /   \
           /     \
        conv1     conv2
    case2: non inst layer is connected to split
              |
            split
            /   \
           /     \
          /       \
        concat   conv1
        the quant layer will be added as follows, the input of concat will 
        first use quant params of split to dequant, and use quant param of 
        concat to quant, concat's input quant param should be modified to quant
        params of split
              |
            quant
              |
            split
            /   \
         quant   \
          /       \
        concat   conv1
          |
    case3: multi input layer is connected to split
              |
            split
        \   /
         \ /
        eltwise
          |
        the quant layer will be added as follows, the input of eltwise from 
        elwise will use quant params of split
              |
            quant
              |
            split
             / 
           quant
         \ /
        eltwise
          |
    '''
    for node in graph.nodes:
        if node.name not in config.get_quant_config():
            continue
        if not config.quant_enable(node.name):
            continue
        if node.type in MULTI_INPUT_ONNX_TYPES:
            # case3
            for input_anchor in node.input_anchors:
                _split_records(
                    input_anchor, config, records, node)
        else:
            # case1 + case2
            input_anchor = node.input_anchors[0]
            _split_records(
                input_anchor, config, records, node)


def _update_records_for_concat(graph, config, records):
    """ For input node of concat layer with one input and one reference at 
        retrain, quant retrain module will not be added, it will use quant 
        param of layer after concat
        case1:
            conv1  conv2
             / \   /
            /   \ / 
               concat
                 |
               conv3
        the quant param between concat and conv2 use quant param of conv3   
        case2:
            conv1  conv2
             / \   /
            /   \ / 
               concat
                 |
                pad
                 |
                pool
        the quant param between concat and conv2 use quant param of pool, it
        will skip pad layer
        case3:
            conv1  conv2
             / \   /
            /   \ / 
               concat
        conv3   /
            \  /
             \/
           eltwise  
        the quant param between concat and conv2 use quant param of the second 
        input of eltwise
    """
    for node in graph.nodes:
        node_name = node.name
        if node_name not in config.get_quant_config():
            continue
        if not config.get_layer_config(node_name)['retrain_enable']:
            continue
        node = down_skip_pad_node(node)
        if node.type != 'Concat':
            continue
        for input_anchor in node.input_anchors:
            if config.get_layer_config(node_name)[RETRAIN_DATA_CONFIG][
                input_anchor.index]['num_bits'] != -1:
                continue
            if len(node.output_anchors) == 0:
                return
            consumer_output = node.get_output_anchor(0)
            if len(consumer_output.get_peer_input_anchor()) == 0:
                return
            peer_input_anchor = consumer_output.get_peer_input_anchor()[0]
            peer_input_node = peer_input_anchor.node
            peer_input_node = down_skip_pad_node(peer_input_node)
            index = peer_input_anchor.index
            if peer_input_node.name not in config.get_quant_config():
                continue
            if not config.get_layer_config(peer_input_node.name)[
                'retrain_enable']:
                continue
            scale_d, offset_d, num_bits_d = \
                read_activation_scale_offset(records, peer_input_node.name, index)
            activation_quant_param = ActivationQuantParam(scale=scale_d, offset=offset_d, index=input_anchor.index,
                                                          num_bits=num_bits_d)
            record_activation_scale_offset(records, node.name, activation_quant_param)


def _update_records_for_retrain(graph, records, model, config):
    for node in graph.nodes:
        if node.type != 'Conv':
            continue
        if node.name not in config.get_quant_config():
            continue
        scale_w, offset_w, params = read_weights_scale_offset(records,
                                                              node.name)
        _update_conv_bn_scale_pattern(node, node.name, scale_w, records, model)
    _update_records_for_concat(graph, config, records)
    _update_records_of_layer_after_split(graph, config, records)


def _update_records_for_calibration(graph, records, model, config):
    if config.get_fusion_switch():
        for node in graph.nodes:
            if node.type != 'Conv':
                continue
            if node.name not in config.get_quant_config():
                continue
            if not config.get_layer_config(node.name)['quant_enable']:
                continue
            if node.name in config.get_skip_fusion_layers():
                continue
            # Check whether need to do Conv_BN_Scale fusion
            scale_w, offset_w, params = read_weights_scale_offset(records,
                                                                  node.name)
            _update_conv_bn_scale_pattern(node, node.name, scale_w, records, model)
    _update_records_of_layer_after_split(graph, config, records)


def update_record_file(graph, model, is_retrain=False):
    """If there need_fusion_layers, calculate fusion scale, offset, then
       generate new record file.
    """
    LOGGER.logi('Update record file for fusion.')
    if is_retrain:
        config = RetrainConfig()
    else:
        config = Configuration()

    records = scale_offset_record_pb2.ScaleOffsetRecord()
    with open(config.get_record_file_path(), 'r') as read_file:
        pbtxt_string = read_file.read()
        text_format.Merge(pbtxt_string, records)

    if is_retrain:
        _update_records_for_retrain(graph, records, model, config)
    else:
        _update_records_for_calibration(graph, records, model, config)

    update_all_records(records, is_retrain)
    if config.is_record_file_name_update():
        update_record_file_path = config.get_record_file_path()
    else:
        update_record_file_path = '{}_update{}'.format(
            os.path.splitext(config.get_record_file_path())[0],
            os.path.splitext(config.get_record_file_path())[-1])
    with os.fdopen(os.open(update_record_file_path, FILE_ACCESS_FLAG,
        FILE_ACCESS_MODE), 'w') as record_file:
        record_file.write(text_format.MessageToString(
            records, as_utf8=True))
    if not config.is_record_file_name_update():
        config.update_record_file(update_record_file_path)
    LOGGER.logi('Update record_file to {}'.format(update_record_file_path))


def _update_conv_bn_scale_pattern(node_conv,
                                  layer_name,
                                  scale_w,
                                  records,
                                  model):
    """if there is conv+bn+scale pattern in graph, do scale and offset
       recalculate that fusion with bn and scale parameters
    """
    fused_scale_w = None
    fused_offset_w = None

    peer_anchors = node_conv.output_anchors[0].get_peer_input_anchor()
    if len(peer_anchors) != 1:
        return
    peer_node = peer_anchors[0].node
    if peer_node.type != 'BatchNormalization':
        return
    model_helper = ModuleHelper(model)
    bn_module = model_helper.get_module(peer_node.name)
    if type(bn_module).__name__ == 'CaliQuant':
        bn_module = bn_module.sub_module
    bn_var_rsqrt = torch.rsqrt(bn_module.running_var + bn_module.eps)
    if bn_module.weight is None:
        scale = bn_var_rsqrt
    else:
        scale = bn_module.weight * bn_var_rsqrt
    if torch.isclose(scale, torch.zeros_like(scale)).all():
        raise ValueError("scale of layer %s is invalid, weight of bn_module %s is zero" % layer_name, peer_node.name)
    fused_scale_w = scale_w / scale.detach().cpu().numpy()
    fused_offset_w = np.zeros(bn_module.num_features).astype(
        np.int8)

    weight_quant_param = WeightQuantParam(scale=fused_scale_w, offset=fused_offset_w, num_bits=None)

    record_weights_scale_offset(records, layer_name, weight_quant_param, params=None)
