#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

IFMR module and Function

"""

from collections import OrderedDict
from torch import nn
from hotwheels.amct_pytorch.custom_op.ifmr.ifmr import IFMR


class CaliQuantBase(nn.Module):  # pylint: disable=R0903, R0902
    """
    Function: Customized torch.nn.Module of the calibration operator.
    APIs: forward
    """

    def __init__(self,
                 layer_name,
                 sub_module,
                 act_config):
        super().__init__()
        self.cur_batch = 0
        self.cali_enable = True
        self.ifmr_after_concat_list = None
        self.sub_module = sub_module
        self.ifmr_module = []
        self.ifmr_param = []
        for _, act_config_item in enumerate(act_config):
            ifmr_param_item = {
                'layers_name': layer_name,
                'num_bits': act_config_item['num_bits'],
                'batch_num': act_config_item['batch_num'],
                'with_offset': act_config_item['with_offset'],
                'max_percentile': act_config_item['max_percentile'],
                'min_percentile': act_config_item['min_percentile'],
                'search_start': act_config_item['search_range_start'],
                'search_end': act_config_item['search_range_end'],
                'search_step': act_config_item['search_step']
            }
            self.ifmr_param.append(ifmr_param_item)
            self.ifmr_module.append(IFMR(**(ifmr_param_item)))
        
        self.quant_params = OrderedDict()
        self.quant_params['scale'] = [1.0] * len(act_config)
        self.quant_params['offset'] = [0] * len(act_config)
        self.quant_params['num_bit'] = [-1] * len(act_config)

    def cali_quant(self, *inputs):
        for index, input_item in enumerate(inputs):
            if type(input_item).__name__ != 'Tensor':
                continue
            ifmr_param = self.ifmr_param[index]
            self.cali_quant_common(input_item, index, ifmr_param)
        return self.sub_module(*inputs)

    def update_shape(self, shapes):
        self.sub_module.shapes = shapes

    def cali_quant_common(self, input_item, index, ifmr_param):
        if self.cur_batch <= ifmr_param['batch_num']:
            # do ifmr
            scale, offset = self.ifmr_module[index].forward(input_item)
            self.quant_params['scale'][index] = scale.item()
            self.quant_params['offset'][index] = int(offset.item())
            self.quant_params['num_bit'][index] = ifmr_param['num_bits']

    def forward_without_cali(self, *inputs):
        return self.sub_module(*inputs)

    def forward(self, *inputs):  # pylint: disable=W0221
        """
        Function: IFMR foward funtion.
        Inputs:
            inputs: data used for calibration in torch.tensor.
        """
        if not self.cali_enable:
            return self.forward_without_cali(*inputs)
        self.cur_batch += 1
        results = self.cali_quant(*inputs)
        return results
