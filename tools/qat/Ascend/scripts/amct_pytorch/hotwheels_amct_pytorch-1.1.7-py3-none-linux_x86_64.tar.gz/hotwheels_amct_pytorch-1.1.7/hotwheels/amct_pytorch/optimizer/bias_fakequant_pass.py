#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fakequant bias from int32 to float32.

"""
import numpy as np

from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.optimizer.weight_calibration import WeightsCalibrationPass
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from hotwheels.amct_pytorch.utils.vars import QUANT_BIAS_BITS
from hotwheels.amct_pytorch.utils.vars import BASE
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.optimizer.bias_quant_pass import BiasQuantPass


class BiasFakequantPass(BaseFusionPass):
    """
    Function: Fakequant bias from int32 to float32
    APIs: match_pattern, do_pass
    """

    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    @staticmethod
    def fake_quant_bias(quant_bias, offset_d, layer_name, sum_weight):
        '''Function: kernel function, fake dequant bias to int bias 
            without sum_weight
        Parameters:
            bias: np.array, to be quantized
            offset: int number, quant factor
        Returns:
            quant_bias, np.array with type int32, quantized bias
        '''
        left_bound = -pow(1.0 * BASE, QUANT_BIAS_BITS - 1)
        right_bound = pow(1.0 * BASE, QUANT_BIAS_BITS - 1) - 1

        bias_shape = quant_bias.shape
        quant_bias = quant_bias + offset_d * sum_weight

        # check the quant_bias in range of int32
        quant_bias = quant_bias.reshape(-1)
        cmp_ans = np.add(quant_bias < left_bound, quant_bias > right_bound)
        if cmp_ans.any():
            invalid_value = quant_bias[np.argmax(cmp_ans)]
            quant_bias[np.argmax(cmp_ans)] = np.clip(
                quant_bias[np.argmax(cmp_ans)], left_bound, right_bound)
            LOGGER.logi('Quantized bias {} of layer "{}" exceed int32 '
                        'range:[{}, {}], it has been clipped to {}.'.format(
                invalid_value, layer_name,
                left_bound, right_bound, quant_bias[np.argmax(cmp_ans)]))

        quant_bias = quant_bias.reshape(bias_shape).astype(np.int32)
        return quant_bias

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type in (tuple(NO_WEIGHT_QUANT_ONNX_TYPES) + RNN_ONNX_TYPES):
            return False

        if node.name not in self.records:
            return False

        _, _, bias_index = QuantOpInfo.get_quant_index(node)
        if bias_index and len(node.input_anchors) > bias_index:
            return True

        return False

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual quantization and node's bias is changed to float32.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        _, weight_index, bias_index = QuantOpInfo.get_quant_index(object_node)
        weight_input_anchor = object_node.get_input_anchor(weight_index)
        weight_param = weight_input_anchor.get_peer_output_anchor().node
        weight_helper = TensorProtoHelper(weight_param.proto)
        weight = weight_helper.get_data()
        if object_node.type == 'ConvTranspose':
            weight = WeightsCalibrationPass.adjust_deconv_weight_np_shape(object_node,
                                                                 weight)

        offset_d = self.records.get(object_node.name).get('data_offset')[0]

        sum_weight = np.sum(weight.reshape(weight.shape[0], -1), axis=1)

        bias_input_anchor = object_node.get_input_anchor(bias_index)
        bias_param = bias_input_anchor.get_peer_output_anchor().node

        bias_helper = TensorProtoHelper(bias_param.proto)
        int32_bias = bias_helper.get_data()

        int32_bias = BiasFakequantPass.fake_quant_bias(
            int32_bias,
            offset_d,
            object_node.name,
            sum_weight)
        float_bias = int32_bias.astype(np.float32)

        bias_helper.clear_data()
        bias_helper.set_data(float_bias, 'FLOAT')

        LOGGER.logd("Fakequant bias from int32 to float32 for layer '{}' "
                    .format(object_node.name), 'BiasFakequantPass')
