#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert some mudule about retrain quantization.

"""
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig \
    as Configuration
from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.custom_op.comp_module.comp_module_without_weight \
    import CompModuleWithoutWeight
from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import RETRAIN_DATA_CONFIG
from hotwheels.amct_pytorch.utils.vars import SKIP_QUANT_INDEX
from hotwheels.amct_pytorch.optimizer.insert_cali_quant import \
    InsertCaliQuantPass
from hotwheels.amct_pytorch.optimizer.insert_retrain_pass import \
    InsertRetrainPass
from hotwheels.amct_pytorch.configuration.check import GraphChecker


class InsertNoWeightRetrainPass(BaseFusionPass):
    """
    Function: Insert some mudule about retrain quantization.
    APIs: match_pattern, do_pass
    """

    def __init__(self, device='cpu'):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.conf = Configuration()
        self.device = device

    def match_pattern(self, node):
        """
        Function: Match the node to be retrain quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if not GraphChecker.check_onnx_quantize_type_without_weight(node):
            return False
        if not self.conf.quant_enable(node.name):
            return False
        if node.type == 'BatchNormalization':
            if len(node.input_anchors) > 1:
                if node.get_input_anchor(0).get_peer_output_anchor(). \
                        node.type == 'Conv':
                    return False
        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Insert some mudule about retrain quantization.
        Parameters: graph: graph structure
                    object_node: node to process
                    model: torch.nn.Module, the model to be modified. if it's
                        None, the gaph will be modified.
        Return: None
        """
        record_layers, record_layer_indexes = \
            InsertCaliQuantPass.get_record_layer_and_index(object_node)

        skip_quant_index = None
        if object_node.has_attr(SKIP_QUANT_INDEX):
            skip_quant_index = object_node.get_attr(SKIP_QUANT_INDEX)

        # Step1: find module and its parent
        object_node_name = object_node.name
        model_helper = ModuleHelper(model)
        object_module = model_helper.get_module(object_node_name)
        parent_module = model_helper.get_parent_module(object_node_name)

        # Step2: construct a new module
        # activation quant config
        act_config = self.conf.get_retrain_config(object_node.name).get(RETRAIN_DATA_CONFIG)
        # if clip_min and clip_max are not set in config, they should 
        # be initialized by ifmr algorithm
        InsertRetrainPass.modify_act_config(act_config, object_node, 
                    object_module, model_helper, object_node_name)
        # common quant config
        common_config = {
            'layers_name': [object_node_name],
            'node_type': object_node.type,
            'device': self.device,
            'batch_num': self.conf.get_quant_config().get('batch_num'),
            'skip_quant_index': skip_quant_index,
            'record_layers': record_layers,
            'record_layer_indexes': record_layer_indexes,
            'num_of_input': len(act_config),
        }
        act_wts_qat_module = CompModuleWithoutWeight(
            object_module,
            act_config,
            wts_config=None,
            common_config=common_config)

        # Step3: replace new model
        setattr(parent_module, object_node_name.split('.')[-1],
                act_wts_qat_module)

        LOGGER.logd(
            "Insert ActivationQAT module to '{}' success"
            "!".format(object_node.name), 'InsertNoWeightRetrainPass')
