/*
 * Copyright (c) CompanyNameMagicTag
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief ifmr_quant algorithm custom op C++ implement
 *
 * @file ifmr.h
 *
 * @version 1.0
 */

#ifndef IFMR_H
#define IFMR_H

#include <torch/extension.h>

#include "util.h"

const int MIN_ACT_NUM_BITS = 8;
const int MAX_ACT_NUM_BITS = 16;

#define AMCT_CHECK_NULLPTR_RET(ptr)     \
    do {                                \
        if ((ptr) == nullptr) {         \
            return;                     \
        }                               \
    } while (0);

struct MaxMinPercentile {
    float max_percentile;
    float min_percentile;
};

struct IfmrParams {
    int numBits;
    float startRatio;
    float endRatio;
    float step;
    bool with_offset;
    bool is_cuda;
    short int deviceId;
};

namespace ifmr
{
    void AccumulateData(torch::Tensor input, std::vector<float> &accumulateData);
    Status IfmrCalibration(
        std::vector<float> &accumulateData,
        IfmrParams &ifmrParam,
        MaxMinPercentile percentiles,
        float &scale,
        int &offset);
}

std::vector<torch::Tensor> IfmrForward(
    torch::Tensor input, short int input_deviceId,
    int num_bits, bool is_cuda, bool with_offset,
    float maxPercentile, float minPercentile, float search_start,
    float search_end, float search_step);


#endif /* IFMR_H */
