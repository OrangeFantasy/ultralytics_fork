#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils for custom ops

"""
from collections import namedtuple
from onnx import onnx_pb
import torch  # pylint: disable=E0401
import numpy as np
from hotwheels.amct_pytorch.utils.vars import SCALE_W_EPSILON
from hotwheels.amct_pytorch.utils.vars import FLT_EPSILON
from hotwheels.amct_pytorch.utils.vars import SNQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import OFFLINE_OPTIMIZE_LAYER_TYPES
from hotwheels.amct_pytorch.common.utils.record_file_operator import WeightQuantParam


def get_distributed_info():
    try:
        process_group = torch.distributed.group.WORLD
        world_size = torch.distributed.get_world_size(process_group)
    except (AttributeError, AssertionError, RuntimeError):
        process_group = None
        world_size = 1
    need_sync = world_size > 1
    return need_sync, process_group, world_size


def check_quant_data(data, data_type):
    """
    Function: check quant data for ops
    Inputs:
        data: torch.Tensor, data to ops
        data_type: a string, type of data, including: "weight", "input"
    """
    if data.dtype is not torch.float32:  # pylint: disable=E1101
        raise TypeError(
            "Only {} with dtype 'torch.float32' is supported to be "
            "quantized, but got {}.".format(data_type, data.dtype))
    if not torch.all(torch.isfinite(data)):  # pylint: disable=E1101
        raise RuntimeError(
            "The {} to be quantized has invalid value inf or nan!"
                .format(data_type))


def check_scale_offset(scale, offset):
    """
    Function: check scale and offset for ops
    Inputs:
        scale: torch.Tensor
        offset: torch.Tensor
    """
    valid = True
    if not torch.all(torch.isfinite(scale)):  # pylint: disable=E1101
        valid = False
    if torch.isclose(scale, torch.zeros_like(scale)).all():
        valid = False
    if not torch.all(torch.isfinite(1 / scale)):  # pylint: disable=E1101
        valid = False
    if not valid:
        raise RuntimeError(
            "Param scale has invalid value inf, nan or zeros!")

    if not torch.all(torch.isfinite(offset)):  # pylint: disable=E1101
        raise RuntimeError(
            "Param offset has invalid value inf or nan!")


def check_record_params(weight_num_bits, params):
    if weight_num_bits == SNQ_WEIGHT_BIT_NUM:
        if params is None:
            raise RuntimeError(
                "params should not be None!")


def check_deq_scale(deq_scale):
    """
    Function: check scale and offset for ops
    Inputs:
        deq_scale: torch.Tensor
    """
    valid = True
    if not torch.all(torch.isfinite(deq_scale)):  # pylint: disable=E1101
        valid = False
    if torch.isclose(deq_scale, torch.zeros_like(deq_scale)).all():
        valid = False
    if not torch.all(torch.isfinite(1 / deq_scale)):  # pylint: disable=E1101
        valid = False

    if not valid:
        raise RuntimeError(
            "The deq_scale to do search_n has invalid value inf, nan or zero!")


def copy_tensor(target, source):
    """
    Function: copy tensor data
    Inputs:
        target: torch.Tensor, taget tensor
        source: torch.Tensor, source tensor
    """
    if isinstance(target, torch.Tensor):
        target.data.copy_(source.data)


def tensor(value, dtype=torch.float,  # pylint: disable=E1101
           requires_grad=False, device=None):
    """
    Function: check scale and offset for ops
    Inputs:
        value: torch.Tensor
        dtype: tensor type
        requires_grad: tensor grad
        device: tensor device
    Outputs:
        output: torch.Tensor
    """
    if device:
        return torch.tensor(value, dtype=dtype,  # pylint: disable=E1102
                            requires_grad=requires_grad, device=device)
    return torch.tensor(value, dtype=dtype,  # pylint: disable=E1102
                        requires_grad=requires_grad)


def process_weight_scale(weight_scale, with_offset=True, layer_name=None, params=None):
    """
    Function: check the validity of quant factor(scale)'s range
    Inputs:
        scale: torch.Tensor, quant factor
        offset: torch.Tensor, quant factor
        with_offset: bool, with offset or not
        num_bit: int, quant bits
    Outputs:
        scale: torch.Tensor, quant factor
        offset: torch.Tensor, quant factor
    """
    scale_device = weight_scale.scale.device
    offset_device = weight_scale.offset.device
    scale_array = weight_scale.scale.cpu().numpy()
    offset_array = weight_scale.offset.cpu().numpy()

    weight_quant_param = WeightQuantParam(scale=scale_array, offset=offset_array, num_bits=weight_scale.num_bit)

    scale_array, offset_array = process_weight_scale_np(weight_quant_param, layer_name, with_offset, params)

    scale = torch.from_numpy(scale_array).to(scale_device)
    offset = torch.from_numpy(offset_array).to(offset_device)

    return scale, offset


def process_weight_scale_np(weight_scale_np, layer_name, with_offset=True, params=None):
    """
    Function: check the validity of quant factor(scale)'s range
    Inputs:
        scale: numpy, quant factor
        offset: torch.Tensor, quant factor
        with_offset: bool, with offset or not
        num_bit: int, quant bits
    Outputs:
        scale: numpy, quant factor
        offset: numpy, quant factor
    """
    base_bit = 2.0
    max_scale = 1 / SCALE_W_EPSILON
    if params is None:
        replaced_value = 1.0
    else:
        replaced_value = max_scale
    for idx in range(len(weight_scale_np.scale)):
        if abs(weight_scale_np.scale[idx]) > max_scale:
            LOGGER.logw('Weight scale at channel {} of layer "{}" is too '
                        'large, scale changed from {} to {}.'.format(
                idx, layer_name, weight_scale_np.scale[idx], replaced_value))
            weight_scale_np.scale[idx] =\
                replaced_value * np.sign(weight_scale_np.scale[idx])
    if with_offset:
        LOGGER.logw(
            'offset changed to {}.'.format(-pow(base_bit, weight_scale_np.num_bits_w - 1)))
        weight_scale_np.offset = np.where(abs(weight_scale_np.scale) > max_scale,
                          -pow(base_bit, weight_scale_np.num_bits_w - 1),
                          weight_scale_np.offset)
    return weight_scale_np.scale, weight_scale_np.offset


def process_data_scale(scale, offset, with_offset=True, num_bit=8,
                       layer_name=None):
    """
    Function: check the validity of quant factor(scale)'s range
    Inputs:
        scale: torch.Tensor, quant factor
        offset: torch.Tensor, quant factor
        with_offset: bool, with offset or not
        num_bit: int, quant bits
    Outputs:
        scale: torch.Tensor, quant factor
        offset: torch.Tensor, quant factor
    """
    scale_device = scale.device
    offset_device = offset.device
    scale_array = scale.cpu().numpy()
    offset_array = offset.cpu().numpy()

    scale_array, offset_array = process_data_scale_np(
        scale_array, offset_array, with_offset, num_bit, layer_name)

    scale = torch.from_numpy(scale_array).to(scale_device)
    offset = torch.from_numpy(offset_array).to(offset_device)

    return scale, offset


def process_data_scale_np(scale, offset, with_offset=True, num_bit=8,
                          layer_name=None):
    """
    Function: check the validity of quant factor(scale)'s range
    Inputs:
        scale: numpy, quant factor
        offset: numpy, quant factor
        with_offset: bool, with offset or not
        num_bit: int, quant bits
    Outputs:
        scale: numpy, quant factor
        offset: numpy, quant factor
    """
    base_bit = 2.0
    max_scale = 1.0 / FLT_EPSILON
    if scale > max_scale:
        LOGGER.logw('Data scale "{}" of layer "{}" is too large, scale' \
                    ' changed to: {}.'.format(scale, layer_name, 1.0))
        scale = np.where(scale > max_scale, 1.0, scale)
        if with_offset:
            LOGGER.logw(
                'Offset changed to "{}".'.format(-pow(base_bit, num_bit - 1)))
            offset = np.where(scale > max_scale, -pow(base_bit, num_bit - 1), offset)
    return scale, offset


def is_valid_input_node(input_node):
    """
    Function: check if the input node is a valid node
    """
    if input_node.type in OFFLINE_OPTIMIZE_LAYER_TYPES:
        return False
    if isinstance(input_node.proto, onnx_pb.NodeProto) or \
            isinstance(input_node.proto, onnx_pb.ValueInfoProto):
        return True
    return False


def is_valid_anchor(input_anchor):
    """
    Function: check if the input anchor is a valid anchor
    """
    if not is_valid_input_node(input_anchor.node):
        return False
    input_type = input_anchor.node.type
    if input_type in OFFLINE_OPTIMIZE_LAYER_TYPES:
        return False
    return True


def get_node_input_num(node):
    """
    Function: get input num of node
    """
    if node.type == 'Resize' or node.type == 'Reshape':
        return 1
    input_num = 0
    for input_anchor in node.input_anchors:
        output_anchor = input_anchor.get_peer_output_anchor()
        if output_anchor is None:
            continue
        input_node = output_anchor.node
        if is_valid_input_node(input_node):
            input_num = input_num + 1
    return input_num


def down_skip_pad_anchor(input_anchor):
    """
    Function: return the next layer of pad layer if it exists
    """
    if input_anchor.node.type == 'Pad':
        if len(input_anchor.node.output_anchors) == 0:
            return input_anchor
        consumer_output = input_anchor.node.get_output_anchor(0)
        if len(consumer_output.get_peer_input_anchor()) == 0:
            return input_anchor
        input_anchor = consumer_output.get_peer_input_anchor()[0]
    return input_anchor


def down_skip_pad_node(input_node):
    """
    Function: return the next layer of pad layer if it exists
    """
    if input_node.type == 'Pad':
        if len(input_node.output_anchors) == 0:
            return input_node
        consumer_output = input_node.get_output_anchor(0)
        if len(consumer_output.get_peer_input_anchor()) == 0:
            return input_node
        input_anchor = consumer_output.get_peer_input_anchor()[0]
        input_node = input_anchor.node
    return input_node


def up_skip_pad_layer(node):
    """
    Function: return the next layer of pad layer if it exists
    """
    if node.type == 'Pad':
        if len(node.input_anchors) == 0:
            return node
        consumer_input = node.input_anchors[0]
        peer_output_anchor = consumer_input.get_peer_output_anchor()
        if peer_output_anchor is None:
            return node
        node = peer_output_anchor.node
    return node


def is_graph_input_node(node):
    if node.type != 'graph_anchor' or len(node.output_anchors) <= 0:
        return False
    if len(node.output_anchors[0].get_peer_input_anchor()) == 0:
        return False
    return True


def is_offline_input_anchor(in_anchor):
    peer_output_anchor = in_anchor.get_peer_output_anchor()
    if peer_output_anchor is None:
        return False
    if peer_output_anchor.node.type in OFFLINE_OPTIMIZE_LAYER_TYPES:
        return True
    if not is_valid_anchor(peer_output_anchor):
        return True
    return False


def get_offline_optimize_index(peer_node):
    for input_anchor in peer_node.input_anchors:
        if input_anchor.index < 3:
            continue
        peer_output_anchor = input_anchor.get_peer_output_anchor()
        if peer_output_anchor is None:
            continue
        if peer_output_anchor.node.type == 'graph_anchor' or \
                peer_output_anchor.node.type == 'ConstantOfShape' or \
                    peer_output_anchor.node.type == 'AscendQuant':
            return input_anchor.index - 1
    return 0
