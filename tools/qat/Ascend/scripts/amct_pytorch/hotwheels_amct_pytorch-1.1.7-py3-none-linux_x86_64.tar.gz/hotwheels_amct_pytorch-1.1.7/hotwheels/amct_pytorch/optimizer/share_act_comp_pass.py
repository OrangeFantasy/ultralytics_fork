#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Share the ActQAT layer and parameters.

"""

from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig as \
    Configuration
from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass

from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_ONNX_TYPES
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import NO_WEIGHT_RETRAIN_MODULE_TYPES
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.custom_op.utils import down_skip_pad_anchor
from hotwheels.amct_pytorch.configuration.check import GraphChecker


class ShareActCompPass(BaseFusionPass):
    """
    Function: Share the ActQAT layer and parameters.
    APIs: match_pattern, do_pass
    """

    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.conf = Configuration()
        self.op_group_map = {}
        self.group_info = {}
        self.group_num = 0

    @staticmethod
    def get_object_module(model, main_module_names):
        """
        Function: get proper object module
        Parameters: model: torch.nn.Module, the model to be modified. if it's
                        None, the graph will be modified.
                    main_module_names: group info
        Return: None
        """
        for model_item in model.named_modules():
            for main_module_item in main_module_names:
                if model_item[0] in main_module_item:
                    return main_module_item
        raise RuntimeError('get object module %s from model failed' % main_module_names)

    def match_pattern(self, node):
        """
        Function: Match pattern of single output multi reference structure
            in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if not GraphChecker.check_onnx_quantize_type(node) and\
                not GraphChecker.check_onnx_quantize_type_without_weight(node):
            return False
        if not self.conf.quant_enable(node.name):
            return False

        output_anchor = node.get_input_anchor(0).get_peer_output_anchor()
        if output_anchor.node.type == 'Pad':
            if len(output_anchor.node.input_anchors) > 0:
                output_anchor = output_anchor.node.get_input_anchor(0). \
                    get_peer_output_anchor()
        if len(output_anchor.get_peer_input_anchor()) <= 1:
            return False

        lgroups = []
        for peer_input_anchor in output_anchor.get_peer_input_anchor():
            peer_input_anchor = down_skip_pad_anchor(peer_input_anchor)
            consumer = peer_input_anchor.node
            idx = peer_input_anchor.index
            if consumer.type not in (QUANTIZABLE_ONNX_TYPES +
                                     NO_WEIGHT_QUANT_ONNX_TYPES) or not \
                    self.conf.quant_enable(consumer.name):
                continue
            consumer_conf = self.conf.get_quant_config()[consumer.name]
            if consumer_conf['retrain_data_config'][idx]['num_bits'] == -1:
                continue
            for l_g in lgroups:
                member_name = self.group_info.get(l_g).get('members')[0][0]
                member_idx = self.group_info.get(l_g).get('members')[0][1]
                member_conf = self.conf.get_quant_config()[member_name]
                # if already has group
                if consumer_conf['retrain_data_config'][idx] == \
                        member_conf['retrain_data_config'][member_idx]:
                    self.op_group_map[(consumer.name, idx)] = l_g
                    self.group_info.get(l_g).get('members').append(
                        (consumer.name, idx))
                    break
            if (consumer.name, idx) not in self.op_group_map.keys():
                # build new group
                self.group_num += 1
                self.group_info[self.group_num] = {}
                group_content = self.group_info.get(self.group_num)
                group_content['done'] = False
                group_content['members'] = []
                self.op_group_map[(consumer.name, idx)] = self.group_num
                group_content['members'].append((consumer.name, idx))
                lgroups.append(self.group_num)
        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Share the ActQAT layer and parameters.
        Parameters: graph: graph structure
                    object_node: node to process
                    model: torch.nn.Module, the model to be modified. if it's
                        None, the graph will be modified.
        Return: None
        """
        object_node_name = object_node.name
        model_helper = ModuleHelper(model)
        object_module = model_helper.get_module(object_node_name)

        for input_anchor in object_node.input_anchors:
            idx = input_anchor.index
            if (object_node_name, idx) not in self.op_group_map.keys():
                continue

            group_num = self.op_group_map.get((object_node.name, idx))
            if self.group_info.get(group_num).get('done'):
                continue

            main_module_names = self.group_info.get(group_num).get(
                'members')
            if (object_node_name, idx) not in main_module_names:
                continue

            # The module used to share should be the first layer in 
            # named_modules
            main_module_name, idx = ShareActCompPass.get_object_module(
                model, main_module_names)

            object_module = model_helper.get_module(main_module_name)
            for group_info_key in self.group_info.get(group_num).get(
                    'members'):
                if main_module_name == group_info_key[0]:
                    continue
                replaced_module = model_helper.get_module(group_info_key[0])
                if type(replaced_module).__name__ in \
                    NO_WEIGHT_RETRAIN_MODULE_TYPES:
                    retrain_module = getattr(replaced_module, 'retrain_module%d' % group_info_key[1])
                    retrain_module.update_shared_module(object_module, idx)
                else:
                    replaced_module.update_shared_module(object_module, idx)
                LOGGER.logd('Share activation module of {} to activation '
                                'module of {}'.format(group_info_key[0],
                                                      main_module_name))
            self.group_info.get(group_num)['done'] = True

        LOGGER.logd(
            "Share ActivationQAT module to '{}' "
            "success!".format(object_node.name), 'ShareActCompPass')
