/*
 * Copyright (c) CompanyNameMagicTag
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief quant head file
 *
 * @file quant.h
 *
 * @version 1.0
 */

#ifndef QUANT_H
#define QUANT_H
#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>
/* *
 * @ingroup quantize lib
 * @brief: error code.
 */
const int SUCCESS = 0x00000000;
const int GENERIC_ERROR = 0xFFFF0000;
const int BAD_FORMAT_ERROR = 0xFFFF0005;
const int BAD_PARAMETERS_ERROR = 0xFFFF0006;
const int OUT_OF_MEMORY_ERROR = 0xFFFF000C;
const int SHORT_BUFFER_ERROR = 0xFFFF0010;
const int NOT_SUPPORT_ERROR = 0xFFFF0011;
const int CUDA_ERROR = 0xFFFF0012;

const unsigned int NUM_BITS_QUANT = 8;
const unsigned int BINARY_BASE = 2;
const unsigned int MIN_NUM_BITS = 2;
const unsigned int MAX_NUM_BITS = 16;

const unsigned int MIN_SHIFT_BIT = 1;
const unsigned int MAX_SHIFT_BIT = 16;
const unsigned int MAX_INT = 2147483647;
constexpr float DIV_HALF_VAL = 2.0;
const int EVEN = 2;

enum InitAlgo {
    INIT_ALG_UNIFORM = 0,
    INIT_ALG_GAUSSIAN = 1,
    INIT_ALG_D2_SAMPLING = 2
};

using Status = int;

#define CHECK_INT_OVERFLOW(data)       \
    if (data > MAX_INT) {              \
        LOG(ERROR) << "int overflow."; \
    }


// CUDA: grid stride looping
#define CUDA_KERNEL_LOOP(i, n) for (int i = blockIdx.x * blockDim.x + threadIdx.x; i < (n); i += blockDim.x * gridDim.x)

// CUDA: use 512 threads per block
const int CAFFE_CUDA_NUM_THREADS = 512;

// CUDA: number of blocks for threads.
inline int CAFFE_GET_BLOCKS(const int N)
{
    return (N + CAFFE_CUDA_NUM_THREADS - 1) / CAFFE_CUDA_NUM_THREADS;
}

/* *
 * @ingroup quantize lib
 * @brief: float data array and length.
 */
struct FloatData {
    unsigned int length;
    float *data;
};

/* *
 * @ingroup quantize lib
 * @brief: float data array and length.
 */
struct CharData {
    unsigned int length;
    char *data;
};

/* *
 * @ingroup quantize lib
 * @breif: clip index and quant bits.
 */
struct ClipInfo {
    unsigned int index;
    unsigned int QUANT_BITS;
};

/* *
 * @ingroup quantize lib
 * @brief: int data array and length.
 */
struct IntData {
    unsigned int length;
    int *data;
};

/* *
 * @ingroup quantize lib
 * @brief: Params for Arq Quantiation.
 */
struct ArqParam {
    unsigned int numBits;
    bool channelWise;
    bool withOffset;
};

/* *
 * @ingroup quantize lib
 * @brief: Params for Ifmr Quantiation.
 */
struct IfmrParam {
    unsigned int calibration;
    unsigned int numBits;
    bool withOffset;
    bool needDump;
    float startRatio;
    float endRatio;
    float step;
    float maxPercentile;
    float minPercentile;
};


/* *
 * @ingroup quantize lib
 * @brief: Params for Ifmr Quantiation
 */
template <class T> struct MaxMinValue {
    T maxValue;
    T minValue;
};

/* *
 * @ingroup quantize lib
 * @brief Param for NUQ
 */
struct NuqParam {
    unsigned int numSteps;
    bool withOffset;
    unsigned int numIter;
};

/* *
 * @ingroup quantize lib
 * @brief Param for SNQ
 */
struct SnqParam {
    bool channelWise;
    unsigned int maxIter;
    double minDistance;
    int initAlgo;
};

/* *
 * @ingroup quantize lib
 * @brief: Ifmr Quantization Function.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] ifmrParam: ifmr quant param.
 * @param [in|out] scale: scale data.
 * @param [in|out] offset: offset data.
 * @return succ/fail
 */
template <class T>
int IfmrQuant(T *data, unsigned int length, IfmrParam ifmrParam, FloatData scale, IntData offset);

template <class T>
int IfmrQuant_gpu(T *deviceData, T *hostDatadata,
    unsigned int length, IfmrParam ifmrParam, FloatData scale, IntData offset);

int SearchN_gpu(std::vector<std::vector<double>> &storedData, std::vector<double> &deqScale, std::vector<int> &bestN);

int SearchN_gpu(std::vector<std::vector<float>> &storedData, std::vector<float> &deqScale, std::vector<int> &bestN);

void SearchShitBit(std::vector<std::vector<float>> &storedData, std::vector<float> &deqScale, std::vector<int> &bestN);

void SearchShitBit(std::vector<std::vector<double>> &storedData, std::vector<double> &deqScale,
    std::vector<int> &bestN);

/* *
 * @ingroup quantize lib
 * @brief: Switch the first and second axis
 * @param: [in|out] data: flatten input data
 * @param: [in] length: the length of data
 * @param: [in|out] shape: the shape of data
 */
template <class T> void TransposeAB(T *data, int length,
    std::vector<int> &shape); 

/* *
 * @ingroup quantize lib
 * @brief: Check whether the clip value is reasonable
 * @param: [in|out] clipMax: the new clip max value
 * @param: [in|out] clipMin: the new clip min value
 * @param: [in|out] clipMaxPre: last clip max value
 * @param: [in|out] clipMinPre: last clip min value
 */
template <class T> bool ClipCheck(T *clipMax, T *clipMin, T &clipMaxPre, T &clipMinPre);

/* *
 * @ingroup quantize lib
 * @brief: Universal Linear Quantization on Activations
 * @param [in|out] data: input data
 * @param [in] length: input data length
 * @param [in] scale: scale data
 * @param [in] offset: offset data
 */
template <class T>
void Ulq(T *data, const unsigned int length, FloatData scale, IntData offset, const unsigned int quantBitNum);

/* *
 * @ingroup quantize lib
 * @brief: ULQ gradient calculation
 * @param: [in] bottomData: bottom data
 * @param: [in] topDiff: top diff
 * @param: [in] length: the length of data
 * @param: [in] clip: a vector of clip_max, clip_min, clip_max_ori, clip_min_ori
 * @return: vector<double> a vector of clip_max_diff and clip_min_diff
 */
template <class T>
std::vector<T> UlqDiff(const T *bottomData, const T *topDiff, const unsigned int length, std::vector<T> clip,
    const unsigned int quantBitNum);

int ActQuantForwardGpu(const int count, const double *bottomData, double *topData, double *clipMaxGpu,
    double *clipMinGpu, bool fixedMin, int quantBitNum);

int ActQuantForwardGpu(const int count, const float *bottomData, float *topData, float *clipMaxGpu, float *clipMinGpu,
    bool fixedMin, int quantBitNum);

int UlqDiffGpu(const int count, const float *bottomData, float *bottomDiff, const float *topDiff,
    const float *clipMaxGpu, const float *clipMinGpu, float &diffMaxCpuRef, float &diffMinCpuRef, int quantBitNum);

int UlqDiffGpu(const int count, const double *bottomData, double *bottomDiff, const double *topDiff,
    const double *clipMaxGpu, const double *clipMinGpu, double &diffMaxCpuRef, double &diffMinCpuRef, int quantBitNum);

/* *
 * @ingroup quantize lib
 * @brief: Arq Quantization Function.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] arqParam: arq quant param.
 * @param [in|out] scale: scale data.
 * @param [in|out] offset: offset data.
 * @return succ/fail
 */
template <class T> int ArqQuant(T *data, unsigned int length, ArqParam arqParam, FloatData scale, IntData offset);

/* *
 * @ingroup quantize lib
 * @brief: Arq Quantization Function.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] arqParam: arq quant param.
 * @param [in] scale: scale data.
 * @param [in] offset: offset data.
 * @param [out] int8Data: output int8 data.
 * @return succ/fail
 */
template <class T>
int ArqQuantReal(T *data, unsigned int length, ArqParam arqParam, FloatData scale, IntData offset, char *int8Data);
/* *
 * @ingroup quantize lib
 * @brief: Arq Quantization Function.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] arqParam: arq quant param.
 * @param [in|out] scale: scale data.
 * @param [in|out] offset: offset data.
 * @return succ/fail
 */
template <class T> int ArqQuantGPU(T *data, unsigned int length, ArqParam arqParam, FloatData scale, IntData offset);

template <class Dtype>
int ArqQuantRetrainGPU(Dtype *devData, unsigned int length, ArqParam arqParam, FloatData scale, IntData offset);
/* *
 * @ingroup quantize lib
 * @brief: Arq Quantization Function.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] arqParam: arq quant param.
 * @param [in] scale: scale data.
 * @param [in] offset: offset data.
 * @param [out] int8Data: output int8 data.
 * @return succ/fail
 */
template <class T>
int ArqQuantRealGPU(T *data, unsigned int length, ArqParam arqParam, FloatData scale, IntData offset, char *int8Data);

/* *
 * @ingroup quantize lib
 * @brief: Check Arq Quantization Inputs Params.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] arqParam: arq quant param.
 * @param [in] scale: scale data.
 * @param [in] offset: offset data.
 * @return succ/fail
 */
template <typename Dtype>
Status CheckArqQuantParams(const Dtype *data, unsigned int length, ArqParam arqParam, FloatData scale, IntData offset);

template <typename Dtype>
Status CheckSnqCalibrationParams(const Dtype *data, const unsigned int length, const SnqParam snqParam,
    const FloatData scale, const CharData cluster);

template <typename Dtype>
Status CheckSnqInferenceParams(const Dtype *data, const unsigned int length, const FloatData scale,
    const CharData cluster, const char *destData);

template <typename Dtype>
Status CheckCommonParams(const Dtype *data, const unsigned int length,
    const FloatData scale, const CharData cluster);

#ifdef __cplusplus
extern "C" {
#endif

/* *
 * @ingroup quantize lib
 * @brief: Arq Quantization Function.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] arqParam: arq quant param.
 * @param [in|out] scale: scale data.
 * @param [in|out] offset: offset data.
 * @return succ/fail
 */
int ArqQuantDoublePython(double *data, unsigned int length, ArqParam arqParam, FloatData scale, IntData offset);

/* *
 * @ingroup quantize lib
 * @brief: Arq Quantization Function.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] scale: scale data.
 * @param [in] offset: offset data.
 * @param [in] numBits: bit number to quantize.
 * @param [out] int8Data: output int8 data.
 * @return succ/fail
 */
int QuantRealDoublePython(double *data, unsigned int length, FloatData scale, IntData offset, unsigned int numBits,
    char *int8Data);
/* *
 * @ingroup quantize lib
 * @brief: Arq Quantization Function.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] arqParam: arq quant param.
 * @param [in|out] scale: scale data.
 * @param [in|out] offset: offset data.
 * @return succ/fail
 */
int ArqQuantDoublePythonGPU(double *data, unsigned int length, ArqParam arqParam, FloatData scale, IntData offset);

/* *
 * @ingroup quantize lib
 * @brief: Arq Quantization Function.
 * @param [in] data: input data.
 * @param [in] length: inputs data length.
 * @param [in] scale: scale data.
 * @param [in] offset: offset data.
 * @param [in] numBits: bit number to quantize.
 * @param [out] int8Data: output int8 data.
 * @return succ/fail
 */
int QuantRealDoublePythonGPU(double *data, unsigned int length, FloatData scale, IntData offset, unsigned int numBits,
    char *int8Data);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] data: input data
 * @param [in] length: input data length
 * @param [in] snqParam: snq parameters
 * @param [in] scale: scale data
 * @param [in] cluster: cluster data
 * @return [out] success/fail
 */
Status SnqQuantDoublePython(double *data, const unsigned int length, const SnqParam snqParam, FloatData scale,
    CharData cluster);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] data: input data
 * @param [in] length: input data length
 * @param [in] scale: scale data
 * @param [in] cluster: cluster data
 * @param [in] int4Data: output int4 data
 * @return [out] success/fail
 */
Status SnqQuantRealDoublePython(const double *data, const unsigned int length, const FloatData scale,
    const CharData cluster, char *int4Data);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] int4Data: input data
 * @param [in] length: input data length
 * @param [in] scale: scale data
 * @param [in] cluster: cluster data
 * @param [in] int8Data: output int8 data
 * @return [out] success/fail
 */
Status SnqDeQuantPython(const char *int4Data, const unsigned int length, const FloatData scale,
    const CharData cluster, char *int8Data);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] data: input data
 * @param [in] length: input data length
 * @param [in] snqParam: snq parameters
 * @param [in] scale: scale data
 * @param [in] cluster: cluster data
 * @return [out] success/fail
 */
Status SnqQuantDoublePythonGPU(double *data, const unsigned int length, const SnqParam snqParam, FloatData scale,
    CharData cluster);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] data: input data
 * @param [in] length: input data length
 * @param [in] scale: scale data
 * @param [in] cluster: cluster data
 * @param [in] int4Data: output int4 data
 * @return [out] success/fail
 */
Status SnqQuantRealDoublePythonGPU(const double *data, const unsigned int length, const FloatData scale,
    const CharData cluster, char *int4Data);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] int4Data: input data
 * @param [in] length: input data length
 * @param [in] scale: scale data
 * @param [in] cluster: cluster data
 * @param [in] int8Data: output int8 data
 * @return [out] success/fail
 */
Status SnqDeQuantPythonGPU(char *int4Data, const unsigned int length, const FloatData scale,
    const CharData cluster, char *int8Data);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] data: input data
 * @param [in] length: input data length
 * @param [in] nuqParam: nuq parameters
 * @param [in] scale: scale data
 * @param [in] offset: offset data
 * @return [out] success/fail
 */
int NuqQuantPython(double *data, unsigned int length, NuqParam nuqParam, FloatData scale, IntData offset);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] data: input data
 * @param [in] length: input data length
 * @param [in] scale: scale data
 * @param [in] offset: offset data
 * @param [out] int8Data: output int8 data
 * @return [out] success/fail
 */
int NuqQuantRealPython(double *data, unsigned int length, FloatData scale, IntData offset, char *int8Data);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] data: input data
 * @param [in] length: input data length
 * @param [in] nuqParam: nuq parameters
 * @param [in] scale: scale data
 * @param [in] offset: offset data
 * @return [out] success/fail
 */
int NuqQuantPythonGPU(double *data, unsigned int length, NuqParam nuqParam, FloatData scale, IntData offset);

/* *
 * @ingroup quantize lib
 * @brief: Non-uniform Quantization Function
 * @param [in] data: input data
 * @param [in] length: input data length
 * @param [in] scale: scale data
 * @param [in] offset: offset data
 * @param [out] int8Data: output int8 data
 * @return [out] success/fail
 */
int NuqQuantRealPythonGPU(double *data, unsigned int length, FloatData scale, IntData offset, char *int8Data);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* QUANT_H */
