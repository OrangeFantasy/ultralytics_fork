#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

CaliQuantLSTM module and Function

"""
import torch
from hotwheels.amct_pytorch.custom_op.cali_quant.cali_quant_multi_input \
    import CaliQuantMultiInput


class CaliQuantLSTM(CaliQuantMultiInput):
    """
    Function: Customized torch.nn.Module of the LSTM calibration operator.
    APIs: forward
    """
    def __init__(self,
                layer_name,
                sub_module,
                act_config):
        super(CaliQuantLSTM, self).__init__(layer_name,
                sub_module,
                act_config)

    def cali_quant(self, *inputs):
        hx = None
        for index, input_item in enumerate(inputs):
            if type(input_item).__name__ == 'tuple':
                # lstm input is (input, (hx, cx))
                hx, _ = input_item
                self.cali_quant_common(hx, index, self.ifmr_param[index])
            if type(input_item).__name__ != 'Tensor':
                continue
            ifmr_param = self.ifmr_param[index]
            self.cali_quant_common(input_item, index, ifmr_param)

        output = self.sub_module(*inputs)
        if hx is None:
            _, (hx, _) = output
            self.cali_quant_common(hx, 1, self.ifmr_param[1])
        return output


