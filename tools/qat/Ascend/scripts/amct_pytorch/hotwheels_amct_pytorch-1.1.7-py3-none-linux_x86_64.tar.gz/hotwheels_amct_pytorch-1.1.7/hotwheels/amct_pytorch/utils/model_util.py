#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils for torch.nn.module

"""
import copy
import torch # pylint: disable=E0401

from torch.fx import symbolic_trace, GraphModule
from torch.fx.proxy import TraceError
from hotwheels.amct_pytorch.utils.vars import AMCT_OPERATIONS
from hotwheels.amct_pytorch.utils.vars import AMCT_RETRAIN_OPERATIONS
from hotwheels.amct_pytorch.utils.vars import CALI_QUANT_MODULE_TYPES
from hotwheels.amct_pytorch.utils.vars import ONNX_SPLIT_OP_TYPE
from hotwheels.amct_pytorch.utils.log import LOGGER


class ModuleHelper():
    """
    Funtion: Helper for torch.nn.module
    APIS: get_module, get_parent_module
    """
    def __init__(self, model):
        ''' init function '''
        self.named_module_dict = {}
        for name, mod in model.named_modules():
            self.named_module_dict[name] = mod

    @staticmethod
    def deep_copy(model):
        """deepcopy a model """
        try:
            new_model = copy.deepcopy(model)
            return new_model
        except Exception as exception:
            raise RuntimeError("The model cannot do copy.deepcopy, "
                               "exception is: {}".format(exception)) from exception

    @staticmethod
    def check_model_type(model):
        if isinstance(model, GraphModule):
            raise RuntimeError("Model should be of type torch.nn.Module, current is of type GraphModule!")
    
    @staticmethod
    def check_model_traceable(model):
        try:
            symbolic_trace(model)
        except TraceError as exception:
            raise RuntimeError('Model should be symbolically traceable with torch.fx!') from exception
        except NameError as exception:
            raise RuntimeError("Please make sure all modules used in model forward function have been "
                "initialized in model __init__ method!") from exception

    @staticmethod
    def check_is_training_model(model):
        if not model.training:
            raise RuntimeError("Model should be of training status!")
    
    @staticmethod
    def check_is_eval_model(model, target_status='train'):
        if model.training:
            raise RuntimeError("Model should be of eval status!")

    @staticmethod
    def check_forward_iterations(model):
        module_helper = ModuleHelper(model)
        for name, module in module_helper.named_module_dict.items():
            if type(module).__name__ in CALI_QUANT_MODULE_TYPES and\
                    module.cur_batch < module.ifmr_param[0].get('batch_num'):
                raise RuntimeError(f'number of iterations of model forward is not same with batch_num actually,'
                                   f' module name: {name}')

    def get_module(self, name):
        ''' get a module from name'''
        module = self.named_module_dict.get(name)
        if module is None:
            raise RuntimeError("module %s not in model." % (name))
        return module

    def get_parent_module(self, name):
        ''' get parent module from name'''
        if name == '':
            raise RuntimeError("model has no parent module.")

        parent_name = '.'.join(name.split('.')[:-1])
        parent_module = self.named_module_dict.get(parent_name)
        if parent_module is None:
            raise RuntimeError("module %s not in model." % (parent_name))
        return parent_module

    def check_amct_op(self):
        """ Check all the layers whose type is in AMCT_OPERATIONS in model
        """
        amct_layers = {}
        for name in self.named_module_dict:
            mod_type = type(self.named_module_dict.get(name)).__name__
            if mod_type in AMCT_OPERATIONS:
                amct_layers[name] = mod_type

        if amct_layers:
            raise RuntimeError("The model cannot be quantized for following "\
                "quant layers are in the model %s" % (amct_layers))

    def check_amct_retrain_op(self):
        """ Check all the layers whose type is in AMCT-RETRAIN_OPERATIONS in
            model
        """
        amct_retrain_layers = {}
        for name in self.named_module_dict:
            mod_type = type(self.named_module_dict.get(name)).__name__
            if mod_type in AMCT_RETRAIN_OPERATIONS:
                amct_retrain_layers[name] = mod_type

        if not amct_retrain_layers:
            raise RuntimeError("The model cannot be quantized because it is "\
                "not a model after quantitative retraining.")

    def check_op_split(self):
        for name, mod in self.named_module_dict.items():
            if isinstance(mod, ONNX_SPLIT_OP_TYPE):
                LOGGER.logw("It is recommended to split module {} manually"
                            " following onnx file exported for best performance".format(name))


def load_pth_file(model, pth_file, state_dict_name):
    """
    Function: load pth file to model
    Inputs:
        model: user model
        pth_file: parameters file
        state_dict_name: parameters state name
    Outputs:
        model: model loaded parameters
    """
    checkpoint = torch.load(
        pth_file, map_location=torch.device('cpu')) # pylint: disable=E1101
    if state_dict_name:
        if checkpoint.get(state_dict_name):
            state_dict = checkpoint[state_dict_name]
        else:
            raise KeyError("The pth_file has no key name: "
                           "{}".format(state_dict_name))
    else:
        state_dict = checkpoint
    pth_parallel = \
        all([state.startswith('module.') for state in state_dict.keys()])
    if pth_parallel:
        new_state_dict = dict()
        for key, value in state_dict.items():
            new_state_dict[key[7:]] = value
        model.load_state_dict(new_state_dict)
    else:
        model.load_state_dict(state_dict)

    return model
