#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Add fakequant "quant" pattern and "antiquant" pattern in the graph

"""
from onnx import onnx_pb # pylint: disable=E0401
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.utils.onnx_initializer_util import \
    TensorProtoHelper
from hotwheels.amct_pytorch.utils.attrs_list import \
    ATTR_NODE_EQUIVALENT_OBJECT_LAYER


def add_fakequant(graph, layer_name, quant_param, object_node):
    """
    Function: Add fakequant "quant" pattern in graph
    """
    ori_object_name = object_node.get_attr('object_node')
    layer_name = '.'.join([layer_name, 'fakequant'])
    # add scale, offset, clip_min, clip_max
    scale_node = graph.add_node(_construct_fakequant_scale(layer_name, quant_param.scale))
    offset_node = graph.add_node(
        _construct_fakequant_offset(layer_name, quant_param.offset))
    min_node = graph.add_node(
        _construct_fakequant_clip_min(layer_name, -2**(quant_param.num_bits - 1)))
    max_node = graph.add_node(
        _construct_fakequant_clip_max(layer_name, 2**(quant_param.num_bits - 1) - 1))
    # add mul
    mul_node = graph.add_node(_construct_fakequant_mul(layer_name))
    mul_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, ori_object_name)
    # add round
    round_node = graph.add_node(_construct_fakequant_round(layer_name))
    round_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, ori_object_name)
    # add add
    add_node = graph.add_node(_construct_fakequant_add(layer_name))
    add_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, ori_object_name)
    # add clip
    clip_node = graph.add_node(_construct_fakequant_clip(layer_name))
    clip_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, ori_object_name)
    # add sub
    sub_node = graph.add_node(_construct_fakequant_sub(layer_name))
    sub_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, ori_object_name)

    # add links
    graph.add_edge(scale_node, 0, mul_node, 1)
    graph.add_edge(mul_node, 0, round_node, 0)
    graph.add_edge(round_node, 0, add_node, 0)
    graph.add_edge(offset_node, 0, add_node, 1)
    graph.add_edge(add_node, 0, clip_node, 0)
    graph.add_edge(min_node, 0, clip_node, 1)
    graph.add_edge(max_node, 0, clip_node, 2)
    graph.add_edge(clip_node, 0, sub_node, 0)
    graph.add_edge(offset_node, 0, sub_node, 1)

    return mul_node, sub_node


def add_fake_antiquant(graph, layer_name, scale, object_node):
    """
    Function: Add fakequant "antiquant" pattern in graph
    """
    ori_object_name = object_node.get_attr('object_node')
    layer_name = '.'.join([layer_name, 'fake_antiquant'])
    # add scale
    scale_node = graph.add_node(_construct_fakequant_scale(layer_name, scale))
    scale_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, ori_object_name)
    # add mul
    mul_node = graph.add_node(_construct_fakequant_mul(layer_name))
    scale_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, ori_object_name)

    # add links
    graph.add_edge(scale_node, 0, mul_node, 1)

    return mul_node


def _construct_fakequant_mul(layer_name):
    ''' construct mul op'''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'mul_quant_layer'])
    node_proto.op_type = 'Mul'
    node_proto.doc_string = 'mul of the Fakequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'mul', 'input0']),
        '.'.join([layer_name, 'scale', 'output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'mul', 'output0'])])

    return node_proto


def _construct_fakequant_round(layer_name):
    ''' construct round op'''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'round_quant_layer'])
    node_proto.op_type = 'Round'
    node_proto.doc_string = 'round of the Fakequant'
    node_proto.input.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'mul', 'output0'])])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'round', 'output0'])])

    return node_proto


def _construct_fakequant_add(layer_name):
    ''' construct add op'''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'add_quant_layer'])
    node_proto.op_type = 'Add'
    node_proto.doc_string = 'add of the Fakequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'round', 'output0']),
        '.'.join([layer_name, 'offset', 'output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'add', 'output0'])])

    return node_proto


def _construct_fakequant_clip(layer_name):
    ''' construct clip op'''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'clip_quant_layer'])
    node_proto.op_type = 'Clip'
    node_proto.doc_string = 'clip of the Fakequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'add',
                  'output0']), '.'.join([layer_name, 'min_val', 'output0']),
        '.'.join([layer_name, 'max_val', 'output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'clip', 'output0'])])

    return node_proto


def _construct_fakequant_sub(layer_name):
    ''' construct sub op'''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'sub_quant_layer'])
    node_proto.op_type = 'Sub'
    node_proto.doc_string = 'sub of the Fakequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'sub', 'input0']),
        '.'.join([layer_name, 'sub', 'input1'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'sub', 'output0'])])

    return node_proto


def _construct_fakequant_scale(layer_name, scale):
    ''' construct scale op'''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'scale_quant_layer'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'scale of the Fakequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'scale', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([scale], 'FLOAT')

    return node_proto


def _construct_fakequant_offset(layer_name, offset):
    ''' construct offset op'''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'offset_quant_layer'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'offset of the Fakequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'offset', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([offset], 'FLOAT')

    return node_proto


def _construct_fakequant_clip_min(layer_name, clip_min):
    ''' construct clip's min op'''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'min_val_quant_layer'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'clip min of the Fakequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'min_val', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([clip_min], 'FLOAT')

    return node_proto


def _construct_fakequant_clip_max(layer_name, clip_max):
    ''' construct clip's max op'''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'max_val_quant_layer'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'clip max of the Fakequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'max_val', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([clip_max], 'FLOAT')

    return node_proto
