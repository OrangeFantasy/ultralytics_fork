/*
 * Copyright (c) CompanyNameMagicTag
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0. You may not use
 * this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief luq algorithm custom op C++ implement
 *
 * @file snq.h
 *
 * @version 1.0
 */

#ifndef SNQ_H
#define SNQ_H

#include <torch/extension.h>
#include "util.h"
#include "quant.h"


std::vector<torch::Tensor> SnqCali(torch::Tensor input, SnqParam snqParam);

#endif /* SNQ_H */
