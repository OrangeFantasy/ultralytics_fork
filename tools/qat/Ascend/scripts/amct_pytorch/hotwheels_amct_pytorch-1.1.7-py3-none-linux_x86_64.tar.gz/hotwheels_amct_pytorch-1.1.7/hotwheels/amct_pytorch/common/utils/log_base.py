# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

log base class

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import logging
import os

from hotwheels.amct_pytorch.common.utils.files import create_empty_file

LOG_FILE_DIR = 'amct_log'

LOGGING_LEVEL_MAP = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR
}


def check_level(level, name):
    """
    Function: Check level
    Parameter: level: log's level to be check
               name: level's name
    """
    if level.upper() not in LOGGING_LEVEL_MAP:
        raise ValueError("%s{'%s'} is invalid, only support %s"
                         % (name, level, list(LOGGING_LEVEL_MAP)))


class LoggerBase():
    """
    Function：Record debug，info，warning，error level log
    API：logd, logi, logw, loge, set_debug_level
    """
    def __init__(self, log_dir, log_name):
        """
        Function：Create logger， console handler and file handler
        Parameter: log_dir: directory of log
                   log_name: name of log
        Return:None
        """
        # create logger
        self.logger = logging.getLogger("Log")
        self.logger.setLevel(logging.DEBUG)
        print_format = "%(asctime)s - %(levelname)s - [AMCT]:%(message)s"
        self.formatter = logging.Formatter(print_format)

        # add console handler
        self.console_handler = logging.StreamHandler()
        self.console_handler.setLevel(logging.INFO)
        self.console_handler.setFormatter(self.formatter)
        self.logger.addHandler(self.console_handler)

        # create log dir and empty log file
        log_dir = os.path.realpath(log_dir)
        self.debug_log_file = os.path.join(log_dir, log_name)
        create_empty_file(self.debug_log_file)

        # add file handler
        self.file_handler = logging.FileHandler(self.debug_log_file, mode='w')
        self.file_handler.setLevel(logging.INFO)
        self.file_handler.setFormatter(self.formatter)
        self.logger.addHandler(self.file_handler)

    def set_debug_level(self, print_level='info', save_level='info'):
        """
        Function：Set debug level
        Parameter: print_level: 'debug', 'info', 'warning', 'error'
                   save_level: 'debug', 'info', 'warning', 'error'
        Return:None
        """
        # entry check
        print_level = print_level.upper()
        save_level = save_level.upper()

        check_level(print_level, 'print_level')
        check_level(save_level, 'save_level')

        self.console_handler.setLevel(LOGGING_LEVEL_MAP[print_level])
        self.file_handler.setLevel(LOGGING_LEVEL_MAP[save_level])

    def logd(self, debug_message, module_name="AMCT"):
        """
        Function：Record debug log
        Parameter: debug_message: debug log
                   module_name: name of module
        Return:None
        """
        self.logger.debug("[%s]: %s", module_name, debug_message)

    def logi(self, info_message, module_name="AMCT"):
        """
        Function：Record info log
        Parameter: info_message: info log
                   module_name: name of module
        Return:None
        """
        self.logger.info("[%s]: %s", module_name, info_message)

    def logw(self, warning_message, module_name="AMCT"):
        """
        Function：Record warning log
        Parameter: warning_message: warning log
              module_name: name of module
        Return:None
        """
        self.logger.warning("[%s]: %s", module_name, warning_message)

    def loge(self, error_message, module_name="AMCT"):
        """
        Function：Record error log
        Parameter: error_message: error log
              module_name: name of module
        Return:None
        """
        self.logger.error("[%s]: %s", module_name, error_message)
