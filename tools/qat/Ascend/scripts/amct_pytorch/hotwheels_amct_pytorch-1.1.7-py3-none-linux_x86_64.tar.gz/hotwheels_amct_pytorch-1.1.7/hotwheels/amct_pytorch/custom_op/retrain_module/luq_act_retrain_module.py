#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

luq retrain Module of quantized retrain

"""

from math import inf
import numpy as np
import torch
from torch.nn.parameter import Parameter
from hotwheels.amct_pytorch.custom_op.luq_retrain.acts_luq_retrain import \
    ActsLuqRetrainFunction
import hotwheels.amct_pytorch.custom_op.amct_pytorch_ops as amct_pytorch_ops
from hotwheels.amct_pytorch.custom_op.utils import copy_tensor
from hotwheels.amct_pytorch.custom_op.utils import tensor
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import MIN_ALPHA
from hotwheels.amct_pytorch.custom_op.retrain_module.act_retrain_module_base \
    import ActRetrainModuleBase
from hotwheels.amct_pytorch.common.utils.vars import WITH_OFFSET

SYM_THRESHOLD = 100


class LuqActRetrainModule(ActRetrainModuleBase):
    """
    Function: Base class module for quantized retrain.
    APIs: __init__, _init_output, forward
    """
    def __init__(self, *args, **kwargs):
        super(LuqActRetrainModule, self).__init__(*args, **kwargs)
        self.acts_sym = torch.tensor(1, dtype=torch.int32)

    @torch.no_grad()
    def init_atc_clipmax(self, inputs):
        if self.act_config['max_init_algo'] == 'mse':
            abs_max = inputs.abs().max()
            cands = torch.linspace(abs_max * 0.5, abs_max * 1.5, 100,
                                device=inputs.device)
            min_err = inf
            best_clip_max = abs_max
            for a in cands:
                y, _, _ = amct_pytorch_ops.acts_luq_retrain_forward(
                    inputs, a, self.act_config['num_bits'], self.acts_sym.data)
                err = torch.norm((inputs - y))
                if err.item() < min_err:
                    min_err = err
                    best_clip_max = a
        else:
            best_clip_max = inputs.abs().max()
        self.acts_clip_max.data.copy_(best_clip_max.data)

    def acts_forward(self, inputs):
        """
        Function: activation quantization function.
        Inputs:
            inputs: data used for calibration in torch.tensor.
        """
        # Obtains symmetry flags based on threshold statistics
        with torch.no_grad():
            if self.cur_batch < SYM_THRESHOLD:
                self.cur_batch += 1
                self.acts_sym.data.fill_(inputs.min() < 0)
            if self.cur_batch == 1:
                self.init_atc_clipmax(inputs)
            # Forward with fake-quantized activations.
            if self.acts_clip_max.min() < MIN_ALPHA:
                LOGGER.logi('CLIP_MAX {} is less than {}!'.format(
                    self.acts_clip_max, MIN_ALPHA))
                ind = self.acts_clip_max.data < MIN_ALPHA
                self.acts_clip_max.data[ind] = MIN_ALPHA
        # judge the with_offset value in config.json to control params of offset in record.txt
        if WITH_OFFSET in self.act_config.keys():
            # if with_offset is false, offset gonna be zero
            self.acts_sym.data.fill_(not self.act_config.get(WITH_OFFSET))
        fakequant_inputs, scale, offset = ActsLuqRetrainFunction.apply(inputs,
            self.acts_clip_max, self.act_config['num_bits'], self.acts_sym.data,
            self.cur_batch)
        with torch.no_grad():
            copy_tensor(self.acts_scale, scale)
            copy_tensor(self.acts_offset, offset)
        return fakequant_inputs

    def _init_output(self):
        # Register quantitative parameters.
        self.register_buffer('cur_batch', tensor(0))
        self.register_parameter('acts_clip_max',
                                Parameter(tensor(1.0, requires_grad=True)))
        self.register_buffer('acts_scale', tensor(np.nan))
        self.register_buffer('acts_offset', tensor(np.nan))