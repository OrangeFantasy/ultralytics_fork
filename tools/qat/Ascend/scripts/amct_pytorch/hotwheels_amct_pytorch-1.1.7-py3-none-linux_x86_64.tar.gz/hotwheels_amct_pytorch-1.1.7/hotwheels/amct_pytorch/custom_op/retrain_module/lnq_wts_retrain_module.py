#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

lnq weight retrain module

"""

import numpy as np
import torch
from hotwheels.amct_pytorch.custom_op.lnq_retrain.lnq_retrain import \
    LnqRetrainFunction
from hotwheels.amct_pytorch.custom_op.utils import tensor
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import MIN_ALPHA
from hotwheels.amct_pytorch.custom_op.retrain_module.wts_retrain_module_base \
    import WtsRetrainModuleBase
from hotwheels.amct_pytorch.custom_op.lnq_retrain.lnq_retrain import \
    lnq_export_param
from hotwheels.amct_pytorch.custom_op.utils import copy_tensor

CLUSTER_SIZE = 272


class LnqWtsRetrainModule(WtsRetrainModuleBase):
    """
    Function: lnq retrain module for quantized retrain.
    APIs: __init__, _init_output, wts_forward, get_weight_scale,
        get_weight_offset, get_weight_param
    """

    def __init__(self, *args, **kwargs):
        super(LnqWtsRetrainModule, self).__init__(*args, **kwargs)
        self.num_tracked_batches = 0

    def wts_forward(self):
        if self.training:
            self.num_tracked_batches += 1
        wts_qat_param = {
            'num_bits': self.wts_config.get('num_bits'),
            'cluster_freq': self.wts_config.get('cluster_freq'),
            'max_iteration': self.wts_config.get('max_iteration'),
            'min_distance': self.wts_config.get('min_distance'),
            'training': self.training,
            'num_tracked_batches': self.num_tracked_batches
        }
        with torch.no_grad():
            if self.wts_clip_max.data[0] < MIN_ALPHA:
                LOGGER.logw('wts_clip_max of layer {} is less than {}'.format
                            (self.common_config['layers_name'][0], MIN_ALPHA))
                self.wts_clip_max.data[0] = MIN_ALPHA
        weights = self.replaced_module.weight
        if self.transpose:
            weights = weights.transpose(0, 1)
        fakequant_weights = LnqRetrainFunction.apply(weights,
                                                    self.wts_clip_max,
                                                    self.centroids,
                                                    wts_qat_param)
        scale_w, params = lnq_export_param(weights, self.wts_clip_max,
            self.centroids)
        if self.transpose:
            fakequant_weights = fakequant_weights.transpose(0, 1)
        with torch.no_grad():
            copy_tensor(self.wts_scales, scale_w)
            copy_tensor(self.params, params)
        return fakequant_weights

    def get_weight_param(self):
        return self.params

    def _init_output(self):
        # Register quantitative parameters.
        self.register_parameter('wts_clip_max', torch.nn.Parameter(
            torch.tensor([self.wts_config['clip_max']])))
        self.register_buffer('wts_scales', tensor([np.nan] * 1))
        self.register_buffer('wts_offsets', tensor([0] * 1))
        self.register_buffer('centroids', torch.linspace(-1.0, 1.0, 16))
        self.register_buffer('params', torch.zeros(CLUSTER_SIZE,
                                                   dtype=torch.uint8))
