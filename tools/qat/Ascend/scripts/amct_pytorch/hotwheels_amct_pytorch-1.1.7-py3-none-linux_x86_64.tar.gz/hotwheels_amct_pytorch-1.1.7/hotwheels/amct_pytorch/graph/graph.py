#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of graph which contains graph topologic info

"""
from onnx import onnx_pb  # pylint: disable=import-error

from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.common.graph_base.graph_base import GraphBase
from hotwheels.amct_pytorch.graph.node import Node
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.utils.vars import OFFLINE_OPTIMIZE_LAYER_TYPES


class Graph(GraphBase):  # pylint: disable=no-member
    """
    Function: Data structure of graph IR
    APIs: add_node, remove_node, net, dump_proto
    """

    def __init__(self, network):
        super().__init__(network)
        self._net = network
        self._init_graph()
        self.topologic_sort()
        self.model = None

    @property
    def net(self):
        """ Return onnx_pb.ModelProto of graph
        """
        return self._net

    def set_name_node(self, node, new_name):
        """set node's name as new_name. """
        LOGGER.logd('set "%s" to "%s"' % (new_name, node.name), 'Graph')
        try:
            target_node = self.get_node_by_name(new_name)
        except RuntimeError:
            LOGGER.logd('"%s" is unique in graph.' % (new_name), 'Graph')
            return
        finally:
            if node.name != new_name:
                node.set_name(self._decorate_node_name(new_name))
        LOGGER.logd('"%s" already exist in graph, may be reused module'
                    '.' % (new_name), 'Graph')
        node.set_attr('is_reuse', True)
        target_node.set_attr('is_reuse', True)

    def remove_mark_node(self, quant_mark_nodes):
        # delete quant mark nodes
        for node in quant_mark_nodes:
            # delete input/output edges
            produce_anchor = node.get_input_anchor(0).get_peer_output_anchor()
            producer = produce_anchor.node
            output_anchor = node.get_output_anchor(0)
            self.remove_edge(producer, produce_anchor.index, node, 0)
            peer_input_anchors = list()
            for input_anchor in output_anchor.get_peer_input_anchor():
                peer_input_anchors.append(input_anchor)
            for peer_input_anchor in peer_input_anchors:
                dst_node = peer_input_anchor.node
                self.remove_edge(node, 0, dst_node, peer_input_anchor.index)
                self.add_edge(producer, produce_anchor.index,
                              dst_node, peer_input_anchor.index)
            self.remove_node(node)

    def add_node(self, node_proto, index=None):
        """
        Function: Add node that constructed from node_proto to graph
        Parameter: None
        Return: Node that be added
        """
        # Set node_id to be unique by decorate_node_name function
        if isinstance(node_proto, onnx_pb.SparseTensorProto):
            if node_proto.HasField('values'):
                node_id = node_proto.values.name
                node_proto.values.name = self._decorate_node_name(node_id)
            elif node_proto.HasField('indices'):
                node_id = node_proto.indices.name
                node_proto.indices.name = self._decorate_node_name(node_id)
            else:
                raise RuntimeError('Cannot find tensor in sparse_initializer')
        else:
            node_id = node_proto.name
            node_proto.name = self._decorate_node_name(node_id)
        # Generate node to graph
        node = Node(self._tail, node_proto)
        if index is None:
            self._nodes.insert(0, node)
        else:
            self._nodes.insert(index, node)
        return node

    def remove_node(self, delete_node):
        """
        Function: Remove data node from graph by name
        Parameter: None
        Return: None
        """
        remove_done = False
        for index, node in enumerate(self._nodes):
            if node == delete_node:
                if isinstance(node.proto, onnx_pb.ValueInfoProto):
                    raise RuntimeError('Cannot remove ValueInfoProto node '
                                       '%s from graph.' % node.name)
                del self._nodes[index]
                remove_done = True
                break
        if not remove_done:
            raise RuntimeError('Remove %s from graph failed, cannot found' % (
                delete_node.name))

    def add_model(self, model):
        """ Add model for graph
        """
        self.model = model

    def dump_proto(self):
        """ Dump all nodes and weights of graph to onnx_pb.ModelProto format
        """
        LOGGER.logi('Doing whole model dump...', module_name='Graph')
        self.topologic_sort()

        net = onnx_pb.ModelProto()
        net.CopyFrom(self._net)
        graph = net.graph  # pylint: disable=E1101
        for node in self._nodes:
            if isinstance(node.proto, onnx_pb.NodeProto):
                node_proto = graph.node.add()  # pylint: disable=E1101
                node_proto.CopyFrom(node.dump_proto())
            elif isinstance(node.proto, onnx_pb.TensorProto):
                tensor = graph.initializer.add()  # pylint: disable=E1101
                tensor.CopyFrom(node.dump_proto())
            elif isinstance(node.proto, onnx_pb.SparseTensorProto):
                sparse = graph.sparse_initializer.add()  # pylint: disable=E1101
                sparse.CopyFrom(node.dump_proto())
            elif isinstance(node.proto, onnx_pb.ValueInfoProto):
                continue
            else:
                raise TypeError("Unexcepted node_proto %s! only [NodeProto, "
                                "TensorProto, SparseTensorProto] are "
                                "supporetd." % (type(node.proto)))
        return net

    def remove_initializer(self, delete_node):
        """
        Function: Remove initializer node from graph
        Parameter: delete_node, the node to be removed
        Return: None
        """
        remove_done = False
        for index, node in enumerate(self._nodes):
            if node == delete_node:
                if not isinstance(node.proto, onnx_pb.TensorProto):
                    raise RuntimeError('Cannot only remove initializer node ' 
                                       'from graph by this api. "%s" is "%s"'
                                       % (node.name, node.type))
                if delete_node.get_output_anchor(0).get_peer_input_anchor():
                    LOGGER.logd('Node "%s" still connect to other node, cannot'
                                'remove it now.' % (delete_node.name))
                    return
                del self._nodes[index]

                initializer_name = node.ori_name
                for i, del_node in enumerate(self._nodes):
                    if isinstance(del_node.proto, onnx_pb.ValueInfoProto) and \
                            del_node.ori_name == initializer_name:
                        del self._nodes[i]

                remove_done = True
                LOGGER.logd('Remove node "%s" from graph success.' %
                            delete_node.name)
                break
        if not remove_done:
            raise RuntimeError('Remove %s from graph failed, cannot found' %
                               delete_node.name)

    def _skip_pad(self, consumer, layer_name):
        '''
        pytorch GlobalAvgPool2d module will be transformed to AveragePool node
        combined with Pad, Pad node should be skipped so the AveragePool layer
        will be matched in pytorch and onnx by its pytorch name
             in_data
                |
               Pad
                |
            AveragePool
                |
        '''
        if len(consumer.output_anchors) <= 0:
            return consumer
        consumer_output = consumer.get_output_anchor(0)
        if len(consumer_output.get_peer_input_anchor()) <= 0:
            return consumer
        self.set_name_node(consumer, '%s_pad' % (layer_name))
        consumer = consumer_output.get_peer_input_anchor()[0].node
        return consumer

    def _skip_transpose(self, consumer, layer_name):
        '''
        LSTM, with batch_fisrt set True, a single LSTM module will be
        transformed to LSTM node combined with Transpose,
        Transpose node should be skipped so the LSTM layer
        will be matched in pytorch and onnx by its pytorch name
            in_data   h0     c0
                |     |      /
            Transpose |     /
                \     |    /
                 \    |   /
                  \   |  /
                    LSTM
        '''
        if len(consumer.output_anchors) <= 0:
            return consumer
        consumer_output = consumer.get_output_anchor(0)
        if len(consumer_output.get_peer_input_anchor()) <= 0:
            return consumer
        if consumer_output.get_peer_input_anchor()[0].node.type == 'LSTM':
            self.set_name_node(consumer, '%s_transpose' % (layer_name))
            consumer = consumer_output.get_peer_input_anchor()[0].node
        return consumer

    def _update_node_names(self):
        # get quantize node name from mark node, and set to itself
        quant_mark_nodes = list()
        for node in self._nodes:
            if node.type != 'QuantIdentity':
                continue
            quant_mark_nodes.append(node)
            attr_helper = AttributeProtoHelper(node.proto)
            layer_name = str(attr_helper.get_attr_value('op_name'),
                             encoding="utf-8")

            output_anchor = node.get_output_anchor(0)
            consumers = []
            for peer_input_anchor in output_anchor.get_peer_input_anchor():
                if peer_input_anchor.node.type in OFFLINE_OPTIMIZE_LAYER_TYPES:
                    continue
                consumer = peer_input_anchor.node
                if consumer.type == 'Pad':
                    consumer = self._skip_pad(consumer, layer_name)

                if consumer.type == 'Transpose':
                    consumer = self._skip_transpose(consumer, layer_name)
                consumers.append(consumer)
            if len(consumers) == 1:
                consumer = consumers[0]
                consumer.set_attr('need_quant', True)
                self.set_name_node(consumer, layer_name)

        self.remove_mark_node(quant_mark_nodes)

    def _init_graph(self):
        output_record = dict()
        # 0. init graph input/output nodes
        self._init_graph_input_node(output_record)
        # 1. parse node proto structure
        self._parse_initializer(output_record)
        self._parse_sparse_initializer(output_record)
        self._parse_node_proto(output_record)
        self._init_graph_output_node(output_record)
        # 2. update the name prefix of ndoes, only node with parameters has
        #    module_name
        self._update_node_names()

        # delete node and initializer in graph
        self._net.graph.ClearField('node')
        self._net.graph.ClearField('initializer')
        self._net.graph.ClearField('sparse_initializer')

    def _init_graph_input_node(self, output_record):
        for input_desc in self._net.graph.input:
            graph_input_node = Node(self._tail, input_desc)
            graph_input_node.add_output_anchor(input_desc.name)
            self._nodes.append(graph_input_node)
            output_record[input_desc.name] = [graph_input_node, 0]

    def _init_graph_output_node(self, output_record):
        for output_desc in self._net.graph.output:
            graph_output_node = Node(self._tail, output_desc)
            graph_output_node.add_input_anchor(output_desc.name)
            self._nodes.append(graph_output_node)
            # Add link to output
            if output_desc.name not in output_record:
                raise ReferenceError('Cannot find tensor %s in model.' % (
                    output_desc.name))
            src_node, src_index = output_record[output_desc.name]
            self.add_edge(src_node, src_index, graph_output_node, 0)

    def _parse_initializer(self, output_record):
        for initializer_proto in self._net.graph.initializer:
            node = Node(self._tail, initializer_proto)
            self._nodes.append(node)
            output_record[node.name] = [node, 0]

    def _parse_sparse_initializer(self, output_record):
        for sparse_initializer_proto in self._net.graph.sparse_initializer:
            node = Node(self._tail, sparse_initializer_proto)
            self._nodes.append(node)
            output_record[node.name] = [node, 0]

    def _parse_node_proto(self, output_record):
        for index, node_proto in enumerate(self._net.graph.node):
            if not node_proto.HasField('name'):
                node_proto.name = 'node_{}'.format(index)
            node = Node(self._tail, node_proto)
            self._nodes.append(node)
            # Add link to output
            for input_anchor in node.input_anchors:
                if input_anchor.name not in output_record:
                    if input_anchor.name == '':
                        continue
                    raise ReferenceError('Cannot find tensor %s in model.'
                                         % (input_anchor.name))
                src_node, src_index = output_record[input_anchor.name]
                self.add_edge(src_node, src_index, node, input_anchor.index)
            for output_anchor in node.output_anchors:
                output_record[output_anchor.name] = [node, output_anchor.index]