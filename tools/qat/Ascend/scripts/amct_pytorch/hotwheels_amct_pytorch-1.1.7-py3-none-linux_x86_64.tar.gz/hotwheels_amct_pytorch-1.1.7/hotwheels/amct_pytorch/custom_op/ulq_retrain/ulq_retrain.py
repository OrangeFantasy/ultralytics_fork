#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

UlqRetrain Function

"""

import torch # pylint: disable=E0401
from torch.autograd import Function # pylint: disable=E0401

import hotwheels.amct_pytorch.custom_op.amct_pytorch_ops as amct_pytorch_ops
from hotwheels.amct_pytorch.custom_op.utils import check_quant_data
from hotwheels.amct_pytorch.custom_op.utils import get_distributed_info


class UlqRetrainFunction(Function):
    """
    Function: Run calibration process for quantization of the given layer.
    APIs: forward
    """
    @staticmethod
    def forward(ctx, # pylint: disable=W0221,R0913,R0914
                inputs, clip_max, clip_min, clip_max_pre, clip_min_pre,
                act_qat_param, cur_batch):
        """
        Function: UlqRetrain foward funtion.
        """
        need_sync, process_group, world_size = get_distributed_info()

        if inputs.is_cuda:
            device_id = inputs.device.index
        else:
            device_id = -1
        # check input data
        check_quant_data(inputs, 'activation')
        ctx.inputs = inputs
        results = amct_pytorch_ops.ulq_retrain_forward( # pylint: disable=E1101
            inputs,
            clip_max,
            clip_min,
            clip_max_pre,
            clip_min_pre,
            device_id,
            act_qat_param['num_bits'],
            act_qat_param['ifmr_init'] and cur_batch == 1,
            act_qat_param['fixed_min'])
        is_quant, outputs, scale, offset, clip_max, clip_min = results
        if is_quant != 0:
            raise RuntimeError("Activation retrain forward with ULQ failed!")

        if need_sync and cur_batch == 1:
            clip_max_all = torch.empty( # pylint: disable=E1101
                world_size, 1, dtype=clip_max.dtype, device=clip_max.device)
            clip_min_all = torch.empty( # pylint: disable=E1101
                world_size, 1, dtype=clip_min.dtype, device=clip_min.device)

            clip_max_l = list(clip_max_all.unbind(0))
            clip_min_l = list(clip_min_all.unbind(0))

            clip_max_all_reduce = torch.distributed.all_gather(
                clip_max_l, clip_max, process_group, async_op=True)
            clip_min_all_reduce = torch.distributed.all_gather(
                clip_min_l, clip_min, process_group, async_op=True)

            # wait on the async communication to finish
            clip_max_all_reduce.wait()
            clip_min_all_reduce.wait()
            clip_max_tmp = clip_max_all.mean()
            clip_min_tmp = clip_min_all.mean()
            clip_max.data.copy_(clip_max_tmp.data)
            clip_min.data.copy_(clip_min_tmp.data)

        ctx.clip_max = clip_max
        ctx.clip_min = clip_min
        ctx.num_bits = act_qat_param['num_bits']

        forwards = (outputs, scale, offset, clip_max, clip_min)
        return forwards

    @staticmethod
    def backward(ctx, # pylint: disable=W0221,R0913
                 grad_outputs, grad_scale, # pylint: disable=W0613
                 grad_offset, grad_max, grad_min): # pylint: disable=W0613
        """
        Function: UlqRetrain backward funtion required by torch
                  torch.autograd.
        """
        res = amct_pytorch_ops.ulq_retrain_backward( # pylint: disable=E1101
            ctx.inputs,
            grad_outputs,
            ctx.clip_max,
            ctx.clip_min,
            ctx.num_bits)
        is_quant, grad_input, grad_acts_clip_max, grad_acts_clip_min = res
        if is_quant != 0:
            raise RuntimeError("Activation retrain backward with ULQ failed!")

        backwards = (grad_input, grad_acts_clip_max, grad_acts_clip_min, \
            None, None, None, None)
        return backwards
