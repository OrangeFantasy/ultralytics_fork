#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

decorator util for check function params type

"""
from inspect import signature
from functools import wraps
from hotwheels.amct_pytorch.utils.vars import NON_INSIST_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import OFFLINE_OPTIMIZE_LAYER_TYPES
from hotwheels.amct_pytorch.utils.vars import ACTIVATION_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import RETRAIN_DATA_CONFIG
from hotwheels.amct_pytorch.utils.vars import QUANT_ENABLE
from hotwheels.amct_pytorch.utils.vars import RETRAIN_ENABLE
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import NODE_WITH_OPTIMIZE_INPUT
from hotwheels.amct_pytorch.custom_op.utils import is_valid_anchor
from hotwheels.amct_pytorch.custom_op.utils import down_skip_pad_anchor
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.model_util import ModuleHelper

__all__ = ['check_params']


def check_params(*type_args, **type_kwargs):
    """decorator util for check function params type """

    def decorate(func):
        """ decorate function. """
        func_sig = signature(func)
        need_param_types = func_sig.bind_partial(*type_args,
                                                 **type_kwargs).arguments

        @wraps(func)
        def wrapper(*args, **kwargs):
            """ decorate wrapper. """
            func_param_types = func_sig.bind(*args, **kwargs)
            for name, value in func_param_types.arguments.items():
                if name in need_param_types:
                    if not isinstance(value, need_param_types[name]):
                        raise TypeError('Func {} argument {} must be {}'.
                                        format(func.__name__, name,
                                               need_param_types[name]))
            return func(*args, **kwargs)

        return wrapper

    return decorate


def check_outputs_consistency(graph, quant_layers, quant_config, is_retrain=False):
    ''' check outputs config consistency of each input anchor'''
    if is_retrain:
        quant_enable = RETRAIN_ENABLE
        data_config = RETRAIN_DATA_CONFIG 
    else:
        quant_enable = QUANT_ENABLE
        data_config = ACTIVATION_QUANT_PARAMS

    def check_outputs_consistency_of_input(output_anchor, config, layer, layer_onnx_name):
        for input_anchor in output_anchor.get_peer_input_anchor():
            if not is_valid_anchor(input_anchor):
                continue
            ori_input_anchor = input_anchor
            input_anchor = down_skip_pad_anchor(input_anchor)
            output_name = input_anchor.node.name
            if ori_input_anchor != input_anchor and \
                ori_input_anchor.node.type == 'Pad' and \
                input_anchor.node.type != 'AveragePool':
                continue
            if input_anchor.node.type in OFFLINE_OPTIMIZE_LAYER_TYPES:
                continue
            #        output_anchor.node
            #             /  \
            #            /    \
            #         node1  output_node(input_anchor.node)
            #          /
            #         /
            #     output_node
            #
            # the input of right output_node would not be quantified,
            # while quant params of output_node(layer) is not in quant_config,
            # which read from config.json. When input_anchor points to
            # output_node show above, do skip checking as follow
            if input_anchor.node.type == 'graph_anchor':
                continue
            index = input_anchor.index
            if output_name not in quant_config.keys() or not \
                    quant_config[output_name][quant_enable] or \
                    quant_config[output_name][data_config][
                        index] != config:
                output_onnx_name = input_anchor.node.ori_name
                raise ValueError('Outputs {}(onnx name: {}) and {}(onnx name: {})'
                                    ' of layer {}(onnx name: {}) should have consistent '
                                    '{}.'.format(output_name, output_onnx_name, layer, 
                                    layer_onnx_name, output_anchor.node.name, output_anchor.node.ori_name,
                                    data_config))

    for layer in quant_layers:
        try:
            node = graph.get_node_by_name(layer)
        except RuntimeError:
            LOGGER.logw('layer {} not in graph, it might exist in training '
                    'mode.'.format(layer))
            continue
        if node.type in RNN_ONNX_TYPES:
            continue

        for in_anchor in node.input_anchors:
            peer_output_anchor = in_anchor.get_peer_output_anchor()
            if peer_output_anchor is None:
                continue
            if peer_output_anchor.node.type in \
                    OFFLINE_OPTIMIZE_LAYER_TYPES:
                continue
            if not is_valid_anchor(peer_output_anchor):
                continue
            if not quant_config[layer].get(quant_enable, False):
                continue
            config = quant_config[layer][data_config][in_anchor.index]
            layer_onnx_name = node.ori_name
            check_outputs_consistency_of_input(peer_output_anchor, config, layer, layer_onnx_name)
            if node.type in NODE_WITH_OPTIMIZE_INPUT:
                break


def check_no_command_layer_consistency(node, quant_config, graph, is_retrain=False):
    '''check quant consistency of no conmmand layer'''
    if node.type not in NON_INSIST_ONNX_TYPES:
        return
    if is_retrain:
        quant_enable = RETRAIN_ENABLE
        data_config = RETRAIN_DATA_CONFIG
    else:
        quant_enable = QUANT_ENABLE
        data_config = ACTIVATION_QUANT_PARAMS
    layer_quant_enable = node.name in quant_config \
                    and quant_config[node.name][quant_enable]
    if layer_quant_enable:
        in_data_config = \
            quant_config[node.name][data_config][0]
    else:
        in_data_config = {}
    for out_anchor in node.output_anchors:
        for in_anchor in out_anchor.get_peer_input_anchor():
            in_anchor = down_skip_pad_anchor(in_anchor)
            out_node = in_anchor.node
            if out_node.type == 'Dropout':
                continue
            if out_node.type in OFFLINE_OPTIMIZE_LAYER_TYPES:
                continue
            index = in_anchor.index
            out_quant_enable = out_node.name in quant_config and quant_config[out_node.name][quant_enable]
            if out_quant_enable:
                out_data_config = \
                    quant_config[out_node.name][data_config][index]
            else:
                out_data_config = {}
            # if quant_config of out_node is empty while out_node is not in origin model, continue
            if out_quant_enable is False and \
                    not ModuleHelper(graph.model).named_module_dict.get(out_node.name):
                continue
            # if out_quant_enable = layer_quant_enable = False, in_data_config = out_data_config = {}, exception would
            # not be raised
            if layer_quant_enable != out_quant_enable \
                    or in_data_config != out_data_config:
                raise ValueError('Layer {} should have consistent '
                                    '{} with no command layer {} .'.
                                    format(out_node.name, data_config, node.name))

