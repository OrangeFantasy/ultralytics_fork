/*
 * Copyright (c) CompanyNameMagicTag
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0. You may not use
 * this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief arq_quant algorithm custom op C++ implement
 *
 * @file interface.h
 *
 * @version 1.0
 */

#ifndef INTERFACE_H
#define INTERFACE_H

#include "arq.h"
#include "ifmr.h"
#include "ulq_retrain.h"
#include "arq_retrain.h"
#include "lnq_retrain.h"
#include "luq_retrain.h"
#include "snq.h"

#endif /* INTERFACE_H */
