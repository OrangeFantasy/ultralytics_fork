# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Information Hepler to cope with different quant related operation

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from hotwheels.amct_pytorch.capacity import CAPACITY
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.utils.rnn_utils import get_rnn_helper
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_ONNX_TYPES


class QuantOpInfo():
    '''
    Find infomation of quant_op.
    '''
    @staticmethod
    def get_scale_shape(node, channel_wise):
        """
        Function: Get the weights' scale's shape of node.
        Inputs:
            node: Node, it's type should be in QUANTIZABLE_ONNX_TYPES.
            channel_wise: a bool, parameter of quantization.
        Returns:
            shape: a list, the shape of scale.
            scale_length : a number, the length of scale.
        """
        if node.type not in (QUANTIZABLE_ONNX_TYPES + NO_WEIGHT_QUANT_ONNX_TYPES):
            raise RuntimeError(
                'Not supported get scale shape from type:%s(%s)' %
                (node.type, node.name))
        if channel_wise and node.type in CAPACITY.get_value(
                'CHANNEL_WISE_ONNX_TYPES'):
            weight_node = node.get_input_anchor(1).\
                get_peer_output_anchor().node
            weight_param = weight_node.proto
            if node.type == 'ConvTranspose':
                # deconv2d
                attr_helper = AttributeProtoHelper(node.proto)
                group = 1
                if attr_helper.has_attr('group'):
                    group = attr_helper.get_attr_value('group')
                length = weight_param.dims[1] * group
            else:
                # conv2D
                length = weight_param.dims[0]
            shape = [length, 1, 1, 1]
        elif node.type in RNN_ONNX_TYPES:
            rnn_helper = get_rnn_helper(node)
            shape = rnn_helper.scale_shape()
            length = rnn_helper.scale_length()
        else:
            shape = []
            length = 1

        return shape, length

    @staticmethod
    def get_quant_index(node):
        """
        Function: get act's index and weight's index of node.
        Inputs:
            node: Node, it's type should be in QUANTIZABLE_ONNX_TYPES.
        Returns:
            act_index: the act's index in inputs of node.
            weight_index: the weight's index in inputs of node.
        """
        if node.type not in QUANTIZABLE_ONNX_TYPES:
            raise RuntimeError("%s is not supported." % (node.type))

        quant_indexs = {
            "Conv": [0, 1, 2],
            "Gemm": [0, 1, 2],
            "MatMul": [0, 1, None],
            'ConvTranspose': [0, 1, 2]
        }

        act_index, weight_index, bias_index = quant_indexs.get(node.type)

        return act_index, weight_index, bias_index

    @staticmethod
    def get_dequant_shape(node):
        """
        Function: Get the dequant scale's shape from node
        Inputs: node: the node te be quantized
        Returns: the shape of dequant scale
        """
        if node.type in ["Conv", "AscendDequant", "ConvTranspose", "LSTM", 
            "RNN", "GRU"]:
            dequant_shape = [1, -1, 1, 1]
        elif node.type in ["Gemm", "MatMul", "AveragePool", "MaxPool", \
            "GlobalMaxPool", "GlobalAveragePool"]:
            dequant_shape = [1, -1]
        else:
            raise RuntimeError("%s is not supported." % (node.type))

        return dequant_shape

    @staticmethod
    def get_weight_node(node):
        '''
        Function: Get quantizable_node's weight node
        Parameters:
            quantizable_node: a node, which is quantizable
        Return:
            weight_param: a node, it's quantizable_node' weight
        '''
        _, weight_index, _ = QuantOpInfo.get_quant_index(node)

        weight_input_anchor = node.get_input_anchor(weight_index)
        weight_param = weight_input_anchor.get_peer_output_anchor().node

        if weight_param.type == 'Transpose':
            weight_input_anchor = weight_param.get_input_anchor(0)
            weight_param = weight_input_anchor.get_peer_output_anchor().node
            node.set_attr('with_weights_trans', True)

        return weight_param
    
    @staticmethod
    def get_rnn_weight_node(node):
        '''
        Function: Get quantizable_lstm_node's weight node
        each onnx node has 3 to 8 inputs
        X (differentiable) : T
        The input sequences packed (and potentially padded) into one 3-D 
        tensor with the shape of `[seq_length, batch_size, input_size]`.

        W (differentiable) : T
        The weight tensor for the gates. Concatenation of `W[iofc]` and 
        `WB[iofc]` (if bidirectional) along dimension 0. The tensor has 
        shape `[num_directions, 4*hidden_size, input_size]`.

        R (differentiable) : T
        The recurrence weight tensor. Concatenation of `R[iofc]` and 
        `RB[iofc]` (if bidirectional) along dimension 0. This tensor 
        has shape `[num_directions, 4*hidden_size, hidden_size]`.

        B (optional, differentiable) : T
        The bias tensor for input gate. Concatenation of `[Wb[iofc], 
        Rb[iofc]]`, and `[WBb[iofc], RBb[iofc]]` (if bidirectional) along 
        dimension 0. This tensor has shape `[num_directions, 8*hidden_size]`.
        Optional: If not specified - assumed to be 0.

        Parameters:
            quantizable_node: a lstm node, which is quantizable
        Return:
            weight_param: a tuple node, it's quantizable_node' weights
        '''
        x_weight_index = 1
        h_weight_index = 2
        bias_index = 3

        x_weight_input_anchor = node.get_input_anchor(x_weight_index)
        h_weight_input_anchor = node.get_input_anchor(h_weight_index)
        bias_input_anchor = node.get_input_anchor(bias_index)

        x_weight_param = x_weight_input_anchor.get_peer_output_anchor().node
        h_weight_param = h_weight_input_anchor.get_peer_output_anchor().node
        bias_peer_output_anchor = bias_input_anchor.get_peer_output_anchor()
        if bias_peer_output_anchor is None:
            bias_param = None
        else:
            bias_param = bias_peer_output_anchor.node

        return x_weight_param, h_weight_param, bias_param

    @staticmethod
    def get_weight_tensor(node):
        '''
        Function: Get quantizable_node's weight node
        Parameters:
            quantizable_node: a node, which is quantizable
        Return:
            weight_param: a node, it's quantizable_node' weight
        '''
        weight_node = QuantOpInfo.get_weight_node(node)
        weight_type = weight_node.type
        if weight_type == 'initializer':
            weight_tensor = weight_node.proto
        elif weight_type == 'Constant':
            attr_helper = AttributeProtoHelper(weight_node.proto)
            weight_tensor = attr_helper.get_attr_value('value')
        else:
            raise RuntimeError(
                "Unexcepted weight's type {} for {}"
                .format(weight_type, node.name))

        return weight_tensor
