#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quant bias from floa32 to int32.

"""
import math
import numpy as np
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import RETRAIN_WEIGHT_CONFIG
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from hotwheels.amct_pytorch.optimizer.bias_quant_pass import BiasQuantPass
from hotwheels.amct_pytorch.utils.rnn_utils import get_rnn_helper


class RNNBiasQuantPass(BiasQuantPass):
    """
    Function: Quant bias from floa32 to int32.
    APIs: match_pattern, do_pass
    """

    def __init__(self, records, is_retrain):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BiasQuantPass.__init__(self, records, is_retrain)

    @staticmethod
    def get_bias(bias_helper, fc_num):
        bias = bias_helper.get_data()
        bias_length = int(bias.size / 2)
        x_bias = bias.reshape(-1)[:bias_length].reshape(fc_num, -1)
        h_bias = bias.reshape(-1)[bias_length:].reshape(fc_num, -1)
        return x_bias, h_bias

    @staticmethod
    def get_weight(x_weight_param, h_weight_param, fc_num):
        x_weight_helper = TensorProtoHelper(x_weight_param.proto)
        h_weight_helper = TensorProtoHelper(h_weight_param.proto)
        x_weight = x_weight_helper.get_data()
        h_weight = h_weight_helper.get_data()
        # weight in lstm has 3 dimensions, 
        # one for layer_num, currently it must be 1
        # second is channels of fc, which must be exactly divided by fc_num
        # third is input size
        if x_weight.shape[1] % fc_num != 0:
            raise RuntimeError('x_weight.shape[1]: {} should can be '
                               'be divisible by {}.'.format(x_weight.shape[1], fc_num))
        if h_weight.shape[1] % fc_num != 0:
            raise RuntimeError('h_weight.shape[1]: {} should can be '
                               'be divisible by {}.'.format(h_weight.shape[1], fc_num))
        x_weight_shape = x_weight.shape
        x_weight = x_weight.reshape(fc_num, -1, x_weight_shape[-1])

        h_weight_shape = h_weight.shape
        h_weight = h_weight.reshape(fc_num, -1, h_weight_shape[-1])
        return x_weight, h_weight

    @staticmethod
    def get_qunant_bias(weight, bias, scale,
                        offset_d, object_node):
        scale_d, scale_w = scale
        quantized_bias = [0] * bias.size
        for fc_index in range(weight.shape[0]):
            deq_scale_x = BiasQuantPass.get_deq_scale(scale_d, scale_w[fc_index])
            for bias_index in range(len(bias[fc_index])):
                bias_iter_index = len(bias[fc_index]) * fc_index + bias_index
                quantized_bias[bias_iter_index] = \
                    BiasQuantPass.quant_bias(
                        bias[fc_index][bias_index],
                        offset_d,
                        object_node.name,
                        weight[fc_index][bias_index].sum(),
                        deq_scale_x
                    )
        return quantized_bias

    @staticmethod
    def get_weight_bias(rnn_helper, bias_helper, x_weight_param, h_weight_param):
        fc_num = rnn_helper.weights_count()
        if not rnn_helper.bidirectional:
            x_weight, h_weight = RNNBiasQuantPass.get_weight(x_weight_param,
                                                             h_weight_param, fc_num)
            x_bias, h_bias = RNNBiasQuantPass.get_bias(bias_helper, fc_num)
        else:
            half = fc_num // 2
            x_xr_weight, h_hr_weight = RNNBiasQuantPass.get_weight(x_weight_param,
                                                                   h_weight_param, fc_num)
            x_weight, h_weight = x_xr_weight[:half], h_hr_weight[:half]
            xh_int32_bias, xh_int32_bias_reverse = RNNBiasQuantPass.get_bias(bias_helper, fc_num)
            half = len(xh_int32_bias) // 2
            x_bias, h_bias = xh_int32_bias[:half], xh_int32_bias[half:]
        return x_weight, h_weight, x_bias, h_bias

    @staticmethod
    def get_weight_bias_reverse(rnn_helper, bias_helper, x_weight_param, h_weight_param):
        fc_num = rnn_helper.weights_count()
        half = fc_num // 2
        x_xr_weight, h_hr_weight = RNNBiasQuantPass.get_weight(x_weight_param,
                                                               h_weight_param, fc_num)
        x_weight_reverse, h_weight_reverse = x_xr_weight[half:], h_hr_weight[half:]
        xh_int32_bias, xh_int32_bias_reverse = RNNBiasQuantPass.get_bias(bias_helper, fc_num)
        half = len(xh_int32_bias) // 2
        x_bias_reverse, h_bias_reverse = xh_int32_bias_reverse[:half], xh_int32_bias_reverse[half:]
        return x_weight_reverse, h_weight_reverse, x_bias_reverse, h_bias_reverse

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.name not in self.records:
            return False
        if node.type not in RNN_ONNX_TYPES:
            return False
        '''
        input_anchor[0]: x
        input_anchor[1]: x_w
        input_anchor[2]: h_w
        input_anchor[3]: bias
        '''
        bias_index = 3
        peer_output_anchor = node.input_anchors[bias_index].get_peer_output_anchor()
        if peer_output_anchor is None:
            return False
        if peer_output_anchor.node.type != 'initializer':
            return False

        return True

    def get_scale(self, object_node_name, fc_num):
        x_scale_d = self.records.get(object_node_name).get('data_scale')[0]
        h_scale_d = self.records.get(object_node_name).get('data_scale')[1]
        scale_w = self.records.get(object_node_name).get('weight_scale')
        x_scale_w = scale_w[:fc_num]
        h_scale_w = scale_w[fc_num:]

        scales = (x_scale_d, h_scale_d, x_scale_w, h_scale_w)
        return scales

    def get_offset(self, object_node_name):
        x_offset_d = self.records.get(object_node_name).get('data_offset')[0]
        h_offset_d = self.records.get(object_node_name).get('data_offset')[1]
        return x_offset_d, h_offset_d

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual quantization and node's bias is changed to int32.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        rnn_helper = get_rnn_helper(object_node)
        fc_num = rnn_helper.weights_count()

        # get weight quantization information
        x_weight_param, h_weight_param, bias_param = \
            QuantOpInfo.get_rnn_weight_node(object_node)

        object_node_name = object_node.name
        bias_helper = TensorProtoHelper(bias_param.proto)

        x_offset_d, h_offset_d = self.get_offset(object_node_name)
        x_scale_d, h_scale_d, x_scale_w, h_scale_w = self.get_scale(
            object_node_name, fc_num)
        if rnn_helper.bidirectional:
            half = fc_num // 2
            x_scale_w_reverse, h_scale_w_reverse = x_scale_w[half:], h_scale_w[half:]
            x_scale_w, h_scale_w = x_scale_w[:half], h_scale_w[:half]

        ''' get layer config of current node '''
        layer_config = self.conf.get_layer_config(object_node_name)

        ''' get wts_algo by 'retrain' of 'calibration' status '''
        if self.is_retrain:
            wts_param = layer_config.get(RETRAIN_WEIGHT_CONFIG)
            wts_algo = wts_param['algo']
        else:
            wts_param = layer_config.get(WEIGHT_QUANT_PARAMS)
            wts_algo = wts_param['wts_algo']

        ''' for rnn layer, it has one bias blob, which joins two bias of two fc, 
            each fc is combined by four gate fc, each gate fc has 1 * 1 kernel
        '''
        x_weight, h_weight, x_bias, h_bias = self.get_weight_bias(rnn_helper, bias_helper,
                                                                  x_weight_param, h_weight_param)
        quantized_bias_x = self.get_qunant_bias(x_weight, x_bias,
                                                (x_scale_d, x_scale_w),
                                                x_offset_d, object_node)
        quantized_bias_h = self.get_qunant_bias(h_weight, h_bias,
                                                (h_scale_d, h_scale_w),
                                                h_offset_d, object_node)
        quantized_bias = quantized_bias_x + quantized_bias_h
        if rnn_helper.bidirectional:
            x_weight_reverse, h_weight_reverse, x_bias_reverse, h_bias_reverse = \
                self.get_weight_bias_reverse(rnn_helper, bias_helper,
                                             x_weight_param, h_weight_param)
            quantized_bias_x_reverse = self.get_qunant_bias(x_weight_reverse, x_bias_reverse,
                                                            (x_scale_d, x_scale_w_reverse),
                                                            x_offset_d, object_node)
            quantized_bias_h_reverse = self.get_qunant_bias(h_weight_reverse, h_bias_reverse,
                                                            (h_scale_d, h_scale_w_reverse),
                                                            h_offset_d, object_node, )
            quantized_bias += quantized_bias_x_reverse + quantized_bias_h_reverse

        bias_helper.clear_data()
        bias_helper.set_data(quantized_bias, 'INT32')

        LOGGER.logd("Quant bias from float32 to int32 for layer '{}' " \
                    "success!".format(object_node_name), 'RNNBiasQuantPass')
