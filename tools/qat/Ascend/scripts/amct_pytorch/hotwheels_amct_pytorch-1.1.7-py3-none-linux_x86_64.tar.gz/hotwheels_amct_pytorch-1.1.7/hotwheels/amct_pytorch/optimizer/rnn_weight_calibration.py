#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Do caliration for weight, sacle and offset for weight will be finded and
weight is fake_quantized.

"""
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    record_weights_scale_offset
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_TYPES
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import (X_WEIGHT, H_WEIGHT,
                                               X_WEIGHT_REVERSE, H_WEIGHT_REVERSE)
from hotwheels.amct_pytorch.utils.vars import RNN_TYPES
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from hotwheels.amct_pytorch.optimizer.weight_calibration import WeightsCalibrationPass
from hotwheels.amct_pytorch.utils.rnn_utils import get_rnn_helper

from hotwheels.amct_pytorch.common.utils.record_file_operator import WeightQuantParam


class RNNWeightsCalibrationPass(WeightsCalibrationPass):
    """
    Function: Do calibration for weight of RNN, sacle and offset for weight will
        be found and weight is fake_quantized.
    APIs: set_up, tear_down, match_pattern, do_pass
    """

    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        WeightsCalibrationPass.__init__(self)

    @staticmethod
    def get_calied_weight_raw(x_weight, h_weight):
        xw_calied_weight_raw = x_weight.data
        hw_calied_weight_raw = h_weight.data

        xw_calied_weight_raw = xw_calied_weight_raw.flatten().cpu().numpy().tolist()
        hw_calied_weight_raw = hw_calied_weight_raw.flatten().cpu().numpy().tolist()
        return xw_calied_weight_raw, hw_calied_weight_raw

    @staticmethod
    def get_xh_scale_offset(object_name, wts_param, rnn_helper,
                            x_weight, h_weight):
        scale = []
        offset = []
        x_weight_shape = x_weight.shape
        h_weight_shape = h_weight.shape
        fc_num = rnn_helper.weights_count()
        fc_num = fc_num // 2 if rnn_helper.bidirectional else fc_num
        reshape_x_weight = x_weight.reshape(fc_num, 1, -1, x_weight_shape[-1])
        reshape_h_weight = h_weight.reshape(fc_num, 1, -1, h_weight_shape[-1])

        wts_param['channel_wise'] = True
        # get quantization params of weight calibration
        # the order of fcs in pytorch is different of the order in onnx
        reshape_x_weight = rnn_helper.adjust_weight_order(reshape_x_weight)
        xw_scale, xw_offset, xw_calied_weight, xw_params = WeightsCalibrationPass. \
            cali_tensor(reshape_x_weight, wts_param, object_name)

        reshape_h_weight = rnn_helper.adjust_weight_order(reshape_h_weight)
        hw_scale, hw_offset, hw_calied_weight, hw_params = WeightsCalibrationPass. \
            cali_tensor(reshape_h_weight, wts_param, object_name)

        # update weight data with calied weight
        x_weight.data = xw_calied_weight.reshape(x_weight_shape)
        h_weight.data = hw_calied_weight.reshape(h_weight_shape)

        scale.extend(xw_scale)
        scale.extend(hw_scale)
        offset.extend(xw_offset)
        offset.extend(hw_offset)
        return scale, offset

    @staticmethod
    def ajust_scale_offset(scale, offset, fc_num):
        # The first half is xw, and the second half is hw;
        # The first half is xw_reverse, and the second half is xw_reverse
        scale[fc_num:fc_num * 2], scale[fc_num * 2:fc_num * 3] = \
            scale[fc_num * 2:fc_num * 3], scale[fc_num:fc_num * 2]
        # The first half is xw, and the second half is hw;
        # The first half is xw_reverse, and the second half is xw_reverse
        offset[fc_num:fc_num * 2], offset[fc_num * 2:fc_num * 3] = \
            offset[fc_num * 2:fc_num * 3], offset[fc_num:fc_num * 2]
        return scale, offset

    def match_pattern(self, module, name, graph=None):
        """
        Function:Match the module to be quantized in model
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure, not necessary
        Return: True: matched
                False: mismatch
        """
        if type(module).__name__ not in QUANTIZABLE_TYPES:
            return False
        if type(module).__name__ not in RNN_TYPES:
            return False
        if name not in self.conf.get_quant_config():
            return False
        return True

    def do_pass(self, model, object_module, object_name, graph=None):
        """
        Function: Do rnn weight calibration
        Parameters: model: torch.nn.Module, the model to be modified.
                    object_module: module to process
                    object_name: name of object_module
                    graph: graph structure, not necessary
        Return: None
        """
        # Step0: get weights' information for quantization
        object_node = graph.get_node_by_name(object_name)
        rnn_helper = get_rnn_helper(object_node)
        fc_num = rnn_helper.weights_count()
        # If you are in the bid mode, you need to calibrate the forward and reverse data of the bid model respectively
        fc_num = fc_num // 2 if object_module.bidirectional else fc_num
        layer_config = self.conf.get_layer_config(object_name)
        wts_param = layer_config.get(WEIGHT_QUANT_PARAMS)

        params = None
        x_weight = getattr(object_module, X_WEIGHT).data
        h_weight = getattr(object_module, H_WEIGHT).data
        scale, offset = self.get_xh_scale_offset(object_name, wts_param, rnn_helper,
                                                 x_weight, h_weight)
        # set weights data to graph
        x_weight_param, h_weight_param, _ = \
            QuantOpInfo.get_rnn_weight_node(object_node)
        x_weight_helper = TensorProtoHelper(x_weight_param.proto)
        h_weight_helper = TensorProtoHelper(h_weight_param.proto)

        xw_calied_weight_raw, hw_calied_weight_raw = self.get_calied_weight_raw(x_weight, h_weight)

        x_weight_helper.clear_data()
        h_weight_helper.clear_data()
        if not object_module.bidirectional:
            x_weight_helper.set_data(xw_calied_weight_raw, 'FLOAT')
            h_weight_helper.set_data(hw_calied_weight_raw, 'FLOAT')
        else:
            x_weight_reverse = getattr(object_module, X_WEIGHT_REVERSE).data
            h_weight_reverse = getattr(object_module, H_WEIGHT_REVERSE).data
            scale_reverse, offset_reverse = self.get_xh_scale_offset(object_name, wts_param,
                                                                     rnn_helper, x_weight_reverse, h_weight_reverse)
            all_scale = scale + scale_reverse
            all_offset = offset + offset_reverse
            scale, offset = self.ajust_scale_offset(all_scale, all_offset, fc_num)

            xw_calied_weight_raw_reverse, hw_calied_weight_raw_reverse = \
                self.get_calied_weight_raw(x_weight_reverse, h_weight_reverse)

            x_weight_helper.set_data(xw_calied_weight_raw + xw_calied_weight_raw_reverse, 'FLOAT')
            h_weight_helper.set_data(hw_calied_weight_raw + hw_calied_weight_raw_reverse, 'FLOAT')

        weight_quant_param = WeightQuantParam(scale=scale, offset=offset, num_bits=wts_param.get('num_bits'))
        # save the quantize information
        record_weights_scale_offset(self.records, object_name, weight_quant_param, params)

        LOGGER.logd('Do layer \'{}[{}]\' rnn weights calibration success!'
                    .format(object_node.name, wts_param['wts_algo']),
                    'RNNWeightsCalibrationPass')
