#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

load libquant.so and lib.amct_pytorch_ops.so

"""
import os
import imp
import ctypes
import pkg_resources

from hotwheels.amct_pytorch.utils.vars import TORCH_VERSION

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]


def __load_quant_lib():
    lib_name = './libquant_lib_{}.so'.format(TORCH_VERSION)
    lib_name = os.path.join(CUR_DIR, lib_name)
    ctypes.cdll.LoadLibrary(lib_name)


def __bootstrap():
    lib_name = '../../../amct_pytorch_ops.cpython-37m-x86_64-linux-gnu.so'
    files = pkg_resources.resource_filename(__name__, \
        lib_name)
    imp.load_dynamic(__name__, files)

__load_quant_lib()
__bootstrap()
