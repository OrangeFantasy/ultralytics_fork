#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert DepthwiseConv in model for batchnorm layer

"""
from collections import OrderedDict
import os
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from hotwheels.amct_pytorch.optimizer.base_module_fusion_pass import \
    BaseModuleFusionPass
from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import CONV_BN_FUSION_TYPES
from hotwheels.amct_pytorch.utils.vars import TO_FUSE_TYPES
from hotwheels.amct_pytorch.utils.vars import RETRAIN_WEIGHT_CONFIG
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.capacity import CAPACITY
import torch.nn as nn
from hotwheels.amct_pytorch.custom_op.depthwiseconv_bn import DepthwiseConvBN
import torch
from hotwheels.amct_pytorch.proto import scale_offset_record_pb2
from google.protobuf import text_format
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_FLAG
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_MODE


class InsertDepthwiseConvPass(BaseModuleFusionPass):
    """
    Function: Insert DepthwiseConv for batchNorm module
    APIs: match_pattern, do_pass
    """

    def __init__(self, is_retrain=False):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseModuleFusionPass.__init__(self)
        self.is_retrain = is_retrain
        if is_retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.record_file_path = self.conf.get_record_file_path()

    @staticmethod
    def build_depthwiseconv_module(object_module):
        in_channels = object_module.num_features
        depthwiseconv_module = nn.Conv2d(in_channels, in_channels, 1,
                                         stride=1, padding=0, dilation=1,
                                         groups=in_channels, bias=True,
                                         padding_mode='zeros')
        weight_shape = depthwiseconv_module.weight.shape
        depthwiseconv_module.weight.data = torch.ones(weight_shape)
        bias_shape = depthwiseconv_module.bias.shape
        depthwiseconv_module.bias.data = torch.zeros(bias_shape)
        new_module = DepthwiseConvBN(depthwiseconv_module, object_module)
        new_module.eval()
        return new_module

    def set_up(self):
        """
        Function: Open the record file
        Inputs: None
        Returns: None
        """
        with os.fdopen(os.open(self.record_file_path, os.O_RDONLY,
            FILE_ACCESS_MODE), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with os.fdopen(os.open(self.record_file_path, FILE_ACCESS_FLAG,
            FILE_ACCESS_MODE), 'w') as record_write_file:
            record_write_file.write(
                text_format.MessageToString(self.records, as_utf8=True))

    def match_pattern(self, module, name, graph=None):
        """
        Function:Match the module to be quantized in model
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure, not necessary
        Return: True: matched
                False: mismatch
        """
        if not CAPACITY.get_value('REPLACE_DEPTHWISE_ACCEL'):
            return False
        if type(module).__name__ not in TO_FUSE_TYPES:
            return False
        try:
            node = graph.get_node_by_name(name)
        except RuntimeError:
            # the mod is not in graph
            LOGGER.logd('"%s" is not in graph.' % (name), 'Graph')
            return False
        if node.name not in self.conf.get_quant_config():
            return False
        if len(node.input_anchors) < 1:
            return False
        if node.get_input_anchor(0).get_peer_output_anchor().node.type \
                in CONV_BN_FUSION_TYPES:
            return False
        return True

    def update_record_and_config(self, src_node):
        # update config
        quant_config = self.conf.get_quant_config()
        dest_node_name = src_node.name + '.conv_module'
        quant_config[dest_node_name] = quant_config[src_node.name]
        weight_config = OrderedDict()
        if self.is_retrain:
            if RETRAIN_WEIGHT_CONFIG not in quant_config[dest_node_name]:
                weight_config['algo'] = 'arq_retrain'
                weight_config['channel_wise'] = True
                weight_config['num_bits'] = 8
                weight_config['with_offset'] = False
                quant_config[dest_node_name][
                    RETRAIN_WEIGHT_CONFIG] = weight_config
            self.conf.add_depthwise_layer(dest_node_name)
            for record in self.records.record:
                if record.key == src_node.name:
                    record.key = dest_node_name
        else:
            if WEIGHT_QUANT_PARAMS not in quant_config[dest_node_name]:
                weight_config['wts_algo'] = 'arq_quantize'
                weight_config['channel_wise'] = True
                weight_config['num_bits'] = 8
                weight_config['with_offset'] = False
                quant_config[dest_node_name][
                    WEIGHT_QUANT_PARAMS] = weight_config
        del quant_config[src_node.name]
        self.conf.update_quant_config(quant_config)

    def do_pass(self, model, object_module, object_name, graph):
        """
        Function: Do actual Insert depthwiseconv_bn module
        Parameters: model: torch.nn.Module, the model to be modified.
                    object_module: module to process
                    object_name: name of object_module
                    graph: graph structure, not necessary
        Return: None
        """
        model_helper = ModuleHelper(model)
        object_node = graph.get_node_by_name(object_name)

        # Step1: find module's parent
        parent_module = model_helper.get_parent_module(object_name)

        # Step2: construct a new module
        depthwiseconv_module = \
            InsertDepthwiseConvPass.build_depthwiseconv_module(object_module)

        self.update_record_and_config(object_node)

        # Step3: replace new model
        setattr(parent_module,
                object_name.split('.')[-1], depthwiseconv_module)
        LOGGER.logd(
            "Insert depthwiseConv module to '{}' success!".format(object_name),
            'InsertDepthwiseConvPass')
