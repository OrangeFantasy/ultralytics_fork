#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quant weight by SNQ.

"""
import torch
from hotwheels.amct_pytorch.custom_op.amct_pytorch_ops import SnqParam
from hotwheels.amct_pytorch.custom_op.amct_pytorch_ops import snq_calibration

INIT_ALG_UNIFORM = 0
INIT_ALG_GAUSSIAN = 1
INIT_ALG_D2_SAMPLING = 2

INIT_ALG_MATCH_DICT = {
    "uniform" : INIT_ALG_UNIFORM,
    "gaussian" : INIT_ALG_GAUSSIAN,
    "d2sampling" : INIT_ALG_D2_SAMPLING,
}


__all__ = ['snq_weight_cali_tensor']


def snq_weight_cali_tensor(weight_tensor, wts_param):
    """
    Function: Do calibration on weight_tensor
    Inputs:
        weight_tensor: torch.tensor, weight to be calibrated
        wts_param: a dict, parameters for calibration
     Returns:
        scale_list: a 1-dim list, scale of weight_tensor
        offset_list: a 1-dim list, offset of weight_tensor
        calied_weight: torch.tensor, calibrated weight
    """
    # data's shape should be [channle_out, -1]
    if wts_param['wts_algo'] == 'snq_quantize':
        return snq_weight(weight_tensor, wts_param)

    raise RuntimeError("Unsupport wts_algo %s " % (wts_param['wts_algo']))


def snq_weight(weight_tensor, wts_param):
    """
    Function: Do calibration on weight_tensor with 'ARQ' algorithm
    Inputs:
        weight_tensor: torch.tensor, weight to be calibrated
        wts_param: a dict, parameters for calibration
    Returns:
        scale_list: a 1-dim list, scale of weight_tensor
        offset_list: a 1-dim list, offset of weight_tensor
        calied_weight: torch.tensor, calibrated weight
    """
    snq_param = SnqParam(wts_param['channel_wise'],
        wts_param['max_iteration'], wts_param['min_distance'],
        INIT_ALG_MATCH_DICT.get(wts_param['init_algo']))
    status, scale, offset, params, calied_weight = snq_calibration(
        weight_tensor, snq_param)
    if status != 0:
        raise RuntimeError("Weight calibration with SNQ failed!")
    if torch.isclose(scale, torch.zeros_like(scale)).all():
        raise ValueError("Weight calibration with SNQ failed! Reason: scale is zero")
    scale_list = (1.0 / scale).flatten().cpu().numpy().tolist()
    offset_list = offset.flatten().cpu().numpy().tolist()
    params = params.cpu()
    snq_weight_collection = (scale_list, offset_list, calied_weight, params)
    return snq_weight_collection
