# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

file's releated operations.
"""

import os
import stat
import re

# mode is 640
FILE_MODE = stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP
# mode is 750
DIR_MODE = stat.S_IRWXU + stat.S_IRGRP + stat.S_IXGRP

# writeOnly + create if not exist + truncate
FILE_ACCESS_FLAG = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
# readOnly
FILE_READ_FLAG = os.O_RDONLY
FILE_ACCESS_MODE = 0o755

FILE_NAME_PATTERN = "^[^/]{1,254}$"
SAVE_PREFIX_PATTERN = "^[^/]{0,241}$"

__all__ = ['create_path', 'create_empty_file', 'is_valid_name',
           'is_valid_save_prefix', 'create_file_path']


def create_path(file_path, mode=DIR_MODE):
    ''' Create path '''
    file_dir = os.path.realpath(file_path)
    try:
        os.makedirs(file_dir, mode, exist_ok=True)
    except FileExistsError:
        pass


def create_file_path(file_name, mode=DIR_MODE):
    ''' Create path '''
    file_name = os.path.realpath(file_name)
    file_dir = os.path.split(file_name)[0]
    try:
        os.makedirs(file_dir, mode, exist_ok=True)
    except FileExistsError:
        pass


def create_empty_file(file_name):
    '''Create empty file '''
    file_realpath = os.path.realpath(file_name)
    # set path's permission 750
    create_file_path(file_realpath)

    with os.fdopen(os.open(file_realpath, FILE_ACCESS_FLAG, FILE_MODE), 'w') as record_file:
        record_file.write('')
    # set file's permission 640
    os.chmod(file_realpath, FILE_MODE)

    return file_realpath


def is_valid_name(input_file, name):
    ''' check input_file as inputs'''
    if input_file == '':
        raise ValueError('empty string is an invalid value for %s' % (name))

    if input_file[-1] == '/':
        raise ValueError("%s{%s} should be a file's name but a path."
                         % (name, input_file))

    # check input_file without path
    file_name = os.path.split(os.path.realpath(input_file))[1]
    if not re.match(FILE_NAME_PATTERN, file_name):
        raise ValueError(
            "%s's name{%s} is invalid, '/' is "
            "reserved characters, length should be less than 255." %
            (name, file_name))


def is_valid_save_prefix(save_prefix):
    ''' check save_prefix. '''
    if not re.match(SAVE_PREFIX_PATTERN, save_prefix):
        raise ValueError(
            "prefix{%s} is invalid. '/' is reserved "
            "characters, length should be less than 242." % (save_prefix))


def check_file_path(file_path, name):
    """ check whether file exits. """
    if not os.path.exists(os.path.realpath(file_path)):
        raise RuntimeError(
            'Can not find the {} at {}'.format(name, file_path))
