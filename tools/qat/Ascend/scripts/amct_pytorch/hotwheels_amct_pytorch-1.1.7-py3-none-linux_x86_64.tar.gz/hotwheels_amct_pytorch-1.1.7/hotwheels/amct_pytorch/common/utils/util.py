#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Common function used by other modules.

"""
from hotwheels.amct_pytorch.utils.vars import RETRAIN_DATA_CONFIG
from hotwheels.amct_pytorch.utils.vars import ACTIVATION_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import DATA_BIT_NUM_RANGE
from hotwheels.amct_pytorch.utils.vars import ARQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.utils.vars import SNQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.proto import quant_param_record_pb2
from hotwheels.amct_pytorch.custom_op.utils import get_node_input_num
import numpy as np


def find_repeated_items(items):
    '''find repeated items in a list '''
    repeat_items = set()
    for item in items:
        count = items.count(item)
        if count > 1:
            repeat_items.add(item)

    return list(repeat_items)


def check_no_repeated(items, name):
    '''raise error when item is not empty'''
    if items:
        raise ValueError("Please delete repeated items in %s, "
                         "repeated items are %s " % (name, items))


def proto_float_to_python_float(value):
    '''transform proto float to python float'''
    val_fp32 = np.float32(value)
    return float(str(val_fp32))


def is_invalid(value_array):
    ''' whether there's inf or nan in value_array'''
    is_array_invalid = np.isnan(value_array) | np.isinf(value_array)
    return is_array_invalid.any()


def eltwise_add_optimize(config, node, item, om_config, is_retrain):
    if is_retrain:
        key = RETRAIN_DATA_CONFIG
    else:
        key = ACTIVATION_QUANT_PARAMS
    if node.type == 'Add' and item in om_config.keys():
        input_num = get_node_input_num(node)
        for index in range(input_num):
            if om_config[item][index] == 'FP16':
                config[item][key][index]['num_bits'] = -1


def config_optimize_with_om(config, node, item, om_config, is_retrain):
    eltwise_add_optimize(config, node, item, om_config, is_retrain)


def get_data_cal_type(num_bits_d):
    if num_bits_d == DATA_BIT_NUM_RANGE[0]:
        return quant_param_record_pb2.S8
    elif num_bits_d > DATA_BIT_NUM_RANGE[0] \
            and num_bits_d <= DATA_BIT_NUM_RANGE[1]:
        return quant_param_record_pb2.S16
    else:
        return quant_param_record_pb2.F16


def get_weights_cal_type(num_bits_w):
    if num_bits_w == ARQ_WEIGHT_BIT_NUM:
        return quant_param_record_pb2.S8
    elif num_bits_w == SNQ_WEIGHT_BIT_NUM:
        return quant_param_record_pb2.U4
    else:
        return quant_param_record_pb2.F16