#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Base Module of quantized retrain

"""

import torch  # pylint: disable=E0401
import torch.nn as nn  # pylint: disable=E0401

from hotwheels.amct_pytorch.custom_op.retrain_module.arq_wts_retrain_module import ArqWtsRetrainModule
from hotwheels.amct_pytorch.custom_op.retrain_module.lnq_wts_retrain_module import LnqWtsRetrainModule
from hotwheels.amct_pytorch.custom_op.retrain_module.luq_wts_retrain_module import LuqWtsRetrainModule
from hotwheels.amct_pytorch.custom_op.retrain_module.luq_act_retrain_module import LuqActRetrainModule
from hotwheels.amct_pytorch.custom_op.retrain_module.ulq_act_retrain_module import UlqActRetrainModule
from hotwheels.amct_pytorch.custom_op.retrain_module.fixed_act_retrain_module import FixedActRetrainModule
from hotwheels.amct_pytorch.utils.log import LOGGER

WEIGHT_REPLACE_DICT = {
    'lnq_retrain': LnqWtsRetrainModule,
    'luq_retrain': LuqWtsRetrainModule,
    'arq_retrain': ArqWtsRetrainModule,
}

ACTIVATION_REPLACE_DICT = {
    'ulq_retrain': UlqActRetrainModule,
    'luq_retrain': LuqActRetrainModule,
    'fixed_quant_param_retrain': FixedActRetrainModule,
}


class CompModuleBase(nn.Module):
    """
    Function: Base class module for quantized retrain.
    APIs: __init__, _init_output, forward
    """

    def __init__(self, module,  # pylint: disable=R0913
                 act_config=None,
                 wts_config=None,
                 common_config=None,
                 skip_quant=False,
                 index=0):
        super(CompModuleBase, self).__init__()
        self.replaced_module = module
        self.act_config = act_config
        self.wts_config = wts_config
        self.common_config = common_config
        self.skip_quant = skip_quant
        self.acts_comp_reuse = None
        self.index = index
        self.act_module = ACTIVATION_REPLACE_DICT.get(self.act_config.get('algo'))(
            module, 
            act_config=act_config, 
            common_config=common_config)
        self.wts_module = None
        if wts_config is not None:
            self.wts_module = WEIGHT_REPLACE_DICT.get(self.wts_config.get('algo'))(
            module,
            wts_config=wts_config,
            common_config=common_config)
        if self.act_config.get('num_bits') == -1:
            LOGGER.logd('Skip activation retrain of layer {} at index {}.'. \
                        format(self.common_config['layers_name'][0], self.index))

    def update_skip_quant(self, skip_quant):
        self.skip_quant = skip_quant

    def update_shared_module(self, shared_module, shared_idx):
        if type(shared_module).__name__ == 'CompModuleWithoutWeight':
            replaced_module = getattr(shared_module, 'retrain_module%d' % shared_idx)
        else:
            replaced_module = shared_module
        self.acts_comp_reuse = replaced_module

    def forward(self, inputs):  # pylint: disable=W0221
        """
        Defines the computation performed at every call.
        Should be overridden by all subclasses.
        """
        if self.skip_quant:
            compressed_weights = None
            if self.wts_module is not None:
                compressed_weights = self.wts_module.replaced_module.weight
            return inputs, compressed_weights
        elif self.act_config.get('num_bits') == -1:
            compressed_inputs = inputs
        else:
            if self.acts_comp_reuse:
                compressed_inputs = self.acts_comp_reuse.act_module.acts_forward(inputs)
            else:
                compressed_inputs = self.act_module.acts_forward(inputs)
        compressed_weights = None
        if self.wts_module is not None:
            compressed_weights = self.wts_module.wts_forward()

        return compressed_inputs, compressed_weights

