#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Base Module of quantized retrain

"""

import torch
import torch.nn as nn
from hotwheels.amct_pytorch.custom_op.utils import tensor
import numpy as np

CLUSTER_SIZE = 272
SYM_THRESHOLD = 100


class WtsRetrainModuleBase(nn.Module):
    """
    Function: Base class module for quantized retrain.
    APIs: __init__, get_weight_scale, get_weight_offset,
        get_weight_param
    """
    def __init__(self, module,
                 wts_config=None,
                 common_config=None,
                 transpose=False):
        super(WtsRetrainModuleBase, self).__init__()
        self.replaced_module = module
        self.wts_config = wts_config
        self.common_config = common_config
        self.transpose = transpose
        self._init_output()

    def get_weight_scale(self):
        if self._check_zero():
            raise ValueError("wts_scales of wts retrain is zero")
        return 1.0 / self.wts_scales

    def get_weight_offset(self):
        return self.wts_offsets

    def _init_output(self):
        self.register_buffer('wts_scales', tensor(np.nan))
        self.register_buffer('wts_offsets', tensor(np.nan))

    def _check_zero(self):
        return torch.isclose(self.wts_scales, torch.zeros_like(self.wts_scales)).all()

