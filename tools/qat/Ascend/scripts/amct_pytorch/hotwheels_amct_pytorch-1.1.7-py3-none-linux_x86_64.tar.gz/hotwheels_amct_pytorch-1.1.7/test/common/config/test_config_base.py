import os.path
import unittest

from test.tools.graph.graph_basic import Graph
from test.tools.config.shape import GENERAL_SHAPE
from test.resource.dpn107 import Model as DPN

import torch

from hotwheels.amct_pytorch.common.config.config_base import GraphObjects
from hotwheels.amct_pytorch.common.config.config_base import ConfigBase
from hotwheels.amct_pytorch.configuration.check import GraphQuerier
from hotwheels.amct_pytorch.capacity import CAPACITY
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_ONNX_TYPES, \
    NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.log import LOGGER



CONFIGURER = ConfigBase(
    GraphObjects(graph_querier=GraphQuerier, graph_checker=None), CAPACITY)

ACTIVATION_QUANT_PARAMS = 'activation_quant_params'
WITH_OFFSET = 'with_offset'
QUANT_ENABLE = 'quant_enable'

CURRENT_PATH = os.path.split(os.path.realpath(__file__))[0]
CONFIG_PATH = os.path.join(CURRENT_PATH, 'tmp')
CONFIG_DEFINATION = './cali_conf/calibration_snq.cfg'


MATMUL_QUANT_LAYER = {'matmul_1', 'add_1', 'add_2'}
RELU_QUANT_LAYER = {'relu'}

DICT_LAYERS = {'matmul': MATMUL_QUANT_LAYER, 'relu': RELU_QUANT_LAYER}

SKIP_LAYERS_TEST_CASE = {
    "NOT_EXIST":['XXX'],
    "NOT_SUPPORT":['Constant_14'],
    "QUANTIZABLE":['XXX'],
    "NO_WEIGHT_QUANTIZABLE":['features.conv1_1.conv']
}


class MatMulModel(torch.nn.Module):
    def __init__(self):
        super(MatMulModel, self).__init__()

    def forward(self, add_inputs):
        y = torch.matmul(add_inputs, torch.tensor([1., 2., 6., 3.]).reshape(1, 1, 2, 2).to(add_inputs.device))
        z = torch.add(add_inputs, 1)
        y = torch.add(y, z)
        return y


class ReluModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.relu = torch.nn.ReLU()

    def forward(self, x):
        out = self.relu(x)
        return out


class TestConfigBase(unittest.TestCase):
    def setUp(self) -> None:
        self.ordered_config = None
        self.input_data = None
        self.graph = None
        self.model = None

    def creat_ordered_config(self, config_defination=None):
        if config_defination:
            quant_config = CONFIGURER.generate_quant_config(None, self.graph, config_defination)
        else:
            quant_config = {}
            quant_layers = DICT_LAYERS.get(self.flag)
            if CONFIGURER.capacity.is_enable('BATCH_NUM'):
                quant_config['batch_num'] = 2
            quant_config['activation_offset'] = True
            CONFIGURER.set_param_pool(quant_layers, self.graph)
        CONFIGURER.root.check(None, quant_config)
        CONFIGURER.root.fill_default(quant_config)
        return CONFIGURER.root.sort(quant_config)

    def init_process(self):
        # init input_data
        self.input_data = Graph.generate_dummy_input([GENERAL_SHAPE])
        # init graph
        self.graph = Graph.create_graph(self.model, self.input_data, False)

    def test_set_layer_quant_with_no_offset(self):
        # init
        self.model = MatMulModel()
        self.flag = 'matmul'
        self.init_process()
        self.ordered_config = self.creat_ordered_config(None)

        CONFIGURER.set_layer_quant_with_no_offset(self.ordered_config, self.graph, ACTIVATION_QUANT_PARAMS)

        def _check_matmul(node):
            return node.type == 'MatMul'
        for node in filter(_check_matmul, self.graph.nodes):
            # check point 1
            self.assertEqual(node.type, 'MatMul', 'type of node {} is not matmul'.format(node.name))
            activation_param = self.ordered_config.get(node.name, {}).get(ACTIVATION_QUANT_PARAMS, [])
            for idx, input_config in enumerate(activation_param):
                # check point 2
                self.assertFalse(input_config[WITH_OFFSET],
                                 'with offset in activation quant params of'
                                 ' matmul layer is not False, node: {}, idx: {}'.format(node.name, idx))
                peer_input_anchors = node.get_input_anchor(idx).get_peer_output_anchor().get_peer_input_anchor()
                for peer_input_anchor in peer_input_anchors:
                    if peer_input_anchor.node.name == node.name:
                        continue
                    peer_activation_param = self.ordered_config.get(peer_input_anchor.node.name).\
                        get(ACTIVATION_QUANT_PARAMS)
                    # check point 3
                    self.assertFalse(peer_activation_param[peer_input_anchor.index][WITH_OFFSET],
                                     'one to multipath case: with offset in activation quant params of'
                                     ' peer input is not False, node: {},'
                                     ' idx: {}'.format(peer_input_anchor.node.name, peer_input_anchor.index))

    def test_set_unquantize_layers(self):
        self.model = ReluModel()
        self.flag = 'relu'
        self.init_process()
        # normal
        self.ordered_config = self.creat_ordered_config(None)
        CONFIGURER.set_unquantize_layers(self.ordered_config, self.graph)
        self.check_relu_quant_enable()
        # snq_uniform
        self.ordered_config = self.creat_ordered_config(CONFIG_DEFINATION)
        CONFIGURER.set_unquantize_layers(self.ordered_config, self.graph)
        self.check_relu_quant_enable()

    def check_relu_quant_enable(self):
        # parse ordered_config
        for k, v in self.ordered_config.items():
            if k != self.flag:
                continue
            for param, value in v.items():
                if param == QUANT_ENABLE:
                    self.assertTrue(value, "Relu: not support!")

    def test_check_skip_types(self):
        # normal case
        skip_types = []
        for skip_type in QUANTIZABLE_ONNX_TYPES + NO_WEIGHT_QUANT_ONNX_TYPES:
            skip_types.append(skip_type)
            # check
            CONFIGURER.check_skip_types(skip_types)
            skip_types.clear()
        # exception case, would raise ValueError exception
        self.assertRaises(ValueError, CONFIGURER.check_skip_types, ['XXX'])

    def test_check_skip_layers(self):
        self.model = DPN()
        self.init_process()
        for key in SKIP_LAYERS_TEST_CASE:
            layers = SKIP_LAYERS_TEST_CASE.get(key)
            try:
                if key.startswith("NOT"):
                    self.assertRaises(ValueError, CONFIGURER.check_skip_layers, self.graph, layers)
                else:
                    CONFIGURER.check_skip_layers(self.graph, layers)
            except AssertionError as ae:
                LOGGER.loge("{} case in test_check_skip_layers did not pass, ValueError not raised,"
                            " quantization support {} ".format(key, layers))
            except ValueError as ve:
                LOGGER.loge("{} case in test_check_skip_layers did not pass,"
                            " layers {} not exist or not support quantization".format(key, layers))



