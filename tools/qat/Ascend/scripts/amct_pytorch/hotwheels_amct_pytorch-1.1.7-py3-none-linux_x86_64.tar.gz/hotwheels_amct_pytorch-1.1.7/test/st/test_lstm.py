import unittest


class TestLstm(unittest.TestCase):
    @unittest.skip
    def test_lstm(self):
        self.assertEqual(True, True)  # add assertion here


if __name__ == '__main__':
    unittest.main()
