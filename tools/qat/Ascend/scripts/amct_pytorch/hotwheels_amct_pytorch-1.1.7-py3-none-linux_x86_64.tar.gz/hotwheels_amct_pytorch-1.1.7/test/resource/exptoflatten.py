import torch.nn as nn
import torch


class Model(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        out = torch.exp(x)
        out = torch.flatten(out)

        return out