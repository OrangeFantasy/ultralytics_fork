import os
import unittest

from test.tools.graph.graph_basic import Graph
from test.resource.resources_yolox.yolox_x import Model as YOLOX
from test.tools.vars import DEFAULT_LOG_FILE, LOG_LEVEL


from hotwheels.amct_pytorch.fx.parser.function_replace import Func2ModuleHelper
from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.utils.vars import ONNX_SPLIT_OP_TYPE

CURRENT_PATH = os.path.split(os.path.realpath(__file__))[0]
CONFIG_PATH = os.path.join(CURRENT_PATH, 'tmp')


class TestModelUtil(unittest.TestCase):
    def setUp(self) -> None:
        self.model = None

    def test_check_op_split(self):
        self.model = YOLOX()
        self.model.eval()
        device = Graph.get_current_device(self.model)
        model = Func2ModuleHelper(self.model, CONFIG_PATH).generate_replaced_model().to(device)
        model_helper = ModuleHelper(model)
        # init model_helper using YOLOX
        model_helper.check_op_split()
        # check if warning log created or not
        with open(DEFAULT_LOG_FILE) as fp:
            for line in fp.readlines():
                module_name = line.split()[7]
                if LOG_LEVEL[1] in line and module_name in model_helper.named_module_dict.keys():
                    type_assert = isinstance(model_helper.named_module_dict.get(module_name), ONNX_SPLIT_OP_TYPE)
                    self.assertTrue(type_assert, "warning not logged when op SiLU exists")




