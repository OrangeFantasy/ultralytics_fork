import torch.nn as nn
import torch


class Model(nn.Module):
    """
    repeat() -> Tile op
    """
    def __init__(self):
        super(Model, self).__init__()

    def forward(self, x):
        out = torch.exp(x)
        out = torch.narrow(out, dim=0, start=0, length=3).repeat(3, 4)
        return out