from collections import OrderedDict
import unittest

from torch.nn.parameter import Parameter
import torch

from hotwheels.amct_pytorch.custom_op.utils import tensor
from hotwheels.amct_pytorch.custom_op.luq_retrain.acts_luq_retrain import \
    ActsLuqRetrainFunction



WITH_OFFSET = 'with_offset'


class TestLuqActRetrainModule(unittest.TestCase):
    def setUp(self) -> None:
        self.act_config = OrderedDict([('num_bits', 8), ('algo', 'luq_retrain'),
                                       ('with_offset', False), ('max_init_algo', 'mse')])
        self.acts_sym = tensor(0, dtype=torch.int32)
        self.input_mock = torch.randn(25, 4096)
        self.acts_clip_max = Parameter(tensor(0.0911, device='cpu', requires_grad=True))

    def test_luq_act_retrain_act_forward(self):
        self.acts_sym.data.fill_(not self.act_config.get(WITH_OFFSET))
        fakequant_inputs, scale, offset =\
            ActsLuqRetrainFunction.apply(self.input_mock, self.acts_clip_max,
                                         self.act_config['num_bits'], self.acts_sym.data)
        self.assertFalse(offset, 'offset in record is not zero')


