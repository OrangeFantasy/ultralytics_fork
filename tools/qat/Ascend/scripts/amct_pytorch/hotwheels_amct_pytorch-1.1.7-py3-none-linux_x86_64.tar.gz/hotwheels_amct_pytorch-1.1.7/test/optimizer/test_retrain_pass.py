import unittest

from test.tools.graph.graph_basic import Graph
from test.tools.config.shape import GENERAL_SHAPE

import torch

from hotwheels.amct_pytorch.configuration.check import GraphChecker


class TestModel(torch.nn.Module):
    def __init__(self):
        super(TestModel, self).__init__()

    def forward(self, add_inputs):
        y = torch.matmul(add_inputs, torch.tensor([1., 2., 6., 3.]).reshape(1, 1, 2, 2).to(add_inputs.device))
        z = torch.add(add_inputs, 1)
        y = torch.add(y, z)
        return y


class TestInsertNoWeightRetrainPass(unittest.TestCase):
    def setUp(self) -> None:
        self.input_data = None
        self.graph = None

    def init_process(self, model):
        self.input_data = Graph.generate_dummy_input([GENERAL_SHAPE])
        self.graph = Graph.create_graph(model, self.input_data, True)

    def test_pass_match_patten(self):
        model = TestModel()
        self.init_process(model)
        for node in self.graph.nodes:
            if node.type != 'MatMul':
                continue
            type_without_weight = GraphChecker.check_onnx_quantize_type_without_weight(node)
            type_with_weight = GraphChecker.check_onnx_quantize_type(node)
            self.assertFalse(type_without_weight)
            self.assertTrue(type_with_weight)



