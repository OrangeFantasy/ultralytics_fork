GENERAL_SHAPE = (1, 3, 224, 224)
SHAPE = {"elutoconcat":(1, 2, 393, 16),
         "reshape":(5, 10),
         "exptosplit":(1, 2, 352, 8, 96),
         "flatten":(1, 16, 496, 16, 1),
         "slice":(3, 4),
         "transpose":(1, 48, 17, 42),
         "tile":(3, 4),
         "squeeze":(1, 392, 17, 42),
         "view":GENERAL_SHAPE}
