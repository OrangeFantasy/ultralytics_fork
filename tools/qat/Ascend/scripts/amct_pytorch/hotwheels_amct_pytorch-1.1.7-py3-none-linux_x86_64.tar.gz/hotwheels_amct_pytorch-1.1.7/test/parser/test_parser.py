import unittest

import torch

from hotwheels.amct_pytorch.parser.parser import Parser


class TestRecursiveToCpu(unittest.TestCase):
    def setUp(self):
        self.args_shape = [(1, 3), (1, 3)]
        self.dump_input_lst = [torch.randn(arg) for arg in self.args_shape]
        self.dump_input_tup = [torch.randn(arg) for arg in self.args_shape]

    def test_recursive_to_cpu(self):
        def check_type(data):
            if torch.is_tensor(data):
                self.assertEqual(str(data.device), 'cpu')
            elif isinstance(data, list):
                for item in data:
                    check_type(item)
            elif isinstance(data, tuple):
                for item in data:
                    check_type(item)

        result_lst = Parser.recursive_to_cpu(self.dump_input_lst)
        for data in result_lst:
            self.assertEqual(str(data.device), 'cpu')

        self.dump_input_tup.append([torch.randn((2, 2))])
        tp = tuple(self.dump_input_tup)
        result_tup = Parser.recursive_to_cpu(tp)
        for data in result_tup:
            check_type(data)


