import os
import unittest
import sys


def main():
    test_dir = os.path.split(os.path.realpath(__file__))[0]
    pkg_dir = os.path.realpath(os.path.join(test_dir, '..'))

    loader = unittest.TestLoader()
    runner = unittest.TextTestRunner()
    # discover test_**.py in file path: test_dir and load
    suite = loader.discover(test_dir)
    # runner the UT test files
    runner.run(suite)


if __name__ == '__main__':
    main()
