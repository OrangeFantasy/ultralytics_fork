#!/usr/bin/env python
# -*- coding:utf-8 -*-
import torch.nn as nn
import torch


class Model(nn.Module):
    """testcase module

    Args:
        nn (object): pytorch nn
    """

    def __init__(self):
        super().__init__()
        self.elutoconcat_1 = nn.ELU()

    def forward(self, x):
        """[summary]

        Args:
            x ([type]): [description]

        Returns:
            [type]: [description]
        """
        out = self.elutoconcat_1(x)
        out2 = self.elutoconcat_1(x)
        out = torch.cat((out, out2), 2)
        return out
