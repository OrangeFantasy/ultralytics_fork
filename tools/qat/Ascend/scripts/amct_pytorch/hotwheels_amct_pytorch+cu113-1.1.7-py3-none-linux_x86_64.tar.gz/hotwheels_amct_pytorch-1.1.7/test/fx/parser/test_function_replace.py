import os.path
import unittest
import shutil

from test.resource.reshape import Model as TestModel
from test.resource.dpn107 import Model as DPN

import torch.distributed
from torch.fx import symbolic_trace

from hotwheels.amct_pytorch.fx.parser import function_replace
from hotwheels.amct_pytorch.fx.parser.function_replace import Func2ModuleHelper
from hotwheels.amct_pytorch.utils.vars import NON_REPLACEABLE_TYPES
from hotwheels.amct_pytorch.fx.parser.function_replace import TARGET_OP
from hotwheels.amct_pytorch.capacity.capacity_config import REPLACEABLE_FUNC_TYPES

SAVE_DIR = './tmp'
TMP_OP_DIR = '.temp_op'
TMP_MODEL_DIR = '.temp_model'

CALL_FUNCTION = 'call_function'
CALL_MODULE = 'call_module'

NONE_FLAG = 'None'


class TestFunc2ModuleHelper(unittest.TestCase):
    def setUp(self) -> None:
        self.model = DPN()
        self.test_obj = Func2ModuleHelper(self.model, SAVE_DIR)
        self.graph_module = symbolic_trace(self.test_obj.model)

    def test_check_node_type(self):
        # construct exception case
        all_nodes = list(self.graph_module.graph.nodes)
        if len(all_nodes) != 0:
            all_nodes[0].op = CALL_FUNCTION
            all_nodes[0].target = NON_REPLACEABLE_TYPES[0]
        self.assertRaises(RuntimeError, self.test_obj.check_node_type, self.graph_module)

    def test_process_one_define_multi_use_module(self):
        # test method
        graph_module = self.__process_one_define_multi_use_module()
        all_nodes = list(graph_module.graph.nodes)
        modules = dict(graph_module.named_modules())
        # the node trigger deepcopy
        deepcopy_node = []
        for node in all_nodes:
            if node.op != CALL_MODULE:
                continue
            if node.target == node.name:
                deepcopy_node.append(node)
        if len(deepcopy_node) != 0:
            for d_node in deepcopy_node:
                self.assertEqual(modules[d_node.target], modules[d_node.name])

    def test_register_fx_node_to_module_mapping(self):
        # init
        graph_module = self.__process_one_define_multi_use_module()
        self.__generate_tmp_module_for_func(graph_module)
        # test
        all_node = list(graph_module.graph.nodes)
        node_need_replacing = filter(self.node_need_replacing, all_node)
        # if node_need_replacing is not empty, node_to_module_mapping is not {}
        if len(list(node_need_replacing)) > 0:
            self.assertTrue(self.test_obj.node_to_module_mapping)

    def node_need_replacing(self, node):
        return node.op in TARGET_OP and node.target in REPLACEABLE_FUNC_TYPES

    def test_init_dir(self):
        model = TestModel()
        test_init_dir = Func2ModuleHelper(model, SAVE_DIR)
        tmp_op_dir = test_init_dir.tmp_op_dir.split('/')
        tmp_model_dir = test_init_dir.tmp_model_dir.split('/')
        self.assertTrue(tmp_op_dir[-1].startswith(TMP_OP_DIR))
        self.assertTrue(tmp_model_dir[-1].startswith(TMP_MODEL_DIR))

    def test_generate_tmp_module_for_func(self):
        # init
        graph_module = self.__process_one_define_multi_use_module()
        # count nodes need to be replaced
        all_nodes = list(graph_module.graph.nodes)
        custom_node = []
        for node in all_nodes:
            if node.op not in TARGET_OP or node.target not in REPLACEABLE_FUNC_TYPES:
                continue
            custom_node.append(node)
        # process normally
        self.__generate_tmp_module_for_func(graph_module)
        # compare
        # number of nodes need replacing is same as result(node_to_module_mapping.key())
        self.assertEqual(len(custom_node), len(self.test_obj.node_to_module_mapping))
        module_list = []
        for node in custom_node:
            module_list.append(self.test_obj.node_to_module_mapping.get(node.name, NONE_FLAG))
        self.assertNotIn(NONE_FLAG, module_list,
                         f'{NONE_FLAG} value in node_to_module_mapping when checking nodes need replacing')
        # check if the tmp_op file exist or not
        self.assertTrue(os.path.exists(self.test_obj.tmp_op_dir))


    def test_replace_function_with_tmp_module(self):
        # init
        graph_module = self.__process_one_define_multi_use_module()
        self.__generate_tmp_module_for_func(graph_module)
        # get node in mapping
        node_replace = []
        for node in graph_module.graph.nodes:
            if node.name in self.test_obj.node_to_module_mapping.keys():
                node_replace.append(node)
        graph_module = self.__replace_function_with_tmp_module(graph_module)
        # check if the call_func nodes are replaced by call_module
        for node in node_replace:
            self.assertEqual(node.op, CALL_MODULE)
            self.assertIsInstance(getattr(graph_module, node.name), self.test_obj.node_to_module_mapping.get(node.name))

    def test_generate_model_with_function_replaced_by_tmp_module(self):
        # init
        graph_module = self.__process_one_define_multi_use_module()
        self.__generate_tmp_module_for_func(graph_module)
        graph_module = self.__replace_function_with_tmp_module(graph_module)
        self.__generate_model_with_function_replaced_by_tmp_module(graph_module)
        # test
        self.assertTrue(os.path.exists(self.test_obj.tmp_model_dir))
        self.assertTrue(getattr(graph_module, '_code'), function_replace._python_code(graph_module.graph))

    def test_remove_temp_dir(self):
        model = DPN()
        test_obj = Func2ModuleHelper(model, SAVE_DIR)
        test_obj.generate_replaced_model()
        self.assertFalse(os.path.exists(test_obj.tmp_op_dir))
        self.assertFalse(os.path.exists(test_obj.tmp_model_dir))
        if torch.distributed.is_initialized():
            self.assertFalse(os.path.exists(test_obj.save_dir))

    def tearDown(self) -> None:
        if os.path.exists(SAVE_DIR):
            shutil.rmtree(SAVE_DIR)

    def __process_one_define_multi_use_module(self):
        return Func2ModuleHelper._process_one_define_multi_use_module(self.graph_module)

    def __generate_tmp_module_for_func(self, graph_module):
        self.test_obj._generate_tmp_module_for_func(graph_module)

    def __replace_function_with_tmp_module(self, graph_module):
        return self.test_obj._replace_function_with_tmp_module(graph_module)

    def __generate_model_with_function_replaced_by_tmp_module(self, graph_module):
        self.test_obj._generate_model_with_function_replaced_by_tmp_module(graph_module)

