DEFAULT_LOG_FILE = "./amct_log/hotwheels.amct_pytorch.log"

LOG_LEVEL = ['INFO', 'WARNING', 'ERROR']