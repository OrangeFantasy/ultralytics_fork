#!/usr/bin/env python
# -*- coding:utf-8 -*-
import torch.nn as nn
import torch


class Model(nn.Module):
    """testcase module

    Args:
        nn (object): pytorch nn
    """

    def __init__(self):
        super().__init__()


    def forward(self, x):
        """[summary]

        Args:
            x ([type]): [description]

        Returns:
            [type]: [description]
        """
        out = torch.reshape(x, shape=(5, 10))
        return out
