import unittest
import numpy as np


class TestParseRecordFile(unittest.TestCase):
    def setUp(self) -> None:
        self.offset_1 = [0, 0, 0]
        self.offset_2 = [0, 1, 0]
        self.offset_3 = [1, 1, 1]
        self.offset_d_array_1 = np.array(self.offset_1, dtype=np.int32)
        self.offset_d_array_2 = np.array(self.offset_2, dtype=np.int32)
        self.offset_d_array_3 = np.array(self.offset_3, dtype=np.int32)

    def test_parse_offset(self):
        # False only if each item is zero
        self.assertFalse(self.offset_d_array_1.any())
        self.assertTrue(self.offset_d_array_2.any())
        self.assertTrue(self.offset_d_array_3.any())

