import torch
import torch.nn as nn


class Model(nn.Module):
    """
    Transpose in ONNX is actually a Permute
    """
    def __init__(self):
        super(Model, self).__init__()

    def forward(self, x):
        out = torch.pow(x, exponent=2)
        out = torch.transpose(out, dim0=0, dim1=1)
        return out