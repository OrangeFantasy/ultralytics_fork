import os
from io import BytesIO

import torch.cuda

from hotwheels.amct_pytorch.parser.parser import Parser
from hotwheels.amct_pytorch.fx.parser.function_replace import Func2ModuleHelper

CURRENT_PATH = os.path.split(os.path.realpath(__file__))[0]
CONFIG_PATH = os.path.join(CURRENT_PATH, 'tmp')


class Graph():
    @staticmethod
    def create_graph(model, input_data, train:bool):
        model.train() if train else model.eval()
        if torch.cuda.is_available():
            model.to('cuda')
        device = Graph.get_current_device(model)
        model = Func2ModuleHelper(model, CONFIG_PATH).generate_replaced_model().to(device)
        tmp_onnx = BytesIO()
        Parser.export_onnx(model, input_data, tmp_onnx)
        graph = Parser.parse_net_to_graph(tmp_onnx)
        graph.add_model(model)
        return graph

    @staticmethod
    def generate_dummy_input(shape):
        dummy_input = tuple([torch.randn(sp) for sp in shape])
        if torch.cuda.is_available():
            dummy_input = tuple([data.to('cuda') for data in dummy_input])
        return dummy_input

    @staticmethod
    def get_current_device(model):
        try:
            device = next(model.parameters()).device
        except StopIteration:
            device = 'cpu'
        return device

