import torch.nn as nn
import torch


class Model(nn.Module):
    """
    symbolic_opset11.py -- Line 771
    def narrow():
        return _slice_helper()
    _slice_helper() enables Slice op in onnx graph
    """
    def __init__(self):
        super(Model, self).__init__()

    def forward(self, x):
        out = torch.exp(x)
        out = torch.narrow(out, dim=0, start=0, length=3)
        return out