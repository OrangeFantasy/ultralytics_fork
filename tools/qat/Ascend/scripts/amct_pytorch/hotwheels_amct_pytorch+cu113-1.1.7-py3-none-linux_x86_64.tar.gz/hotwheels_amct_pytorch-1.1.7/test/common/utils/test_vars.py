import unittest
import hotwheels.amct_pytorch.common.utils.vars as va

WITH_OFFSET = 'with_offset'


class TestVars(unittest.TestCase):
    def setUp(self):
        self.with_offset = va.WITH_OFFSET

    def test_with_offset(self):
        self.assertIsNotNone(self.with_offset)
        self.assertEqual(self.with_offset, WITH_OFFSET, 'vars - WITH_OFFSET value error')