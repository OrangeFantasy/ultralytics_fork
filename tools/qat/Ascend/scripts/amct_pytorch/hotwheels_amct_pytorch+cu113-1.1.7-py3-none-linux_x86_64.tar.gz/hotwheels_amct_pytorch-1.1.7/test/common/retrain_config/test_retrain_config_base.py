import os
from io import BytesIO
import unittest

import torch

from hotwheels.amct_pytorch.parser.parser import Parser
from hotwheels.amct_pytorch.fx.parser.function_replace import Func2ModuleHelper
from hotwheels.amct_pytorch.configuration.check import GraphChecker
from hotwheels.amct_pytorch.configuration.check import GraphQuerier
from hotwheels.amct_pytorch.common.retrain_config.retrain_config_base import \
    RetrainConfigBase
from hotwheels.amct_pytorch.common.config.config_base import GraphObjects
from hotwheels.amct_pytorch.capacity import CAPACITY


CONFIGURER = RetrainConfigBase(
    GraphObjects(graph_querier=GraphQuerier, graph_checker=GraphChecker), CAPACITY
)

CURRENT_PATH = os.path.split(os.path.realpath(__file__))[0]
CONFIG_PATH = os.path.join(CURRENT_PATH, 'tmp')

RETRAIN_DATA_CONFIG = 'retrain_data_config'


class TestModel(torch.nn.Module):
    def __init__(self):
        super(TestModel, self).__init__()

    def forward(self, add_inputs):
        y = torch.matmul(add_inputs, torch.tensor([1., 2., 6., 3.]).reshape(1, 1, 2, 2).to(add_inputs.device))
        z = torch.add(add_inputs, 1)
        y = torch.add(y, z)
        return y


class TestRetrainConfigBase(unittest.TestCase):
    def setUp(self):
        def check_cuda_available():
            return torch.cuda.is_available()

        def create_graph():
            try:
                device = next(self.model.parameters()).device
            except StopIteration:
                device = 'cpu'
            self.model = Func2ModuleHelper(self.model, CONFIG_PATH).generate_replaced_model().to(device)
            tmp_onnx = BytesIO()
            Parser.export_onnx(self.model, self.input_data, tmp_onnx)
            graph = Parser.parse_net_to_graph(tmp_onnx)
            graph.add_model(self.model)
            return graph

        def create_ordered_config():
            supported_layers = CONFIGURER.get_supported_layers(self.graph)
            CONFIGURER.config_tree.build_default(supported_layers, self.graph)
            ordered_config = CONFIGURER.config_tree.dump()
            return ordered_config

        self.model = TestModel()
        self.model.train()
        self.input_data = tuple([torch.randn(arg_shape) for arg_shape in [(1, 1, 2, 2)]])
        if check_cuda_available():
            self.input_data = tuple([data.to('cuda') for data in self.input_data])
            self.model.to('cuda')
        self.graph = create_graph()
        self.ordered_config = create_ordered_config()

    def test_set_retrain_data_weight_with_no_offset(self):
        # method process
        CONFIGURER.set_retrain_data_weight_with_no_offset(self.ordered_config, self.graph)

        # check now
        def _check_matmul(node):
            return node.type == 'MatMul'
        for node in filter(_check_matmul, self.graph.nodes):
            # get retrain_data_config of layer node.name
            retrain_data_config = self.ordered_config.get(node.name).get(RETRAIN_DATA_CONFIG)
            for index, data_config in enumerate(retrain_data_config):
                if data_config.get('algo') != 'luq_retrain':
                    # check point 1
                    self.assertIsNone(data_config.get('with_offset'),
                                      'with offset key in algorithm which is not luq')
                    # check point 2
                else:
                    self.assertFalse(data_config.get('with_offset'),
                                     'not false in with offset value in retrain data config,'
                                     ' name of node: {}'.format(node.name))
                peer_input_anchors = node.get_input_anchor(index). \
                    get_peer_output_anchor(). \
                    get_peer_input_anchor()
                for peer_input_anchor in peer_input_anchors:
                    # if peer_input_anchor indicates the init matmul node, skip current process
                    if peer_input_anchor.node.name == node.name:
                        continue
                    peer_node_name = peer_input_anchor.node.name
                    peer_index = peer_input_anchor.index
                    peer_retrain_data_config = self.ordered_config.get(peer_node_name, {}).get(RETRAIN_DATA_CONFIG, [])
                    # check point 3
                    self.assertFalse(peer_retrain_data_config[peer_index].get('with_offset'),
                                     'one to multipath case: with offset in retrain data config of'
                                     ' peer input is not False, node: {},'
                                     ' idx: {}'.format(peer_node_name, peer_index))
