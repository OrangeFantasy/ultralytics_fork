import os
import shutil
import time
import unittest
import numpy as np
import torch
import torch.fx
import onnx
import hotwheels.amct_pytorch as amct
from test.resource.lstm import CustomLSTMXHC, CustomLSTMXHCBid

LOG_FILE_DIR = 'amct_log'


class TestLSTM(unittest.TestCase):
    def setUp(self):
        self.device = torch.cuda.current_device()
        self.start_time = time.time()
        self.path, _ = os.path.split(os.path.realpath(__file__))
        self.tmp_path = os.path.join(self.path, 'tmp')
        self.config_file = os.path.join(self.tmp_path, 'config.json')
        self.record_file = os.path.join(self.tmp_path, 'record.txt')
        self.save_dir = os.path.join(self.tmp_path, 'results/')
        self.dump_dir = os.path.join(self.tmp_path, 'dump')
        self.modified_model_path = os.path.join(self.tmp_path, 'modified_model.onnx')
        self.model_path = None
        self.inputs = None
        self.inputs_type = None
        self.hidden_size = None

    def tearDown(self):
        log_dir = os.path.join(os.getcwd(), LOG_FILE_DIR)
        if os.path.exists(log_dir):
            shutil.rmtree(log_dir)
        if os.path.exists(self.tmp_path):
            shutil.rmtree(self.tmp_path)
        t = time.time() - self.start_time
        print('%s: %.3f' % (self.id(), t))

    def test_lstm_onewey_muti_input(self):
        self.hidden_size = 1
        inputs1 = torch.ones(2, 1, 10).to(self.device) * 0.5
        inputs20 = torch.ones(self.hidden_size, 1, 20).to(self.device) * 0.5
        inputs21 = torch.ones(self.hidden_size, 1, 20).to(self.device) * 0.5
        model = CustomLSTMXHC().to(self.device)
        lstm = model.lstm
        self.set_lstm_bias_weight(lstm.bias_ih_l0, -1)
        self.set_lstm_bias_weight(lstm.bias_hh_l0, 1)
        self.set_lstm_bias_weight(lstm.weight_ih_l0, -0.9)
        self.set_lstm_bias_weight(lstm.weight_hh_l0, 0.9)

        dummy_input = inputs1, inputs20, inputs21
        model.eval()
        amct.create_quant_config(self.config_file,
                                 model,
                                 dummy_input)
        calibrated_torch_model = amct.quantize_model(
            self.config_file,
            self.modified_model_path,
            self.record_file,
            model,
            dummy_input)
        calibrated_torch_model.eval()
        for _ in range(20):
            calibrated_torch_model(*dummy_input)
        amct.save_model(self.modified_model_path, self.record_file, self.save_dir, calibrated_torch_model)
        deploy_model_path = os.path.join(self.save_dir, "deploy_model.onnx")
        deploy_model = onnx.load_model(deploy_model_path)
        bias = np.array([])
        weight = []
        for i in deploy_model.graph.initializer:
            weight.append(np.frombuffer(i.raw_data, np.int8))
            if len(i.int32_data) != 0:
                bias = np.array(i.int32_data)
        gt_bias = np.array([-156778] * 80 + [265578] * 80)
        self.assertTrue(np.all(weight[0] == np.ones_like(weight[0]) * -85))
        self.assertTrue(np.all(weight[1] == np.ones_like(weight[1]) * 85))
        self.assertTrue(np.all(bias == gt_bias))

    def test_lstm_bid_muti_input(self):
        self.hidden_size = 2
        inputs1 = torch.ones(2, 1, 10).to(self.device) * 0.5
        inputs20 = torch.ones(self.hidden_size, 1, 20).to(self.device) * 0.5
        inputs21 = torch.ones(self.hidden_size, 1, 20).to(self.device) * 0.5
        model = CustomLSTMXHCBid().to(self.device)
        lstm = model.lstm
        self.set_lstm_bias_weight(lstm.bias_ih_l0, -1)
        self.set_lstm_bias_weight(lstm.bias_ih_l0_reverse, -1)
        self.set_lstm_bias_weight(lstm.bias_hh_l0, 1)
        self.set_lstm_bias_weight(lstm.bias_hh_l0_reverse, 1)
        self.set_lstm_bias_weight(lstm.weight_ih_l0, -0.9)
        self.set_lstm_bias_weight(lstm.weight_ih_l0_reverse, -0.9)
        self.set_lstm_bias_weight(lstm.weight_hh_l0, 0.9)
        self.set_lstm_bias_weight(lstm.weight_hh_l0_reverse, 0.9)

        dummy_input = inputs1, inputs20, inputs21
        model.eval()
        amct.create_quant_config(self.config_file,
                                 model,
                                 dummy_input)
        calibrated_torch_model = amct.quantize_model(
            self.config_file,
            self.modified_model_path,
            self.record_file,
            model,
            dummy_input)
        calibrated_torch_model.eval()
        for _ in range(20):
            calibrated_torch_model(*dummy_input)
        amct.save_model(self.modified_model_path, self.record_file, self.save_dir, calibrated_torch_model)
        deploy_model_path = os.path.join(self.save_dir, "deploy_model.onnx")
        deploy_model = onnx.load_model(deploy_model_path)
        bias = np.array([])
        weight = []
        for i in deploy_model.graph.initializer:
            if len(i.int32_data) != 0:
                bias = np.array(i.int32_data).reshape(2, -1)
            w = np.frombuffer(i.raw_data, np.int8)
            if len(w) == 0:
                continue
            weight.append(w)
        gt_bias = np.array([-156778] * 80 + [265578] * 80)
        gt_bias = np.concatenate((gt_bias, gt_bias)).reshape(2, -1)

        self.assertTrue(np.all(weight[0] == np.ones_like(weight[0]) * -85))
        self.assertTrue(np.all(weight[1] == np.ones_like(weight[1]) * 85))
        self.assertTrue(np.all(bias == gt_bias))

    def set_lstm_bias_weight(self, key, value):
        key.data = torch.ones_like(key.data) * value


if __name__ == '__main__':
    unittest.main()
