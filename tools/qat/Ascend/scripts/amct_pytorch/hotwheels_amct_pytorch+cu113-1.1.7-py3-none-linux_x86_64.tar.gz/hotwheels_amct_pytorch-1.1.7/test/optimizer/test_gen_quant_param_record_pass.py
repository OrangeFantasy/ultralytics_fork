import unittest

from test.resource.elutoconcat import Model as ELUTOCONCAT
from test.resource.reshape import Model as RESHAPE
from test.resource.exptosplit import Model as EXPTOSPLIT
from test.resource.exptoflatten import Model as FLATTEN
from test.resource.slice import Model as SLICE
from test.resource.powtotranspose import Model as TRANSPOSE
from test.resource.tile import Model as TILE
from test.resource.sigmoidtosqueeze import Model as SQUEEZE
from test.resource.dpn107 import Model as DPN
from test.tools.graph.graph_basic import Graph
from test.tools.config.shape import SHAPE


from hotwheels.amct_pytorch.optimizer.gen_quant_param_record_pass import GenQuantParamRecordPass
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.utils.vars import NON_INSIST_ONNX_TYPES
from hotwheels.amct_pytorch.common.utils import util as UTIL


MODEL_DICT = {
    "elutoconcat":ELUTOCONCAT,
    "reshape":RESHAPE,
    "exptosplit":EXPTOSPLIT,
    "flatten":FLATTEN,
    "slice":SLICE,
    "transpose":TRANSPOSE,
    "tile":TILE,
    "squeeze":SQUEEZE,
    "view":DPN
}

CONFIG_JSON_FILE_PATH = '../resource/record/{}_config.json'
SCALE_OFFSET_FILE_PATH = '../resource/record/{}_scale_offset_record.txt'


class TestGenQuantParamRecordPass(unittest.TestCase):
    """
    Concat -- check
    Split -- check
    Reshape -- check
    Flatten -- check
    Slice -- check
    Transpose -- check
    Tile -- check
    Squeeze -- check
    View -- check
    """
    def setUp(self) -> None:
        self.model = None
        self.graph = None
        self.gen_quan_param_record = None
        self.config_json_file_path = None
        self.scale_offset_file_path = None

    def init_process(self, model_name) -> None:
        # init
        self.model = MODEL_DICT.get(model_name)()
        input_data = Graph.generate_dummy_input([SHAPE.get(model_name)])
        self.graph = Graph.create_graph(self.model, input_data, False)
        self.config_json_file_path = CONFIG_JSON_FILE_PATH.format(model_name)
        self.scale_offset_file_path = SCALE_OFFSET_FILE_PATH.format(model_name)
        Configuration().init(self.config_json_file_path, self.scale_offset_file_path, self.graph)
        # init GenQuantParamRecordPass
        self.gen_quan_param_record = GenQuantParamRecordPass('./test_result', 'GenQuantParamRecordPass')
        # init record
        self.gen_quan_param_record.set_up()


    def generate_output_node_params_test(self):
        matched_nodes = self.get_matching_nodes()
        for node in matched_nodes:
            for record in self.gen_quan_param_record.records.record:
                if node.name != record.key:
                    continue
                layer_param = self.gen_quan_param_record.quant_param_records.layer.add()
                layer_param.name = record.key
                # create output quant param of no insist layer
                self.gen_quan_param_record.generate_output_node_params(layer_param.quant_param, record, node)
                # check quant_param_records generated
                # 1) verify if current node is tail node or not
                if len(layer_param.quant_param.output) == 0:
                    # current node is not tail node when quant_param is empty in general case
                    self.assertEqual(self.get_output_count(node), 0)
                # 2) check if output quant_param follows input quant_param on current no_insist_layer
                record_d = record.value.record_d[0]
                for output in layer_param.quant_param.output:
                    self.assertEqual(output.data_type, UTIL.get_data_cal_type(record_d.num_bits_d))
                    self.assertEqual(output.scale[0], record_d.scale_d)
                    self.assertEqual(output.offset[0], record_d.offset_d)
                # 3) check if num of output params caters for outputs of current layer
                quant_param_output_size = len(layer_param.quant_param.output)
                self.assertEqual(quant_param_output_size, self.get_output_count(node))
                break


    def get_matching_nodes(self):
        matched_nodes = []
        for node in self.graph.nodes:
            if self.gen_quan_param_record.match_pattern(node, None) and\
                    node.type in NON_INSIST_ONNX_TYPES:
                matched_nodes.append(node)
        return matched_nodes

    def get_output_count(self, node):
        if len(node.output_anchors) == 0:
            return 0
        output_anchors = node.output_anchors
        output_count = 0
        for output_anchor in output_anchors:
            peer_input_anchors = output_anchor.get_peer_input_anchor()
            if len(peer_input_anchors) == 0:
                return 0
            for peer_input_anchor in peer_input_anchors:
                if len(peer_input_anchor.node.output_anchors) == 0:
                    output_count = output_count + 1
        return output_count

    def test_generate_output_node_params(self):
        for key in MODEL_DICT:
            self.init_process(key)
            self.generate_output_node_params_test()
