import torch


class CustomLSTMXHC(torch.nn.Module):
    def __init__(self, input_size: int = 10, hidden_size: int = 20,
                 num_layers: int = 1, bias: bool = True,
                 batch_first: bool = False, dropout: float = 0.,
                 bidirectional: bool = False, proj_size: int = 0):
        super(CustomLSTMXHC, self).__init__()
        self.lstm = torch.nn.LSTM(input_size=input_size, hidden_size=hidden_size,
                                  num_layers=num_layers, bias=bias,
                                  batch_first=batch_first, dropout=dropout,
                                  bidirectional=bidirectional, proj_size=proj_size)

    def forward(self, x, h, c):
        return self.lstm(x, (h, c))


class CustomLSTMXHCBid(torch.nn.Module):
    def __init__(self, input_size: int = 10, hidden_size: int = 20,
                 num_layers: int = 1, bias: bool = True,
                 batch_first: bool = False, dropout: float = 0.,
                 bidirectional: bool = True, proj_size: int = 0):
        super(CustomLSTMXHCBid, self).__init__()
        self.lstm = torch.nn.LSTM(input_size=input_size, hidden_size=hidden_size,
                                  num_layers=num_layers, bias=bias,
                                  batch_first=batch_first, dropout=dropout,
                                  bidirectional=bidirectional, proj_size=proj_size)

    def forward(self, x, h, c):
        return self.lstm(x, (h, c))
