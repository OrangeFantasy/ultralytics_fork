#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

package script.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import sys
import shutil
import setuptools

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]
AMCT_LIB_DIR = os.path.join(CUR_DIR, "./hotwheels/amct_pytorch/custom_op")
SUPPORT_TORCH_VERSIONS = ['1.8.1']

os.environ['SOURCE_DATE_EPOCH'] = \
    str(int(os.path.getctime(os.path.realpath(__file__))))


class SetupTool(): # pylint: disable=R0903
    """ tool for setup"""
    def __init__(self):
        self.packages = setuptools.find_packages(exclude = ['amct_pytorch*'])
        self.packages.extend(['hotwheels.custom_op'])
        self.set_version()
        self.set_platform()
        self.set_cuda_version()
        self.setup_args = dict()
        self.add_ops_modules()

    def set_version(self):
        """ set version"""
        version_file = os.path.join(CUR_DIR, 'hotwheels/amct_pytorch', '.version')
        with open(version_file) as fid:
            version = fid.readlines()[0].strip()
            self.version = version

    def set_platform(self):
        """ set platform"""
        if 'sdist' in sys.argv:
            platform = os.getenv('AMCT_PYTORCH_PLATFORM').replace("\n", "")
            self.platform = platform

    def set_cuda_version(self):
        """set cuda version"""
        if 'sdist' in sys.argv:
            cuda_version = os.getenv('CUDA_VERSION').replace("\n", "")
            if cuda_version == '11.3':
                self.cuda_version = '+cu{}'.format(cuda_version.replace('.', ''))
            else:
                self.cuda_version = ''

    def add_ops_modules(self):
        """ set ext_modules for compile amct_pytorch_ops"""
        if 'sdist' in sys.argv:
            return
        # add ext_modules if not setup in source
        from torch.utils import cpp_extension # pylint: disable=E0401, C0415
        ext_modules = [
            cpp_extension.CppExtension(
                # name same with name of amct_ops.py
                name='amct_pytorch_ops',
                sources=['hotwheels/custom_op/src/interface.cpp'],
                include_dirs=[os.path.join(CUR_DIR, 'hotwheels/custom_op/inc/')],
                libraries=['quant_lib_{}'.format(find_torch_version())],
                library_dirs=[AMCT_LIB_DIR])]
        self.setup_args['ext_modules'] = ext_modules
        self.setup_args['cmdclass'] = {
            'build_ext': cpp_extension.BuildExtension
        }


def find_torch_version():
    """ find torch's valid version """
    import torch # pylint: disable=E0401, C0415
    version = torch.__version__
    for support_version in SUPPORT_TORCH_VERSIONS:
        if version.startswith(support_version):
            return support_version
    raise RuntimeError("hotwheels.amct_pytorch cannot support torch %s" % (version))


setup_tools = SetupTool() # pylint: disable=C0103

setuptools.setup(
    name='hotwheels_amct_pytorch',
    version=setup_tools.version,
    description='Advanced Model Compression and Training Toolkit for PyTorch',
    url='',
    packages=setup_tools.packages,
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Programming Language :: C++',
        'Programming Language :: Python :: 3'
    ],
    author='CompanyNameMagicTag',
    license='Apache 2.0',
    extras_require={
        "pytorch": ["1.8.1"]
    },
    install_requires=[
        'interval>=1.0.0',
        'numpy>=1.16.0',
        'pillow>=6.0.0',
        'protobuf>=3.13.0',
        'protobuf<=3.19.0'
    ],
    package_data={
        '': ['.version'],
        'hotwheels.amct_pytorch': ['./proto/*.proto', './capacity/*.csv',
                                   './custom_op/*.so'],
        'hotwheels.custom_op': ['./inc/*.h', './src/interface.cpp', '*.so']
    },
    zip_safe=False,
    **setup_tools.setup_args
)

if 'sdist' in sys.argv:
    shutil.move(
        os.path.join(
            CUR_DIR,
            'dist/hotwheels_amct_pytorch-{}.tar.gz'.format(setup_tools.version)),
        os.path.join(
            CUR_DIR,
            'dist/hotwheels_amct_pytorch{}-{}-py3-none-{}.tar.gz'.format(setup_tools.cuda_version,
                setup_tools.version, setup_tools.platform)))
