#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Base Module of quantized retrain

"""

import numpy as np
import torch
from torch.nn.parameter import Parameter
from hotwheels.amct_pytorch.custom_op.ulq_retrain.ulq_retrain import \
    UlqRetrainFunction
from hotwheels.amct_pytorch.custom_op.utils import copy_tensor
from hotwheels.amct_pytorch.custom_op.utils import tensor
from hotwheels.amct_pytorch.custom_op.retrain_module.act_retrain_module_base \
    import ActRetrainModuleBase


class UlqActRetrainModule(ActRetrainModuleBase):
    """
    Function: Base class module for quantized retrain.
    APIs: __init__, _init_output, acts_forward, get_data_scale, get_data_offset
    """

    def __init__(self, *args, **kwargs):
        super(UlqActRetrainModule, self).__init__(*args, **kwargs)

    def acts_forward(self, inputs):
        """
        Function: activation quantization function.
        Inputs:
            inputs: data used for calibration in torch.tensor.
        """
        if self.cur_batch < 100:
            self.cur_batch += 1

        # do pass operation, nothing done
        act_qat_param = {
            'num_bits': self.act_config.get('num_bits'),
            'ifmr_init': self.act_config.get('ifmr_init'),
            'fixed_min': self.act_config.get('fixed_min'),
        }
        fakequant_inputs, scale, offset, clip_max, clip_min = \
            UlqRetrainFunction.apply(
                inputs, self.acts_clip_max, self.acts_clip_min,
                self.acts_clip_max_pre, self.acts_clip_min_pre, act_qat_param,
                self.cur_batch)
        with torch.no_grad():
            copy_tensor(self.acts_scale, scale)
            copy_tensor(self.acts_offset, offset)
            copy_tensor(self.acts_clip_max, clip_max)
            copy_tensor(self.acts_clip_min, clip_min)
            copy_tensor(self.acts_clip_max_pre, clip_max)
            copy_tensor(self.acts_clip_min_pre, clip_min)
        return fakequant_inputs

    def _init_output(self):
        # Register quantitative parameters.
        self.register_buffer('cur_batch', tensor(0))
        if self.act_config.get('ifmr_init'):
            self.register_parameter('acts_clip_max',
                                    Parameter(tensor(1.0, requires_grad=True)))
            self.register_parameter('acts_clip_min',
                                    Parameter(tensor(1.0, requires_grad=True)))
        else:
            self.register_parameter('acts_clip_max',
                                    Parameter(
                                        tensor(self.act_config.get('clip_max'),
                                                     requires_grad=True)))
            self.register_parameter('acts_clip_min',
                                    Parameter(
                                        tensor(self.act_config.get('clip_min'),
                                                     requires_grad=True)))
        self.register_buffer('acts_clip_max_pre', tensor(np.nan))
        self.register_buffer('acts_clip_min_pre', tensor(np.nan))
        self.register_buffer('acts_scale', tensor(np.nan))
        self.register_buffer('acts_offset', tensor(np.nan))