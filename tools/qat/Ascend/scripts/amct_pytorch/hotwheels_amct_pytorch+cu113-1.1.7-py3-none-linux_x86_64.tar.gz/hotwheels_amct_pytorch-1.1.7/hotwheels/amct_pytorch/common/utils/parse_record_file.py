# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Parse record file.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import collections
import numpy as np
from google.protobuf import text_format  # pylint: disable=E0401
from hotwheels.amct_pytorch.utils.vars import ARQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.utils.vars import SNQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.utils.vars import WEIGHT_NUM_BIT_SET
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.common.utils.util import is_invalid

SCALE_RANGE = [0.0, float("inf")]
CLUSTER_CENTER_RANGE = [-128, 127]
CLUSTER_CENTER_LEN_RANGE = [16, 32]
WEIGHT_OFFSET_RANGE = [0, 0]
SHIFT_N_RANGE = [1, 16]
DATA_BIT_NUM_RANGE = [8, 16]
WEIGHT_BIT_NUM = 8

__all__ = ["RecordFileParserBase", "RecordManager"]


class RecordFileParserBase():
    """
    Function: Parse the information of compression from record_file.
    APIs: read_record_file, parse
    """

    def __init__(self,  # pylint: disable=R0913
                 record_file,
                 graph,
                 model_name,
                 config,
                 records=None):
        """
        Function: init object
        Inputs:
            record_file: a string, the file to parse.
            graph: the graph corresponding to record_file.
            model_name: a string, the model's name.
            config: a dict, including capacity, records_pb2, op_quirer,
                graph_querier, graph_checker
        """
        self.record_file = os.path.realpath(record_file)
        self.graph = graph
        self.model_name = os.path.realpath(model_name)
        self.capacity = config['capacity']
        if records is None:
            self.records = config['records_pb2'].ScaleOffsetRecord()
        else:
            # tensorflow pass the InnerScaleOffsetRecord() to here
            self.records = records
        self.config = config
        self.read_record_file(self.record_file, self.records)

    @classmethod
    def read_record_file(cls, record_file, records):
        ''' read record file to a proto '''
        record_file = os.path.realpath(record_file)
        with open(record_file, 'r') as fid:
            pbtxt_string = fid.read()
            try:
                text_format.Merge(pbtxt_string, records)
            except text_format.ParseError as e:
                raise RuntimeError(
                    "the record_file{%s} cannot be parsered, please ensure "
                    "it matches with scale_offset_record.proto!" % record_file) from e

    def is_records_empty(self):
        ''' check records  '''
        if list(self.records.record) == []:
            return True
        return False

    def parse(self):  # pylint: disable=R0912
        """
        Function: Parse the information of compression.
        Returns:
            layers_params: a dictionary, the information of compression
                containing items as follows:
                data_scale_value：an array, quant factor data's scale.
                data_offset_value：an array, quant factor data's offset.
                weight_scale_value：an array, quant factor weight's scale.
                weight_offset_value：an array, quant factor weight offset.
                dst_type: a string, indicates bit_num(INT4 or INT8).
            skip_fusion_layers: a list containing layers not to do fusion.
        """
        layers_params = collections.OrderedDict()
        skip_fusion_layers = list()
        quantizable_layers = self.config[
            'graph_querier'].get_support_quant_layers(self.graph,
                                                      need_quant=False)
        for record in self.records.record:
            # check key and value exist
            if not record.HasField('key'):
                raise RuntimeError('Cannot find "key" in record file.')
            if not record.HasField('value'):
                raise RuntimeError(
                    "cannot find 'value' in %s in record_file." % record.key)
            # find the layer in graph
            try:
                if hasattr(self.graph, 'get_operation_by_name'):
                    node = self.graph.get_operation_by_name(record.key)
                else:
                    node = self.graph.get_node_by_name(record.key)
            except RuntimeError:
                LOGGER.logw('layer {} not in graph, it might exist in '
                    'training mode.'.format(record.key))
                continue
            except KeyError as e:
                raise RuntimeError(
                    "find %s failure in %s. Please match %s and %s." %
                    (record.key, self.model_name, self.model_name,
                     self.record_file)) from e

            recorder = RecordManager(record, node, self.capacity,
                                     self.config['op_quirer'], self.config['graph_checker'])
            if recorder.get_skip_fusion():
                if node.type in self.capacity.get('FUSE_TYPES'):
                    skip_fusion_layers.append(record.key)
                else:
                    raise RuntimeError(
                        "%s cannot be fused with bn layer, so skip_fusion "
                        "cannot be false in layer %s" %
                        (node.type, record.key))

            if node.name in quantizable_layers:
                # parse value to np.array and store in a dictionary
                layer_params = recorder.parse_quant_value()
                if layer_params:
                    layers_params[record.key] = layer_params
            else:
                raise RuntimeError("layer %s cannot be quantized " % node.name)

        return layers_params, skip_fusion_layers


class RecordManager():
    """
    Function: Parse a record
    APIS: get_key, get_value, get_do_fusion, parse_value
    """

    def __init__(self, record, node, capacity, op_quirer, graph_checker):
        """ init object """
        self.record = record
        self.node = node
        self.capacity = capacity
        self.op_quirer = op_quirer
        self.graph_checker = graph_checker

    @staticmethod
    def check_cluster_center(cluster_center_array):
        """ check whether the cluster center is in [-128, 127]"""
        if len(cluster_center_array) not in CLUSTER_CENTER_LEN_RANGE:
            raise ValueError(
                "The length of cluster center is 16 or 32, but is {}".format(
                    len(cluster_center_array)))
        for value in cluster_center_array:
            if value < CLUSTER_CENTER_RANGE[0] or \
                    value > CLUSTER_CENTER_RANGE[1]:
                raise ValueError("Cluster center should between "
                                 "[-128, 127], but is {}".format(value))

    @classmethod
    def check_layer_params_range(cls, layer_params, layer_name):
        """ Check the range of value in layers_params from record_file."""

        def is_in_range(value_array, min_val, max_val, included=True):
            """ whether value_array is in the range of [min_val, max_val]"""
            if included:
                is_in_range = (value_array >= min_val) & \
                              (value_array <= max_val)
            else:
                is_in_range = (value_array > min_val) & \
                              (value_array < max_val)
            return is_in_range.all()

        # data_num_bits
        def is_valid_data_bit_num(num_bit_list):
            for num_bit in num_bit_list:
                if num_bit != -1 and (num_bit > DATA_BIT_NUM_RANGE[1] \
                                      or num_bit < DATA_BIT_NUM_RANGE[0]):
                    return False
            return True

        if is_invalid(layer_params['data_num_bits']) or not \
                is_valid_data_bit_num(layer_params['data_num_bits']):
            raise ValueError("num_bits of data should be in %s in layer %s" %
                             (DATA_BIT_NUM_RANGE, layer_name))

        # weight_num_bits
        if is_invalid(layer_params['weight_num_bits']) or \
                layer_params['weight_num_bits'] not in WEIGHT_NUM_BIT_SET:
            raise ValueError("weight_num_bits of data should be %d or %d in "
                             "layer %s" % (ARQ_WEIGHT_BIT_NUM,
                                           SNQ_WEIGHT_BIT_NUM, layer_name))

        # offset_d
        for i in range(len(layer_params['data_offset'])):
            num_bits = layer_params['data_num_bits'][i]
            if num_bits == -1:
                continue
            data_offset = layer_params['data_offset'][i]
            data_offset_max = 2 ** (num_bits - 1) - 1
            data_offset_min = -2 ** (num_bits - 1)
            if is_invalid(data_offset) or \
                    data_offset < data_offset_min or \
                    data_offset > data_offset_max:
                raise ValueError("offset_d's value of input %s should be in "
                                 "%s in layer %s, current is %s" % (i,
                                                                    [data_offset_min, data_offset_max], layer_name,
                                                                    data_offset))
        # offset_w
        if is_invalid(layer_params['weight_offset']) or \
                not is_in_range(layer_params['weight_offset'],
                                WEIGHT_OFFSET_RANGE[0],
                                WEIGHT_OFFSET_RANGE[1]):
            raise ValueError("offset_w's value should be 0 in layer %s" %
                             (layer_name))
        # scale_d
        if is_invalid(layer_params['data_scale']) or \
                not is_in_range(layer_params['data_scale'],
                                SCALE_RANGE[0],
                                SCALE_RANGE[1],
                                included=False):
            raise ValueError("scale_d's value should be in positivate range "
                             "of float32 in layer %s" % layer_name)
        # scale_w
        if is_invalid(layer_params['weight_scale']) or \
                not is_in_range(abs(layer_params['weight_scale']),
                                SCALE_RANGE[0],
                                SCALE_RANGE[1],
                                included=False):
            raise ValueError("Absolute scale_w's value should be in positivate range "
                             "of float32 in layer %s" % layer_name)

    def get_key(self):
        """ get key """
        return self.record.key

    def get_value(self):
        """ get value """
        return self.record.value

    def get_skip_fusion(self):
        """ get skip_fusion """
        return self.get_value().skip_fusion

    def parse_quant_value(self):
        """ Parse quant value(scale,offset,shift_bit,dst_type) from record """
        if self.check_quant_value_empty():
            return None

        # read value(scale,offset,shift_bit) from record
        layer_params = collections.OrderedDict()
        # read scale_d and offset_d
        layer_params['data_scale'] = self.get_scale_d()
        layer_params['data_offset'] = self.get_offset_d()
        layer_params['data_num_bits'] = self.get_num_bits_d()
        layer_params['dst_type'] = self.get_dst_type()
        # read scale_w, offset_w and shift_bit
        scale_w_array = self.get_scale_w(
            desirable=self.graph_checker.check_onnx_quantize_type(self.node))
        offset_w_array = self.get_offset_w(
            desirable=self.graph_checker.check_onnx_quantize_type(self.node))
        layer_params['weight_num_bits'] = self.get_num_bits_w(
            desirable=self.graph_checker.check_onnx_quantize_type(self.node))
        layer_params['params'] = self.get_params(
            desirable=self.graph_checker.check_onnx_quantize_type(self.node)
                      and layer_params['weight_num_bits'] == SNQ_WEIGHT_BIT_NUM)

        # optional cluster center
        cluster_center_array = self.get_cluster_center()

        scale_w_array, offset_w_array = \
            self.adjust_scale_offset(scale_w_array, offset_w_array)
        layer_params['weight_scale'] = scale_w_array
        layer_params['weight_offset'] = offset_w_array

        # optional cluster center
        if cluster_center_array is not None:
            RecordManager.check_cluster_center(cluster_center_array)
            layer_params['cluster_center'] = cluster_center_array

        # check value
        RecordManager.check_layer_params_range(layer_params, self.get_key())

        # astype to necessary type
        layer_params['data_offset'] = \
            layer_params['data_offset'].astype(np.int32)
        layer_params['weight_offset'] = \
            layer_params['weight_offset'].astype(np.int8)

        # optional cluster center
        if cluster_center_array is not None:
            layer_params['cluster_center'] = \
                layer_params['cluster_center'].astype(np.int8)

        return layer_params

    def check_quant_value_empty(self):
        """check whether the value in record is empty """
        value = self.get_value()
        if value.record_d or value.scale_w or \
                value.offset_w or value.shift_bit:
            return False
        return True

    def get_dst_type(self):
        """get dst type"""
        if hasattr(self.record.value, 'dst_type'):
            if 'AvgPool' in self.record.key and self.record.value.dst_type == 'INT4':
                raise RuntimeError('AvgPool in INT4 not supported. Please Check record file.')
            if self.record.value.dst_type in ('INT8', 'INT4'):
                return self.record.value.dst_type
            raise RuntimeError('Do not support dst_type %s in record file'
                               % self.record.value.dst_type)
        return 'INT8'

    def get_scale_d(self):
        ''' get scale_d '''
        record = self.record
        if not record.value.record_d:
            raise RuntimeError(
                "Cannot find record_d of layer %s in record_file" %
                (self.get_key()))
        scale_d = list()
        for i in range(len(record.value.record_d)):
            for record_d in record.value.record_d:
                if record_d.index == i:
                    scale_d.append(record_d.scale_d)
                    break
        scale_d_array = np.array(scale_d, dtype=np.float32)
        return scale_d_array

    def get_offset_d(self):
        ''' get offset_d '''
        record = self.record
        if not record.value.record_d:
            raise RuntimeError(
                "Cannot find record_d of layer %s in record_file" %
                (self.get_key()))
        offset_d = list()
        for i in range(len(record.value.record_d)):
            for record_d in record.value.record_d:
                if record_d.index == i:
                    offset_d.append(record_d.offset_d)
                    break
        offset_d_array = np.array(offset_d, dtype=np.int32)
        if self.node.type == 'MatMul' and offset_d_array.any():
            raise RuntimeWarning("value of offset on matmul layer {}"
                                 " in record file should be zero".format(self.node.name))
        return offset_d_array

    def get_num_bits_d(self):
        ''' get num_bits_d '''
        record = self.record
        if not record.value.record_d:
            raise RuntimeError(
                "cannot find record_d of layer %s in record_file" %
                (self.get_key()))
        num_bits_list = list()
        for i in range(len(record.value.record_d)):
            for record_d in record.value.record_d:
                if record_d.index == i:
                    num_bits_list.append(record_d.num_bits_d)
                    break
        num_bits_array = np.array(num_bits_list, dtype=np.int32)
        return num_bits_array

    def get_num_bits_w(self, desirable=True):
        ''' get num_bits_w '''
        record = self.record
        if desirable:
            if not record.value.num_bits_w:
                raise RuntimeError(
                    "cannot find num_bits_w of layer %s in record_file" %
                    (self.get_key()))
            return record.value.num_bits_w
        else:
            if record.value.num_bits_w:
                raise RuntimeError(
                    "find num_bits_w of layer %s in record_file" %
                    (self.get_key()))
            return ARQ_WEIGHT_BIT_NUM

    def get_scale_w(self, desirable=True):
        ''' get scale_w '''
        record = self.record
        scale_w = list()
        if desirable:
            if not record.value.scale_w:
                raise RuntimeError(
                    "cannot find scale_w of layer %s in record_file" %
                    (self.get_key()))
            scale_w.extend(record.value.scale_w)
        else:
            if record.value.scale_w:
                raise RuntimeError(
                    "find undesirable scale_w of layer %s in record_file" %
                    (self.get_key()))
            scale_w.extend([1.0])
        scale_w_array = np.array(scale_w, dtype=np.float32)

        return scale_w_array

    def get_offset_w(self, desirable=True):
        """ get offset_w """
        record = self.record
        offset_w = list()
        if desirable:
            if not record.value.offset_w:
                raise RuntimeError(
                    "cannot find offset_w of layer %s in record_file" %
                    (self.get_key()))
            offset_w.extend(record.value.offset_w)
        else:
            if record.value.offset_w:
                raise RuntimeError(
                    "find undesirable offset_w of layer %s in record_file" %
                    (self.get_key()))
            offset_w.extend([0.0])
        offset_w_array = np.array(offset_w, dtype=np.int32)

        return offset_w_array

    def get_params(self, desirable=True):
        """ get params """
        record = self.record
        if desirable:
            if not record.value.params:
                raise RuntimeError(
                    "cannot find params of layer %s in record_file" %
                    (self.get_key()))
        else:
            if record.value.params:
                raise RuntimeError(
                    "find undesirable params of layer %s in record_file" %
                    (self.get_key()))
        return record.value.params

    def get_cluster_center(self):
        """ optional value, get cluster_center """
        record = self.record
        cluster_center = list()
        if not hasattr(record.value, 'cluster'):
            cluster_center_array = None
        elif not record.value.cluster:
            cluster_center_array = None
        else:
            cluster_center.extend(record.value.cluster)
            cluster_center_array = np.array(cluster_center, dtype=np.int32)

        return cluster_center_array

    def adjust_scale_offset(self, scale_w_array, offset_w_array):
        """
        Function: Adjust the shape of scale and offset according to operation.
            if operation is conv2d and scale_w_array has multiple numbers, then
            scale_w_array's shape will be reshaped as [cout, 1, 1, 1]
        Inputs:
            scale_w_array: np.array, scale_w
            offset_w_array: np.array, offset_w
        Return:
            scale_w_array: np.array, reshaped scale_w
            offset_w_array: np.array, reshaped offset_w
        """
        operation = self.node
        err_prefix = ""

        if scale_w_array.size != offset_w_array.size:
            raise RuntimeError(
                "scale_w's length, offset_w's length %s should be equal "
                "in layer %s." % (err_prefix, operation.name))

        if scale_w_array.size == 1:
            channel_wise = False
        else:
            channel_wise = True

        # check length and reshape
        shape_except, scale_length_except = self.get_possible_length(
            channel_wise)
        if scale_w_array.size != scale_length_except:
            raise RuntimeError("scale_w's length, offset_w's length %s"
                               "should be equal to the 'C' of outputs of layer %s if they "
                               "are not a single value. Cannot support to quantize %s" % (
                                   err_prefix, operation.name, operation.name))

        scale_w_array = np.reshape(scale_w_array, shape_except)
        offset_w_array = np.reshape(offset_w_array, shape_except)

        return scale_w_array, offset_w_array

    def get_possible_length(self, channel_wise=True):
        """Get possible length for """
        operation = self.node
        if operation.type in ('AvgPool', 'AveragePool'):
            shape_except = []
            scale_length_except = 1
        else:
            if hasattr(self.op_quirer, 'get_op_scale_shape'):
                quire_func = getattr(self.op_quirer, 'get_op_scale_shape')
            else:
                quire_func = getattr(self.op_quirer, 'get_scale_shape')
            shape_except, scale_length_except = quire_func(
                self.node, channel_wise)
        return shape_except, scale_length_except


