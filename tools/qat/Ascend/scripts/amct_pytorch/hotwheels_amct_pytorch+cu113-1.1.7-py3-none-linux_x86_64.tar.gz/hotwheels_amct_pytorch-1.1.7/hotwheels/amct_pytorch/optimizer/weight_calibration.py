#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Do caliration for weight, sacle and offset for weight will be finded and
weight is fake_quantized.

"""
import os
from collections import OrderedDict
import torch
import numpy as np
from google.protobuf import text_format
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from hotwheels.amct_pytorch.optimizer.base_module_fusion_pass import BaseModuleFusionPass
from hotwheels.amct_pytorch.proto import \
    scale_offset_record_pb2  # pylint: disable=no-name-in-module
from hotwheels.amct_pytorch.custom_op.arq.arq import weight_cali_tensor
from hotwheels.amct_pytorch.custom_op.snq.snq import snq_weight_cali_tensor
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    record_weights_scale_offset
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_TYPES
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import RNN_TYPES
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper

from hotwheels.amct_pytorch.common.utils.record_file_operator import WeightQuantParam

from hotwheels.amct_pytorch.common.utils.files import (
    FILE_ACCESS_FLAG,
    FILE_MODE,
    FILE_READ_FLAG
)


class WeightsCalibrationPass(BaseModuleFusionPass):
    """
    Function: Do caliration for weight, sacle and offset for weight will
        be found and weight is fake_quantized.
    APIs: set_up, tear_down, match_pattern, do_pass
    """

    def __init__(self, is_retrain=False):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseModuleFusionPass.__init__(self)
        self.is_retrain = is_retrain
        if self.is_retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.record_file_path = self.conf.get_record_file_path()

    @staticmethod
    def adjust_deconv_weight_np_shape(node_deconv, weights_array):
        """Adjust deconv's weights' shape to fit fuse_conv_bn function """
        attr_helper = AttributeProtoHelper(node_deconv.proto)
        group = 1
        if attr_helper.has_attr('group'):
            group = attr_helper.get_attr_value('group')

        weight_shape = weights_array.shape
        new_shape = tuple([group, -1] + list(weight_shape)[1:])
        weights_array = np.reshape(weights_array, new_shape)

        weights_array = np.transpose(weights_array, (0, 2, 1, 3, 4))

        weight_shape = weights_array.shape
        new_shape = tuple([-1] + list(weight_shape)[2:])
        weights_array = np.reshape(weights_array, new_shape)

        return weights_array

    @staticmethod
    def adjust_deconv_weight_shape(node_deconv, weights_tensor):
        """Adjust deconv's weights' shape to fit fuse_conv_bn function """
        device = weights_tensor.device
        weights_array = weights_tensor.cpu().numpy()

        weights_array = WeightsCalibrationPass.adjust_deconv_weight_np_shape(
            node_deconv, weights_array)
        weights_tensor = torch.from_numpy(weights_array).to(device)

        return weights_tensor

    @staticmethod
    def cali_tensor(data_tensor, wts_param, object_name):
        params = None
        if wts_param.get('wts_algo') == 'arq_quantize':
            scale, offset, calied_weight = weight_cali_tensor(data_tensor,
                                                              wts_param)
        elif wts_param.get('wts_algo') == 'snq_quantize':
            scale, offset, calied_weight, params = snq_weight_cali_tensor(
                data_tensor, wts_param)
        else:
            LOGGER.logi('wts algo with {} of layer {} is not supported!'.
                        format(wts_param['wts_algo'], object_name))
            raise RuntimeError('wts algo with {} of layer {} is not '
                               'supported!'.format(wts_param['wts_algo'],
                                                   object_name))
        if params is not None:
            params = params.cpu().numpy().tobytes()
        cali_tensors = (scale, offset, calied_weight, params)
        return cali_tensors

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with os.fdopen(os.open(self.record_file_path, FILE_READ_FLAG, FILE_MODE), 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with os.fdopen(os.open(self.record_file_path, FILE_ACCESS_FLAG, FILE_MODE), 'w') as record_write_file:
            record_write_file.write(
                text_format.MessageToString(self.records, as_utf8=True))

    def match_pattern(self, module, name, graph=None):
        """
        Function:Match the module to be quantized in model
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure, not necessary
        Return: True: matched
                False: mismatch
        """
        if self.is_retrain:
            if name in self.conf.get_inserted_depthwise_layers():
                return True
            return False
        if type(module).__name__ not in QUANTIZABLE_TYPES:
            return False
        if type(module).__name__ in RNN_TYPES:
            return False
        if name not in self.conf.get_quant_config():
            return False
        return True

    def do_pass(self, model, object_module, object_name, graph=None):  # pylint: disable=R0914
        """
        Function: Do actual Insert IFMR module
        Parameters: model: torch.nn.Module, the model to be modified.
                    object_module: module to process
                    object_name: name of object_module
                    graph: graph structure, not necessary
        Return: None
        """
        # Step0: get weights' information for quantization
        object_node = graph.get_node_by_name(object_name)
        layer_config = self.conf.get_layer_config(object_name)
        if self.is_retrain:
            wts_param = OrderedDict()
            wts_param["wts_algo"] = "arq_quantize"
            wts_param['num_bits'] = 8
            wts_param['channel_wise'] = True
            wts_param['with_offset'] = False
        else:
            wts_param = layer_config.get(WEIGHT_QUANT_PARAMS)
        data_tensor = object_module.weight.data

        # get quantization params of weight calibration
        scale, offset, params = [], [], None
        if type(object_module).__name__ == 'ConvTranspose2d':
            # get quantization params with group
            data_tensor = WeightsCalibrationPass.adjust_deconv_weight_shape(
                object_node, data_tensor)
            scale, offset, calied_weight, \
            params = WeightsCalibrationPass.cali_tensor(
                data_tensor, wts_param, object_name)
            calied_weight = WeightsCalibrationPass.adjust_deconv_weight_shape(
                object_node, calied_weight)
        else:
            scale, offset, calied_weight, params = WeightsCalibrationPass. \
                cali_tensor(data_tensor, wts_param, object_name)

        # update weight data with calied weight
        object_module.weight.data = calied_weight

        # set weights data to graph
        weight_param = QuantOpInfo.get_weight_node(object_node)
        weight_helper = TensorProtoHelper(weight_param.proto)

        calied_weight_raw = object_module.weight.data
        # transpose torch.nn.Linear.weight in (Cout, Cin) to ONNX (Cin, Cout).
        if object_node.type == 'MatMul' and type(object_module).__name__ == 'Linear':
            need_transpose = True
            # Trans op may already be inserted in exported ONNX model
            if object_node.has_attr('with_weights_trans'):
                if object_node.get_attr('with_weights_trans'):
                    need_transpose = False
            if need_transpose:
                calied_weight_raw = calied_weight_raw.transpose(1, 0)
        calied_weight_raw = calied_weight_raw.flatten().cpu().numpy().tolist()

        weight_helper.clear_data()
        weight_helper.set_data(calied_weight_raw, 'FLOAT')

        weight_quant_param = WeightQuantParam(scale=scale, offset=offset, num_bits=wts_param.get('num_bits'))

        # save the quantize information
        record_weights_scale_offset(self.records, object_name, weight_quant_param, params)

        LOGGER.logd('Do layer \'{}[{}]\' weights calibration success!'
                    .format(object_node.name, wts_param['wts_algo']),
                    'WeightsCalibrationPass')
