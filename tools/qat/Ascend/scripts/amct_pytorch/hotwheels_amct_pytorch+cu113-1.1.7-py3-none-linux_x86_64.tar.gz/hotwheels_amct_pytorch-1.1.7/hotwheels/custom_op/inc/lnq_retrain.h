/*
 * Copyright (c) CompanyNameMagicTag
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0. You may not use
 * this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief lnq algorithm custom op C++ implement
 *
 * @file lnq_retrain.h
 *
 * @version 1.0
 */
#ifndef LNQ_RETRAIN_H
#define LNQ_RETRAIN_H

#include <torch/extension.h>
#include <vector>
#include <iostream>
#include "util.h"

struct LnqParam {
    LnqParam(int numTrackedBatches, bool training, bool isCentroidSym, \
    int clustFreq, int maxIter, float minDistance): numTrackedBatches(numTrackedBatches),
        training(training),
        isCentroidSym(isCentroidSym),
        clustFreq(clustFreq),
        maxIter(maxIter),
        minDistance(minDistance)
    {
    }
    int numTrackedBatches;
    bool training;
    bool isCentroidSym;
    int clustFreq;
    int maxIter;
    float minDistance;
};

std::vector<torch::Tensor> LnqRetrainForward(
    torch::Tensor inputTensor,
    torch::Tensor clipMax,
    int numBits,
    torch::Tensor clustCentroids,
    LnqParam lnqParam);

std::vector<torch::Tensor> LnqRetrainBackward(
    torch::Tensor gradOutputs,
    torch::Tensor inputTensor,
    torch::Tensor clipMax,
    torch::Tensor clustCentroids);

std::vector<torch::Tensor> LnqExportParam(
    torch::Tensor inputTensor,
    torch::Tensor clipMax,
    torch::Tensor clustCentroids);

torch::Tensor LnqDequant(
    torch::Tensor inputTensor,
    torch::Tensor cluster);

torch::Tensor LnqQuant(
    torch::Tensor inputTensor,
    torch::Tensor cluster);
#endif