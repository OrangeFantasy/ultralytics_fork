#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

ArqRetrain Function

"""

from torch.autograd import Function # pylint: disable=E0401

import hotwheels.amct_pytorch.custom_op.amct_pytorch_ops as amct_pytorch_ops
from hotwheels.amct_pytorch.custom_op.utils import check_quant_data


class ArqRetrainFunction(Function):
    """
    Function: Run weight retrain process for quantization of the given layer.
    APIs: forward, backward
    """
    @staticmethod
    def forward(ctx, # pylint: disable=W0221, W0613
                weight_tensor, wts_param, node_type):
        """
        Function: ArqRetrain foward funtion.
        """
        # check weight tensor
        check_quant_data(weight_tensor, 'weight')
        if node_type in ["Conv", "ConvTranspose"]:
            weight_size = weight_tensor.size()
            weight_tensor = weight_tensor.reshape([weight_size[0], -1])

        results = amct_pytorch_ops.arq_retrain_forward( # pylint: disable=E1101
            weight_tensor,
            wts_param['num_bits'],
            wts_param['channel_wise'],
            wts_param['with_offset'])
        is_quant, quantized_weight, scale, offset = results

        if is_quant == -1:
            raise RuntimeError("Weight quant with ARQ failed!")

        # restore shape
        if node_type in ["Conv", "ConvTranspose"]:
            weight_tensor = weight_tensor.reshape(weight_size)
            quantized_weight = quantized_weight.reshape(weight_size)

        return quantized_weight, scale, offset

    @staticmethod
    def backward(ctx, # pylint: disable=W0221, W0613
                 grad_outputs,
                 grad_scale, grad_offset): # pylint: disable=W0613
        """
        Function: ArqRetrain backward funtion required by torch torch.autograd.
        """
        grad_input = amct_pytorch_ops.arq_retrain_backward( # pylint: disable=E1101
            grad_outputs)
        return grad_input, None, None
