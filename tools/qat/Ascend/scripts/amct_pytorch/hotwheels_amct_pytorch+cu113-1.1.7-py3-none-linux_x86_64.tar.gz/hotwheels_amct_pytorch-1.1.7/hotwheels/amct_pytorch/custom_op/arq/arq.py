#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quant weight by ARQ.

"""
import torch # pylint: disable=E0401
from hotwheels.amct_pytorch.custom_op.amct_pytorch_ops \
    import arq_cali # pylint: disable=E0611
from hotwheels.amct_pytorch.custom_op.amct_pytorch_ops \
    import arq_real # pylint: disable=E0611
from hotwheels.amct_pytorch.custom_op.utils import check_quant_data
from hotwheels.amct_pytorch.custom_op.utils import check_scale_offset

__all__ = ['weight_cali_tensor', 'weight_quant_np']


def weight_cali_tensor(weight_tensor, wts_param):
    """
    Function: Do calibration on weight_tensor
    Inputs:
        weight_tensor: torch.tensor, weight to be calibrated
        wts_param: a dict, parameters for calibration
        module_type: a string, type of layer weight_tensor attached to.
    Returns:
        scale_list: a 1-dim list, scale of weight_tensor
        offset_list: a 1-dim list, offset of weight_tensor
        calied_weight: torch.tensor, calibrated weight
    """
    # data's shape should be [channle_out, -1]
    if wts_param['wts_algo'] == 'arq_quantize':
        return weight_arq(weight_tensor, wts_param)

    raise RuntimeError("Unsupport wts_algo %s " % (wts_param['wts_algo']))


def weight_arq(weight_tensor, wts_param):
    """
    Function: Do calibration on weight_tensor with 'ARQ' algorithm
    Inputs:
        weight_tensor: torch.tensor, weight to be calibrated
        wts_param: a dict, parameters for calibration
        module_type: a string, type of layer weight_tensor attached to.
    Returns:
        scale_list: a 1-dim list, scale of weight_tensor
        offset_list: a 1-dim list, offset of weight_tensor
        calied_weight: torch.tensor, calibrated weight
    """
    # only 2-D tensor is valid for arq_cpp.cali()
    need_reshape = weight_tensor.dim() > 2
    if need_reshape:
        weight_size = weight_tensor.size()
        weight_tensor = weight_tensor.reshape([weight_size[0], -1])

    check_quant_data(weight_tensor, 'weight')

    status, scale, offset, calied_weight = arq_cali(
        weight_tensor, wts_param['num_bits'],
        wts_param['channel_wise'], wts_param['with_offset'])
    if status != 0:
        raise RuntimeError("Weight calibration with ARQ failed!")

    scale_list = scale.cpu().numpy().tolist()
    offset_list = offset.cpu().numpy().tolist()
    # restore shape
    if need_reshape:
        calied_weight = calied_weight.reshape(weight_size)

    return scale_list, offset_list, calied_weight


def weight_quant_np(weight_np, scale_list, offset_list, num_bit):
    """
    Function: Quant weight_tensor from float32 to int8
    Inputs:
        weight_np: np array, weight to be quant
        scale_list: a list, scale of weight_np
        offset_list: a list, offset of weight_np
        num_bit: a int number, bit the weight will be quant to
        module_type: a string, type of layer weight_tensor attached to.
    Returns:
        int_weight_np: np array, the weight of int8
    """

    weight_tensor = torch.from_numpy(weight_np).to('cpu')
    scale = torch.tensor(scale_list).reshape([-1]).to('cpu')
    offset = torch.tensor(offset_list).reshape([-1]).to('cpu')

    need_reshape = weight_tensor.dim() > 2
    if need_reshape:
        weight_size = weight_tensor.size()
        weight_tensor = weight_tensor.reshape([weight_size[0], -1])

    check_quant_data(weight_tensor, 'weight')
    check_scale_offset(scale, offset)

    num_bit = 8
    is_quant, int_weight_tensor = arq_real(
        weight_tensor, scale, offset, num_bit)

    if is_quant != 0:
        raise RuntimeError("Weight quant with ARQ failed!")

    if need_reshape:
        int_weight_tensor = int_weight_tensor.reshape(weight_size)
    int_weight_np = int_weight_tensor.numpy()

    return int_weight_np
