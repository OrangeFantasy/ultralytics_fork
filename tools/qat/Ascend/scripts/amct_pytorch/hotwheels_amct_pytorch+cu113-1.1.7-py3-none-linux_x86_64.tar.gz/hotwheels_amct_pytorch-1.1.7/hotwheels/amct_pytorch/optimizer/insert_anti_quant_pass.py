#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert AscendAntiQuant in the graph

"""
from onnx import onnx_pb  # pylint: disable=import-error
from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import MULTI_INPUT_ONNX_TYPES
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.attrs_list import ATTR_NODE_EQUIVALENT_OUTPUT
from hotwheels.amct_pytorch.utils.attrs_list import \
    ATTR_NODE_EQUIVALENT_OBJECT_LAYER


class InsertAntiQuantPass(BaseFusionPass):
    """
    Function: Insert AscendAntiQuant
    APIs: match_pattern, do_pass
    """

    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
            num_bits: int number indicating the bit to be quanted such 8
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    @staticmethod
    def skip_avg_pool(object_node, peer_node):
        object_name = object_node.name
        if object_node.type == 'AveragePool' and peer_node.type == 'Pad':
            output_anchor = peer_node.get_output_anchor(0)
            if len(output_anchor.get_peer_input_anchor()) == 1:
                # If AveragePool with pool, add anti quant before it
                if peer_node.name == '%s_pad' % (object_name):
                    object_node = peer_node
                    input_anchor = object_node.get_input_anchor(0)
                    peer_output_anchor = input_anchor.get_peer_output_anchor()
                    peer_node = peer_output_anchor.node
        return object_node, peer_node

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type not in NO_WEIGHT_QUANT_ONNX_TYPES:
            return False
        if node.name not in self.records:
            return False
        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actually inserting AscendAntiQuant.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        object_name = object_node.name
        object_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, object_name)
        object_node.set_attr(ATTR_NODE_EQUIVALENT_OUTPUT, object_name)

        length = len(object_node.input_anchors) if object_node.type in MULTI_INPUT_ONNX_TYPES else 1

        for index in range(length):
            input_anchor = object_node.get_input_anchor(index)
            node_index = input_anchor.index
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            peer_node = peer_output_anchor.node
            object_node, peer_node = InsertAntiQuantPass.skip_avg_pool(
                object_node, peer_node)
            if peer_node.type != 'AscendQuant':
                continue
            attr_helper = AttributeProtoHelper(peer_node.proto)
            scale = 1 / attr_helper.get_attr_value('scale')
            offset = attr_helper.get_attr_value('offset')
            quant_bit = attr_helper.get_attr_value('quant_bit')

            # Step1: add a new_node
            anti_quant_proto = construct_anti_quant_node(
                inputs=['.'.join([object_name, 'anti_quant',
                                  'input{}'.format(node_index)])],
                outputs=['.'.join([object_name, 'anti_quant',
                                   'output{}'.format(node_index)])],
                attrs={
                    'scale': scale,
                    'offset': offset,
                    'quant_bit': quant_bit
                },
                layer_name=object_name,
                index=node_index)
            anti_quant_node = graph.add_node(anti_quant_proto)
            anti_quant_node.set_attr('object_node', object_name)

            # Step2: Relink nodes in th graph
            # remove output links
            peer_output_anchor_index = peer_output_anchor.index
            graph.remove_edge(peer_node, peer_output_anchor_index,
                              object_node, node_index)
            # add links
            graph.add_edge(peer_node, peer_output_anchor_index,
                           anti_quant_node, 0)
            graph.add_edge(anti_quant_node, 0, object_node, node_index)

            LOGGER.logd("Insert quant layer '{}' before '{}' "
                        "success!".format(anti_quant_node.name, object_name),
                        'InsertAntiQuantPass')



def construct_anti_quant_node(inputs,  # pylint: disable=no-member
                              outputs,
                              attrs,
                              layer_name,
                              index):
    """
    Function: construct quant node in onnx
    Inputs:
        input: a list of inputs' name
        output: a list of outputs' name
        attrs: a dict of attrs including
            scale: numpy.array
            offset: numpy.array
            quant_bit: a number
        quantize_layer: a string, layer to be quantized
    """
    node_proto = onnx_pb.NodeProto()

    node_proto.name = '.'.join([layer_name, 'anti_quant{}'.format(index)])
    node_proto.op_type = 'AscendAntiQuant'
    node_proto.input.extend(inputs)  # pylint: disable=E1101
    node_proto.output.extend(outputs)  # pylint: disable=E1101

    attr_helper = AttributeProtoHelper(node_proto)
    attr_helper.set_attr_value('scale', 'FLOAT', attrs['scale'])
    attr_helper.set_attr_value('offset', 'FLOAT', attrs['offset'])
    attr_helper.set_attr_value('quant_bit', 'INT', attrs['quant_bit'])

    return node_proto
