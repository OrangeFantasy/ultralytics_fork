#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantization module after pooling, eltwise layer encapsulation

"""
import torch # pylint: disable=E0401
from hotwheels.amct_pytorch.custom_op.comp_module.comp_module_base \
    import CompModuleBase


class CompModuleWithoutWeight(CompModuleBase): # pylint: disable=R0903
    """
    Function: Quantization module class after conv2d encapsulation.
    APIs: __init__, forward
    """
    def __init__(self, module, act_config=None, wts_config=None, common_config=None):
        super(CompModuleBase, self).__init__()
        self.common_config = common_config
        self.act_config = act_config
        self.wts_config = wts_config
        input_num = self.common_config['num_of_input']
        for index in range(input_num):
            if common_config['skip_quant_index'] == index:
                skip_quant = True
            else:
                skip_quant = False
            retrain_module = CompModuleBase(module,
                                            act_config=act_config[index],
                                            wts_config=wts_config, 
                                            common_config=common_config,
                                            skip_quant=skip_quant,
                                            index=index)
            self.add_module('retrain_module%d' % index, retrain_module)
        self.module = module

    def update_shape(self, shapes):
        self._modules['retrain_module0'].replaced_module.shapes = shapes

    def forward(self, *inputs):
        """
        Defines the computation performed at every call.
        Should be overridden by all subclasses.
        """
        if len(inputs) > 1:
            compressed_inputs_list = list()
            for index, input_item in enumerate(inputs):
                if 'retrain_module%d' % index not in self._modules.keys():
                    compressed_inputs = input_item
                else:
                    compressed_inputs, _ = \
                        self._modules['retrain_module%d' % index].forward(
                            inputs[index])
                compressed_inputs_list.append(compressed_inputs)
            with torch.enable_grad():
                output = self.module.forward(*compressed_inputs_list)
        else:
            compressed_inputs, _ = \
                self._modules['retrain_module0'].forward(*inputs)
            # Forward
            with torch.enable_grad():
                output = self.module.forward(compressed_inputs)
        return output
