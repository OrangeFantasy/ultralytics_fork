#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Operation functions for scale and offset record file

"""

import sys
from collections import namedtuple
from hotwheels.amct_pytorch.utils.log import LOGGER

DBL_EPSILON = sys.float_info.epsilon

WeightQuantParam = namedtuple('WeightQuantParam', ['scale', 'offset', 'num_bits'])


def record_weights_scale_offset(records, layer_name, weight_quant_param, params=None):
    """
    Function: Write scale_w and offset_w to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                scale: vector of scale_w
                offset: vector of offset_w
                num_bits_w: weight num bit
    Return: None
    """
    done_flag = False
    for record in records.record:
        if record.key == layer_name:
            record.value.scale_w[:] = weight_quant_param.scale
            record.value.offset_w[:] = weight_quant_param.offset
            if weight_quant_param.num_bits:
                record.value.num_bits_w = weight_quant_param.num_bits
            if params is not None:
                record.value.params = params
            done_flag = True
            break
    if not done_flag:
        record = records.record.add()
        record.key = layer_name
        record.value.scale_w[:] = weight_quant_param.scale
        record.value.offset_w[:] = weight_quant_param.offset
        if weight_quant_param.num_bits:
            record.value.num_bits_w = weight_quant_param.num_bits
        if params is not None:
            record.value.params = params


def record_weights_centroids(records, layer_name, centroids=None):
    """
    Function: Write scale_w and offset_w to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                centroids: centroid of weight
    Return: None
    """
    done_flag = False
    for record in records.record:
        if record.key == layer_name:
            if centroids is not None:
                record.value.centroids[:] = centroids.cpu().numpy()
            done_flag = True
            break
    if not done_flag:
        record = records.record.add()
        record.key = layer_name
        if centroids is not None:
            record.value.centroids[:] = centroids.cpu().numpy().data


def record_skip_status(records, layer_name, is_skip_fusion):
    """
    Function: Write scale_w and offset_w to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                scale: vector of scale_w
                offset: vector of offset_w
    Return: None
    """
    done_flag = False
    for record in records.record:
        if record.key == layer_name:
            record.value.skip_fusion = is_skip_fusion
            done_flag = True
            break
    if not done_flag:
        record = records.record.add()
        record.key = layer_name
        record.value.skip_fusion = is_skip_fusion


def read_weights_scale_offset(records, layer_name):
    """
    Function: Read scale_w and offset_w from record file
    Parameters: records: ScaleOffsetRecord() object to read
                layer_name: layer name of scale_w, offset_w
    Return: scale: vector of scale_w
            offset: vector of offset_w
    """
    done_flag = False
    scale = []
    offset = []
    params = None
    centroids = None
    weight_clip_max = None
    for record in records.record:
        if record.key == layer_name:
            # Read scale_w from record file
            if not record.value.scale_w:
                raise RuntimeError("Cannot find scale_w of layer '{}' "
                                   "in record file".format(layer_name))
            scale.extend(record.value.scale_w)
            # Read offset_w from record file
            if not record.value.offset_w:
                raise RuntimeError("Cannot find offset_w of layer \'{}\' "
                                   "in record file".format(layer_name))
            offset.extend(record.value.offset_w)
            if record.value.params:
                params = record.value.params
            done_flag = True
            break
    if not done_flag:
        raise RuntimeError("Cannot find layer '{}' in record "
                           "file".format(layer_name))
    return scale, offset, params


def record_shift_bits(records, layer_name, shift_bit):
    """
    Function: Write shift_bit to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                shift_bit: vector of shift_bit
    Return: None
    """
    done_flag = False
    for record in records.record:
        if record.key == layer_name:
            record.value.shift_bit[:] = shift_bit
            done_flag = True
            break
    if not done_flag:
        record = records.record.add()
        record.key = layer_name
        record.value.shift_bit[:] = shift_bit


def read_shift_bits(records, layer_name):
    """
    Function: Read the number of bit to shift from record file
    Parameters: records: ScaleOffsetRecord() object to read
                layer_name: layer name to read shift_bits
    Return: : shift_bits: the number of bit to shift
    """
    shift_bits = []
    for record in records.record:
        if record.key == layer_name:
            if record.value.shift_bit:
                shift_bits.extend(record.value.shift_bit)
            break
    else:
        raise RuntimeError("Cannot find layer '{}' in record "
                           "file".format(layer_name))

    return shift_bits


ActivationQuantParam = namedtuple('ActivationQuantParam', ['scale', 'offset', 'index', 'num_bits'])


def record_activation_scale_offset(records, layer_name, activation_quant_param):
    """
    Function: Write scale_w and offset_w to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                scale: vector of scale_w
                offset: vector of offset_w
    Return: None
    """
    key_found = False
    for record in records.record:
        if record.key == layer_name:
            record_found = False
            for record_d in record.value.record_d:
                if record_d.index == activation_quant_param.index:
                    record_d.scale_d = activation_quant_param.scale
                    record_d.offset_d = activation_quant_param.offset
                    record_d.num_bits_d = get_num_bits_d(activation_quant_param.num_bits, record_d.num_bits_d)
                    record_found = True
                    break
            if not record_found:
                record_d = record.value.record_d.add()
                record_d.scale_d = activation_quant_param.scale
                record_d.offset_d = activation_quant_param.offset
                record_d.index = activation_quant_param.index
                record_d.num_bits_d = get_num_bits_d(activation_quant_param.num_bits, record_d.num_bits_d)
            key_found = True
            break
    if not key_found:
        record = records.record.add()
        record.key = layer_name
        record_d = record.value.record_d.add()
        record_d.scale_d = activation_quant_param.scale
        record_d.offset_d = activation_quant_param.offset
        record_d.index = activation_quant_param.index
        record_d.num_bits_d = get_num_bits_d(activation_quant_param.num_bits, record_d.num_bits_d)


def get_num_bits_d(num_bits, record_d_num_bits):
    if num_bits is not None:
        return num_bits
    return record_d_num_bits


def read_activation_scale_offset(records, layer_name, index=0):
    """
    Function: Read scale_d and offset_d from record file
    Parameters: records: ScaleOffsetRecord() object to read
                layer_name: layer name of scale_d, offset_d
    Return: scale: scalar of scale_d
            offset: scalar of offset_d
    """
    scale = 1
    offset = 0
    num_bits_d = 0
    for record in records.record:
        if record.key != layer_name:
            continue
        for record_d in record.value.record_d:
            if record_d.index != index:
                continue
            if record_d.HasField('scale_d') and record_d.HasField('offset_d'):
                scale = record_d.scale_d
                offset = record_d.offset_d
                num_bits_d = record_d.num_bits_d
                return scale, offset, num_bits_d
    raise RuntimeError("Cannot find layer '{}' in record "
                       "file".format(layer_name))


