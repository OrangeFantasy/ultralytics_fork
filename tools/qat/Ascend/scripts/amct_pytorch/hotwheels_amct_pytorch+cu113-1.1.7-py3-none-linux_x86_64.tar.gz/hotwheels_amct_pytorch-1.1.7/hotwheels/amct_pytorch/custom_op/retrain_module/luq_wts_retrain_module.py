#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

luq weight retrain Module of quantized retrain

"""

from math import inf
import numpy as np
import torch
from torch.nn.parameter import Parameter

from hotwheels.amct_pytorch.custom_op.luq_retrain.wts_luq_retrain import \
    WtsLuqRetrainFunction
import hotwheels.amct_pytorch.custom_op.amct_pytorch_ops as amct_pytorch_ops
from hotwheels.amct_pytorch.custom_op.utils import copy_tensor
from hotwheels.amct_pytorch.custom_op.utils import tensor
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import MIN_ALPHA
from hotwheels.amct_pytorch.custom_op.retrain_module.wts_retrain_module_base \
    import WtsRetrainModuleBase 

SYM_THRESHOLD = 100


class LuqWtsRetrainModule(WtsRetrainModuleBase):
    """
    Function: Base class module for quantized retrain.
    APIs: __init__, _init_output, forward
    """

    def __init__(self, *args, **kwargs):
        super(LuqWtsRetrainModule, self).__init__(*args, **kwargs)
        self.wts_sym = torch.tensor(1, dtype=torch.int32)

    @torch.no_grad()
    def init_wts_clipmax(self, weights):
        if self.wts_config['max_init_algo'] == 'mse':
            abs_max = weights.abs().max()
            cands = torch.linspace(abs_max * 0.5, abs_max * 1.5, 100,
                                device=weights.device)
            min_err = inf
            best_clip_max = abs_max
            for a in cands:
                y, _, _ = amct_pytorch_ops.wts_luq_retrain_forward(
                    weights, a, self.wts_config['num_bits'],
                    self.wts_sym.data)
                err = torch.norm((weights - y))
                if err.item() < min_err:
                    min_err = err
                    best_clip_max = a
        else:
            best_clip_max = weights.abs().max()
        self.wts_clip_max.data.copy_(best_clip_max.data)

    def wts_forward(self):
        """
        Function: weights quantization function.
        """
        weights = self.replaced_module.weight
        if self.transpose:
            weights = weights.transpose(0, 1)
        # Obtains symmetry flags based on threshold statistics
        with torch.no_grad():
            if self.cur_batch < SYM_THRESHOLD:
                self.cur_batch += 1
            if self.cur_batch == 1:
                self.init_wts_clipmax(weights)
            if self.wts_clip_max.min() < MIN_ALPHA:
                LOGGER.logi('wts_clip_max of layer {} is less than {}'.format(
                    self.common_config['layers_name'][0], MIN_ALPHA))
                ind = self.wts_clip_max.data < MIN_ALPHA
                self.wts_clip_max.data[ind] = MIN_ALPHA
        # Call the core method of luq_retrain.
        fakequant_weights, scale, offset = WtsLuqRetrainFunction.apply(
            weights,
            self.wts_clip_max, self.wts_config['num_bits'],
            self.wts_sym.data, self.cur_batch)

        if self.transpose:
            fakequant_weights = fakequant_weights.transpose(0, 1)

        with torch.no_grad():
            copy_tensor(self.wts_scales, scale)
            copy_tensor(self.wts_offsets, offset)

        return fakequant_weights

    def _init_output(self):
        # Register quantitative parameters.
        self.register_buffer('cur_batch', tensor(0))
        self.register_parameter('wts_clip_max',
            Parameter(tensor(1.0, requires_grad=True)))
        self.register_buffer('wts_scales', tensor([np.nan] * 1))
        self.register_buffer('wts_offsets', tensor([0] * 1))
