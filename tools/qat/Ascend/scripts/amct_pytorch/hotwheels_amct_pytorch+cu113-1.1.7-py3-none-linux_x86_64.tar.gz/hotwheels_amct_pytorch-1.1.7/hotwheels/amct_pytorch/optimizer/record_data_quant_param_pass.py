#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

record data quant params by CaliQuantModule

"""
import os
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.optimizer.base_module_fusion_pass \
    import BaseModuleFusionPass

from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import CALI_QUANT_MODULE_TYPES
from hotwheels.amct_pytorch.proto import scale_offset_record_pb2
from google.protobuf import text_format
from hotwheels.amct_pytorch.common.utils import files as files_util
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_FLAG
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_MODE
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    record_activation_scale_offset

from hotwheels.amct_pytorch.common.utils.record_file_operator import ActivationQuantParam


class RecordDataQuantParamPass(BaseModuleFusionPass):
    """
    Function: Insert CaliQuant for quantizable module
    APIs: match_pattern, do_pass
    """

    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseModuleFusionPass.__init__(self)
        self.conf = Configuration()
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.record_file_path = self.conf.get_record_file_path()

    @classmethod
    def match_pattern(cls, module, name, graph=None):
        """
        Function:Match the module to be quantized in model
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure, not necessary
        Return: True: matched
                False: mismatch
        """
        if type(module).__name__ not in CALI_QUANT_MODULE_TYPES:
            return False
        return True

    def set_up(self):
        """
        Function: Open the record file
        Inputs: None
        Returns: None
        """
        with os.fdopen(os.open(self.record_file_path, os.O_RDONLY,
            FILE_ACCESS_MODE), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        self.record_file_path = files_util.create_empty_file(
            self.record_file_path)
        with os.fdopen(os.open(self.record_file_path, FILE_ACCESS_FLAG,
            FILE_ACCESS_MODE), 'w+') as record_write_file:
            record_write_file.write(text_format.MessageToString(
                self.records, as_utf8=True))

    def do_pass(self, model, object_module, object_name, graph=None):
        """
        Function: Record data quant param of cali quant layer
        Parameters: model: torch.nn.Module, the model to be modified.
                    object_module: module to process
                    object_name: name of object_module
                    graph: graph structure, not necessary
        Return: None
        """
        # Step2: construct a new module
        quant_params = object_module.quant_params
        scale = quant_params['scale']
        offset = quant_params['offset']
        num_bit = quant_params['num_bit']
        for record_index, scale_item in enumerate(scale):
            activation_quant_param = ActivationQuantParam(scale=scale_item, offset=offset[record_index],
                                                            index=record_index, num_bits=num_bit[record_index])
            record_activation_scale_offset(
                self.records,
                object_name,
                activation_quant_param)

        LOGGER.logi("Record data quant param of layer '{}' success!".format(
            object_name), 'RecordDataQuantParamPass')
