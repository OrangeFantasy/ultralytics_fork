/*
 * Copyright (c) CompanyNameMagicTag
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0. You may not use
 * this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief luq algorithm custom op C++ implement
 *
 * @file luq_retrain.h
 *
 * @version 1.0
 */
#ifndef LUQ_RETRAIN_H
#define LUQ_RETRAIN_H

#include <torch/extension.h>
#include <vector>
#include <iostream>


std::vector<torch::Tensor> ActsLuqRetrainForward(
    torch::Tensor inputTensor,
    torch::Tensor clipMax,
    int numBits,
    torch::Tensor isSym);

std::vector<torch::Tensor> WtsLuqRetrainForward(
    torch::Tensor inputTensor,
    torch::Tensor clipMax,
    int numBits,
    torch::Tensor isSym);

std::vector<torch::Tensor> LuqRetrainBackward(
    torch::Tensor gradOutputs,
    torch::Tensor inputTensor,
    torch::Tensor clipMax,
    int numBits,
    torch::Tensor isSym);
#endif