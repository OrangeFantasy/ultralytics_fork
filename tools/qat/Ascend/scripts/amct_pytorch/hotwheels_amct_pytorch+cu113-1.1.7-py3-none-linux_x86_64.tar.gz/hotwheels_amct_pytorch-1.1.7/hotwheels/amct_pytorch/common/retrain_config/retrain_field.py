# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

field defination in json config.

"""
from collections import OrderedDict
from hotwheels.amct_pytorch.utils.vars import DATA_BIT_NUM_RANGE
from hotwheels.amct_pytorch.utils.vars import ARQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.utils.vars import SNQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.utils.vars import CLIP_MAX
from hotwheels.amct_pytorch.utils.vars import CLUSTER_FREQ
from hotwheels.amct_pytorch.utils.vars import WEIGHT_NUM_BIT_SET
from hotwheels.amct_pytorch.utils.vars import RETRAIN_DATA_CONFIG
from hotwheels.amct_pytorch.utils.vars import RETRAIN_WEIGHT_CONFIG
from hotwheels.amct_pytorch.utils.vars import DEFAULT_DATA_RETRAIN_ALGO
from hotwheels.amct_pytorch.utils.vars import DEFAULT_WEIGHT_RETRAIN_ALGO
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.custom_op.utils import get_node_input_num
from hotwheels.amct_pytorch.common.config.field import MAX_ITERATION_RANGE
from hotwheels.amct_pytorch.common.config.field import MAX_ITERATION
from hotwheels.amct_pytorch.utils.log import LOGGER
from interval import Interval
from hotwheels.amct_pytorch.common.retrain_config.retrain_proto import DT_INT4
from hotwheels.amct_pytorch.common.retrain_config.retrain_proto import DT_INT8
from hotwheels.amct_pytorch.common.utils.vars import WITH_OFFSET

LNQ_MIN_DISTANCE_RANGE = Interval(1e-2, 1e-8)
LNQ_MIN_DISTANCE = 1e-4
DEFAULT_INIT_ALGO = "mse"
MAX_INIT_ALGO = ["mse", "real_max"]


class ConfigItem():
    """an class for ConfigItem field"""

    def __init__(self, graph_querier, capacity, graph_checker, strong_check=True):
        """inner method"""
        self.graph_querier = graph_querier
        self.graph_checker = graph_checker
        self.capacity = capacity
        self.children = {}
        self.value = None
        self.strong_check = strong_check

    @staticmethod
    def check_type(name, variable, typeinfo, layer=None):
        """inner method"""
        error_msg = "Type of %s should be %s, but is %s" \
                    % (name, typeinfo, type(variable))
        if layer is not None:
            error_msg = "%s for layer %s" % (error_msg, layer)
        if not isinstance(variable, typeinfo):
            raise TypeError(error_msg)

    def set_strong_check(self, check_type):
        """inner method"""
        self.strong_check = check_type

    def add_child(self, key, item, extra=None):
        """inner method"""
        self.children[key] = item

    def dump(self):
        """inner method"""
        if self.children.keys():
            ordered_config = OrderedDict()
            for k, val in self.children.items():
                if k is RETRAIN_DATA_CONFIG:
                    ordered_config[k] = []
                    for item in val:
                        ordered_config[k].append(item.dump())
                else:
                    ordered_config[k] = val.dump()
            return ordered_config
        return self.value

    def build_util(self, key, cls, value, extra=None):
        """inner method"""
        item = cls(self.graph_querier, self.capacity, self.graph_checker, self.strong_check)
        if extra:
            item.build(value, extra)
        else:
            item.build(value)
        self.add_child(key, item)

    def build_default_util(self, key, cls, extra=None):
        """inner method"""
        item = cls(self.graph_querier, self.capacity, self.graph_checker, self.strong_check)
        if extra:
            item.build_default(extra)
        else:
            item.build_default()
        self.add_child(key, item, extra)


class Version(ConfigItem):
    """an object for Version field"""

    def build(self, val):
        """inner method"""
        self.check_type("Version", val, int)
        if val != 1:
            raise ValueError("version should be 1")
        self.value = 1

    def build_default(self):
        """inner method"""
        self.value = 1


class BatchNum(ConfigItem):
    """an object for BatchNum field"""

    def build(self, val):
        """inner method"""
        self.check_type("BatchNum", val, int)
        if val <= 0:
            raise ValueError("batch_num(%d) should be greater than zero."
                             % val)
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = 1


class RetrainEnable(ConfigItem):
    """an object for RetrainEnable field"""

    def build(self, val, extra=None):
        """inner method"""
        self.check_type("RetrainEnable", val, bool, extra[0])
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = True


class ULQAlgo(ConfigItem):
    """an object for ULQAlgo field"""

    def build(self, val, extra=None):
        """inner method"""
        self.check_type('ULQAlgo', val, str)
        if val not in DATA_RETRAIN_ALGO_DICT.keys():
            raise ValueError('ULQAlgo should be in %s for layer %s'
                             % (DATA_RETRAIN_ALGO_DICT.keys(), extra[0]))
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = 'ulq_retrain'


class DataLUQAlgo(ConfigItem):
    """an object for DataLUQAlgo field"""

    def build(self, val, extra=None):
        """inner method"""
        self.check_type('DataLUQAlgo', val, str)
        if val not in DATA_RETRAIN_ALGO_DICT.keys():
            raise ValueError('DataLUQAlgo should be in %s for layer %s'
                             % (DATA_RETRAIN_ALGO_DICT.keys(), extra[0]))
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = 'luq_retrain'


class FixedAlgo(ConfigItem):
    """an object for FixedAlgo field"""

    def build(self, val, extra=None):
        """inner method"""
        self.check_type('FixedAlgo', val, str)
        if val not in DATA_RETRAIN_ALGO_DICT.keys():
            raise ValueError('FixedAlgo should be in %s for layer %s'
                             % (DATA_RETRAIN_ALGO_DICT.keys(), extra[0]))
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = 'fixed_quant_param_retrain'


class ClipMax(ConfigItem):
    """an object for ClipMax field"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('ClipMax', val, float, extra[0])
        if val <= 0:
            raise ValueError('clip max should be larger than 0 for layer %s'
                             % extra[0])
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = CLIP_MAX


class ClipMin(ConfigItem):
    """an object for ClipMin field"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('ClipMin', val, float, extra[0])
        if val >= 0:
            raise ValueError('clip min should be less than 0 for layer %s'
                             % extra[0])
        self.value = val


class FixedMin(ConfigItem):
    """an object for FixedMin field"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('FixedMin', val, bool, extra[0])
        self.value = val


class DataType(ConfigItem):
    """an object for DataType field"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('dst_type', val, str, extra[0])
        if val not in [DT_INT4, DT_INT8]:
            raise ValueError(
                "now only support ['INT4', 'INT8'], but is {}".format(val))
        self.value = val

    def build_default(self, extra=None):  # pylint: disable=W0613
        """inner method"""
        self.value = DT_INT8


class DataBitNum(ConfigItem):
    """an object for data bit num field"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('num_bits', val, int)
        if val != -1 and (val > DATA_BIT_NUM_RANGE[1] \
                or val < DATA_BIT_NUM_RANGE[0]):
            raise ValueError("The num_bits of data must be -1 or between %s and %s."
                             % (DATA_BIT_NUM_RANGE[0], DATA_BIT_NUM_RANGE[1]))
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = DATA_BIT_NUM_RANGE[0]


class DataScale(ConfigItem):
    """an object for data scale field"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('scale_d', val, float)
        self.value = val
    
    def build_default(self):
        """inner method"""
        self.value = 1.0


class WithOffset(ConfigItem):
    """an object for with offset field"""
    def build(self, val, extra):
        """inner method for check and add value"""
        self.check_type(WITH_OFFSET, val, bool)
        self.value = val


class DataOffset(ConfigItem):
    """an object for data offset field"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('offset_d', val, int)
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = 0


class MaxInitAlgo(ConfigItem):
    """an object for max init algo field"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('max_init_algo', val, str)
        if val not in MAX_INIT_ALGO:
            raise ValueError("max_init_algo should be %s or %s."
                             % (MAX_INIT_ALGO[0], MAX_INIT_ALGO[1]))
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = DEFAULT_INIT_ALGO

DATA_RETRAIN_ALGO_DICT = {
    'luq_retrain': DataLUQAlgo,
    'ulq_retrain': ULQAlgo,
    'fixed_quant_param_retrain': FixedAlgo,
}


class RetrainDataConfig(ConfigItem):
    """an object for RetrainDataConfig field"""

    def build_fixed_quant_param_retrain(self, val, extra):
        if 'scale_d' not in val.keys():
            self.build_dafault_util('scale_d', DataScale)
        else:
            self.build_util('scale_d', DataScale, val['scale_d'], extra)
            del val['scale_d']

        if 'offset_d' not in val.keys():
            self.build_dafault_util('offset_d', DataOffset)
        else:
            self.build_util('offset_d', DataOffset, val['offset_d'], extra)
            del val['offset_d']

    def build_luq_retrain(self, val, extra):
        self.build_with_offset(val, extra)
        if 'max_init_algo' not in val.keys():
            self.build_default_util('max_init_algo', MaxInitAlgo)
        else:
            self.build_util(
                'max_init_algo', MaxInitAlgo, val['max_init_algo'], extra)
            del val['max_init_algo']

    def build_ulq_retrain(self, val, extra):
        if 'clip_max' in val.keys() and 'clip_min' in val.keys():
            self.build_util('clip_max', ClipMax, val['clip_max'], extra)
            self.build_util('clip_min', ClipMin, val['clip_min'], extra)
            del val['clip_max']
            del val['clip_min']
        if 'fixed_min' in val.keys():
            self.build_util('fixed_min', FixedMin, val['fixed_min'], extra)
            del val['fixed_min']

    def build_config_by_algo(self, val, extra):
        algo = DEFAULT_DATA_RETRAIN_ALGO
        if 'algo' not in val.keys():
            algo_item = DATA_RETRAIN_ALGO_DICT.get(algo)
            self.build_default_util('algo', algo_item)
        else:
            algo = val['algo']
            algo_item = DATA_RETRAIN_ALGO_DICT.get(algo)
            self.build_util('algo', algo_item, val['algo'], extra)
            del val['algo']
        if algo == 'luq_retrain':
            self.build_luq_retrain(val, extra)

        if algo == 'fixed_quant_param_retrain':
            self.build_fixed_quant_param_retrain(val, extra)

        if algo == 'ulq_retrain':
            self.build_ulq_retrain(val, extra)

    def build_num_bits(self, val, extra):
        if 'num_bits' not in val.keys():
            self.build_default_util('num_bits', DataBitNum)
        else:
            self.build_util('num_bits', DataBitNum, val['num_bits'], extra)
            del val['num_bits']

    def build_with_offset(self, val, extra):
        # check lay_name and ensure key of with_offset included
        if WITH_OFFSET in val.keys():
            self.build_util(WITH_OFFSET, WithOffset, val[WITH_OFFSET], extra)
            del val[WITH_OFFSET]

    def build_common(self, val, extra):
        self.build_num_bits(val, extra)

    def build(self, val, extra):
        """inner method"""
        self.check_type('RetrainDataConfig', val, dict, extra[0])
        self.build_common(val, extra)
        self.build_config_by_algo(val, extra)

        if val.keys():
            raise ValueError('Invalid keys in data config for layer %s'
                             % extra[0])

    def build_default(self, extra=None):
        """inner method"""
        self.build_default_util('algo', DataLUQAlgo)
        self.build_default_util('num_bits', DataBitNum)
        self.build_default_util('max_init_algo', MaxInitAlgo)


class WeightAlgo(ConfigItem):
    """an object for WeightAlgo field"""

    def build(self, val, extra=None):
        """inner method"""
        self.check_type('WeightAlgo', val, str, extra[0])
        if val not in WEIGHT_RETRAIN_ALGO_DICT.keys():
            raise ValueError('WeightAlgo only supports {} for layer {}'.\
                format(WEIGHT_RETRAIN_ALGO_DICT.keys(), extra[0]))
        self.value = val

    def build_default(self, extra=None):  # pylint: disable=W0613
        """inner method"""
        self.value = 'arq_retrain'


class LNQAlgo(ConfigItem):
    """an object for LNQAlgo field"""

    def build(self, val, extra=None):
        self.check_type('WeightAlgo', val, str, extra[0])
        if val not in WEIGHT_RETRAIN_ALGO_DICT.keys():
            raise ValueError('WeightAlgo only supports {} for layer {}'.\
                format(WEIGHT_RETRAIN_ALGO_DICT.keys(), extra[0]))
        self.value = val

    def build_default(self, extra=None):
        """inner method"""
        self.value = 'lnq_retrain'


class WeightLUQAlgo(ConfigItem):
    """an object for WeightLUQAlgo field"""

    def build(self, val, extra=None):
        self.check_type('WeightLUQAlgo', val, str, extra[0])
        if val not in WEIGHT_RETRAIN_ALGO_DICT.keys():
            raise ValueError('WeightLUQAlgo only supports {} for layer {}'.\
                format(WEIGHT_RETRAIN_ALGO_DICT.keys(), extra[0]))
        self.value = val

    def build_default(self, extra=None):
        """inner method"""
        self.value = 'lnq_retrain'


class ChannelWise(ConfigItem):
    """an object for ChannelWise field"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('ChannelWise', val, bool, extra[0])
        if extra[1] in [
            'Linear', 'Gemm', 'MatMul', 'InnerProduct', 'Pooling',
            'AvgPool'
        ] and val is True:
            raise ValueError(' %s layer can not be channelwised' % extra[0])
        self.value = val

    def build_default(self, extra):
        """inner method"""
        if extra[1] in [
            'Linear', 'Gemm', 'MatMul', 'InnerProduct', 'Pooling',
            'AvgPool'
        ]:
            self.value = False
        else:
            self.value = True


class WeightBitNum(ConfigItem):
    """an object for weight bit num"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('num_bits', val, int)
        if val not in WEIGHT_NUM_BIT_SET:
            raise ValueError("The num_bits of weight must be either %d "
                             "or %d." % ARQ_WEIGHT_BIT_NUM, SNQ_WEIGHT_BIT_NUM)
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = ARQ_WEIGHT_BIT_NUM


class ClusterFreq(ConfigItem):
    """an object for weight cluster frequency"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('cluster_freq', val, int)
        if val <= 0:
            raise ValueError("The cluster_freq of weight must be larger than zero")
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = CLUSTER_FREQ


class MaxIteration(ConfigItem):
    """an object for weight cluster max iteration"""

    def build(self, val, extra):
        """inner method"""
        self.check_type('max_iteration', val, int)
        if val not in MAX_ITERATION_RANGE:
            raise ValueError('max_iteration is {}, which must be in '
                             '{}'.format(val, MAX_ITERATION_RANGE))
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = MAX_ITERATION


class MinDistance(ConfigItem):
    """an object for weight cluster min distance"""

    def build(self, val, extra):
        """inner method"""
        if float(val) not in LNQ_MIN_DISTANCE_RANGE:
            raise ValueError("min_distance is {}, which must be in {}".format(
                val, LNQ_MIN_DISTANCE_RANGE))
        self.value = val

    def build_default(self):
        """inner method"""
        self.value = LNQ_MIN_DISTANCE


WEIGHT_RETRAIN_ALGO_DICT = {
    'arq_retrain': WeightAlgo,
    'luq_retrain': WeightLUQAlgo,
    'lnq_retrain': LNQAlgo,
}


class RetrainWeightConfig(ConfigItem):
    """an object for RetrainWeightConfig field"""

    def build_common(self, val, extra):
        if 'num_bits' not in val.keys():
            self.build_default_util('num_bits', WeightBitNum)
        else:
            self.build_util('num_bits', WeightBitNum, val['num_bits'], extra)
            del val['num_bits']
        self.build_config_by_key('channel_wise', ChannelWise, val, extra)

    def buid_luq_retrain(self, val, extra):
        if 'max_init_algo' not in val.keys():
            self.build_default_util('max_init_algo', MaxInitAlgo)
        else:
            self.build_util('max_init_algo', MaxInitAlgo, val['max_init_algo'], extra)
            del val['max_init_algo']

    def build_lnq_retrain(self, val, extra):
        if 'clip_max' not in val.keys():
            self.build_default_util('clip_max', ClipMax)
        else:
            self.build_util('clip_max', ClipMax, val['clip_max'], extra)
            del val['clip_max']

        if 'cluster_freq' not in val.keys():
            self.build_default_util('cluster_freq', ClusterFreq)
        else:
            self.build_util('cluster_freq', ClusterFreq,
                            val['cluster_freq'], extra)
            del val['cluster_freq']

        if 'max_iteration' not in val.keys():
            self.build_default_util('max_iteration', MaxIteration)
        else:
            self.build_util('max_iteration', MaxIteration,
                            val['max_iteration'], extra)
            del val['max_iteration']

        if 'min_distance' not in val.keys():
            self.build_default_util('min_distance', MinDistance)
        else:
            self.build_util('min_distance', MinDistance,
                            val['min_distance'], extra)
            del val['min_distance']

    def build_config_by_algo(self, val, extra):
        wts_algo = DEFAULT_WEIGHT_RETRAIN_ALGO
        key = 'algo'
        if key not in val.keys():
            self.build_default_util(key, WEIGHT_RETRAIN_ALGO_DICT.get(wts_algo))
        else:
            wts_algo = val[key]
            self.build_util(key, WEIGHT_RETRAIN_ALGO_DICT.get(wts_algo), val.get(key), extra)
            del val[key]

        if wts_algo not in WEIGHT_RETRAIN_ALGO_DICT.keys():
            raise ValueError("only support {}, but is {}".format(
                WEIGHT_RETRAIN_ALGO_DICT.keys(), wts_algo))

        if wts_algo == 'luq_retrain':
            self.buid_luq_retrain(val, extra)

        if wts_algo == 'lnq_retrain':
            self.build_lnq_retrain(val, extra)

        if val.keys():
            raise ValueError('Invalid keys in weight config for layer %s'
                             % extra[0])

    def build(self, val, extra):
        """inner method"""
        self.check_type('RetrainWeightConfig', val, dict, extra[0])
        self.build_common(val, extra)
        self.build_config_by_algo(val, extra)

    def build_default(self, extra):
        """inner method"""
        self.build_default_util('algo', WeightAlgo)
        self.build_default_util('channel_wise', ChannelWise, extra)
        self.build_default_util('num_bits', WeightBitNum)

    def build_config_by_key(self, key, cls, val, extra):
        """inner method"""
        if key in val.keys():
            self.build_util(key, cls, val[key], extra)
            del val[key]
        else:
            self.build_default_util(key, cls, extra)


class LayerConfig(ConfigItem):
    """an object for LayerConfig field"""
    fields = {
        'retrain_enable': RetrainEnable,
        RETRAIN_DATA_CONFIG: RetrainDataConfig,
        RETRAIN_WEIGHT_CONFIG: RetrainWeightConfig
    }

    def build(self, val, extra):
        """inner method"""
        self.check_type('LayerConfig', val, dict)
        for key, cls in self.fields.items():
            if self.graph_checker.check_onnx_quantize_type_without_weight(extra[2]) and\
                    key == RETRAIN_WEIGHT_CONFIG:
                continue
            if key not in val.keys():
                if key == RETRAIN_WEIGHT_CONFIG:
                    self.build_default_util(key, cls, extra)
                else:
                    self.build_default_util(key, cls)
            else:
                if key == 'retrain_enable':
                    self.build_util(key, cls, val[key], extra)
                else:
                    self.build_util(key, cls, val[key], extra)
                del val[key]

    def build_default(self, extra):
        """inner method"""
        for key, cls in self.fields.items():
            if self.graph_checker.check_onnx_quantize_type_without_weight(extra[2]) and\
                    key == RETRAIN_WEIGHT_CONFIG:
                continue
            if key == RETRAIN_WEIGHT_CONFIG or key == RETRAIN_DATA_CONFIG:
                self.build_default_util(key, cls, extra)
            else:
                self.build_default_util(key, cls)

    def build_default_util(self, key, cls, extra=None):
        """inner method"""
        if key == RETRAIN_DATA_CONFIG:
            num_of_input = get_node_input_num(extra[2])
            if num_of_input > 0:
                single_item = cls(self.graph_querier, self.capacity, self.graph_checker, self.strong_check)
                single_item.build_default(extra)
                item = [single_item] * num_of_input
        else:
            item = cls(self.graph_querier, self.capacity, self.graph_checker, self.strong_check)
            if extra:
                item.build_default(extra)
            else:
                item.build_default()
        self.add_child(key, item, extra)

    def build_util(self, key, cls, value, extra=None):
        """inner method"""
        if key == RETRAIN_DATA_CONFIG:
            item = []
            for value_item in value:
                single_item = cls(self.graph_querier, self.capacity, self.graph_checker, self.strong_check)
                single_item.build(value_item, extra)
                item.append(single_item)
        else:
            item = cls(self.graph_querier, self.capacity, self.graph_checker, self.strong_check)
            if extra:
                item.build(value, extra)
            else:
                item.build(value)
        self.add_child(key, item)

    def add_child(self, key, item, extra=None):
        """inner method"""
        self.children[key] = item


class RootConfig(ConfigItem):
    """an object for RootConfig field"""

    def build(self, value, extra, graph):
        """inner method"""
        self.check_type('RootConfig', value, dict)
        # handle version
        key = 'version'
        self._build(key, value)

        # handle batch_num
        if self.capacity.is_enable('BATCH_NUM'):
            key = 'batch_num'
            self._build(key, value)
        else:
            if 'batch_num' in value.keys():
                raise ValueError("unsupported batch_num")

        all_disable = True
        for layer, layer_config in value.items():
            if layer not in extra.keys():
                LOGGER.logw('{} is not in graph, it might exist in training '
                    'mode.'.format(layer))
                continue
            if layer_config['retrain_enable'] is True:
                all_disable = False
            self.build_util(layer, LayerConfig, layer_config,
                            (layer, extra[layer],
                             graph.get_node_by_name(layer)))
            del extra[layer]
        disable_config = {}
        for layer, layer_type in extra.items():
            disable_config['retrain_enable'] = False
            self.build_util(layer, LayerConfig, disable_config,
                            (layer, layer_type))

        if all_disable:
            raise ValueError('No layer retrain enabled')

    def build_default(self, extra, graph):
        """inner method"""
        key = 'version'
        self.build_default_util(key, Version)
        if self.capacity.is_enable('BATCH_NUM'):
            key = 'batch_num'
            self.build_default_util(key, BatchNum)
        if not extra:
            raise ValueError('No layer retrain enabled')
        for layer, layer_type in extra.items():
            self.build_default_util(
                layer, LayerConfig,
                (layer, layer_type,
                 graph.get_node_by_name(layer)))

    def get_global_keys(self):
        """Get global config's keys """
        global_keys = ['version']
        if self.capacity.is_enable('BATCH_NUM'):
            global_keys.append('batch_num')
        return global_keys

    def _build(self, key, value):
        class_dict = {"version": Version, "batch_num": BatchNum}
        if key not in value and self.strong_check:
            raise ValueError("must has %s" % {key})
        if key not in value:
            self.build_default_util(key, class_dict.get(key))
        else:
            self.build_util(key, class_dict.get(key), value.get(key))
            del value[key]
