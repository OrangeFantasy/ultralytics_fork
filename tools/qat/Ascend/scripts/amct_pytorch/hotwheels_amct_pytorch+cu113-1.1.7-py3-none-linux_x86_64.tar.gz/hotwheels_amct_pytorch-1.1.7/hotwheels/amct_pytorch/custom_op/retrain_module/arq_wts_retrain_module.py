#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

arq weight retrain module

"""

import numpy as np
import torch
from hotwheels.amct_pytorch.custom_op.arq_retrain.arq_retrain import \
    ArqRetrainFunction
from hotwheels.amct_pytorch.custom_op.utils import copy_tensor
from hotwheels.amct_pytorch.custom_op.utils import tensor
from hotwheels.amct_pytorch.custom_op.retrain_module.wts_retrain_module_base \
    import WtsRetrainModuleBase 


class ArqWtsRetrainModule(WtsRetrainModuleBase):
    """
    Function: Arq weight retrain module.
    APIs: __init__, _init_output, wts_forward, get_weight_scale,
        get_weight_offset
    """

    def __init__(self, *args, **kwargs):
        super(ArqWtsRetrainModule, self).__init__(*args, **kwargs)

    def wts_forward(self):
        """
        Function: weights quantization function.
        """
        node_type = self.common_config.get('node_type')
        wts_param = {
            'num_bits': self.wts_config.get('num_bits'),
            'channel_wise': self.wts_config.get('channel_wise'),
            'with_offset': False,
        }

        weights = self.replaced_module.weight
        if self.transpose:
            weights = weights.transpose(0, 1)
        fakequant_weights, scale, offset = ArqRetrainFunction.apply(
            weights, wts_param, node_type)
        if self.transpose:
            fakequant_weights = fakequant_weights.transpose(0, 1)
        with torch.no_grad():
            copy_tensor(self.wts_scales, scale)
            copy_tensor(self.wts_offsets, offset)

        return fakequant_weights

    def get_weight_scale(self):
        return self.wts_scales

    def get_weight_offset(self):
        return self.wts_offsets

    def _init_output(self):
        # Register quantitative parameters.
        num_scale = self.wts_config['num_scale']
        self.register_buffer('wts_scales', tensor([np.nan] * num_scale))
        self.register_buffer('wts_offsets', tensor([np.nan] * num_scale))
