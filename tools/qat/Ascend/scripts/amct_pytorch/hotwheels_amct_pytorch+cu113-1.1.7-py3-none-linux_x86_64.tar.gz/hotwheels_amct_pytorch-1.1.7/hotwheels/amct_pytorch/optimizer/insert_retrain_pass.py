#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert some mudule about retrain quantization.

"""
import torch # pylint: disable=E0401

from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig as \
    Configuration
from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.custom_op.comp_module.comp_module_conv2d \
    import CompModuleConv2d
from hotwheels.amct_pytorch.custom_op.comp_module.comp_module_linear \
    import CompModuleLinear
from hotwheels.amct_pytorch.custom_op.comp_module.comp_module_convtranspose2d \
    import CompModuleConvTranspose2d
from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import RETRAIN_WEIGHT_CONFIG
from hotwheels.amct_pytorch.utils.vars import RETRAIN_DATA_CONFIG
from hotwheels.amct_pytorch.utils.vars import SKIP_QUANT_INDEX
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.configuration.check import GraphChecker


REPLACE_DICT = {
    'Conv': CompModuleConv2d,
    'Gemm': CompModuleLinear,
    'MatMul': CompModuleLinear,
    'ConvTranspose': CompModuleConvTranspose2d,
}


class InsertRetrainPass(BaseFusionPass):
    """
    Function: Insert some mudule about retrain quantization.
    APIs: match_pattern, do_pass
    """
    def __init__(self, device='cpu'):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.conf = Configuration()
        self.device = device

    @staticmethod
    def modify_act_config(act_config, object_node, object_module, model_helper,
                          object_node_name):
        """
        Function: The following operation will be done if activation retrain
                    algorithm is 'ulq_retrain':
                    a. If 'clip_min' or 'clip_max' is not set, it will be 
                        initialized by IFMR, 'ifmr_init' will be set True
                    b. If current module is located after ReLU or ReLU6, 
                        all data will be larger than 0, there is no need to
                        learn clip_min, 'fixed_min' will be set True
        Parameters: act_config: the activation config to be modified
                    object_node: current node
                    object_module: current module
                    model_helper: model helper to get module according its name
                    object_node_name: current node name
        """
        for index, config in enumerate(act_config):
            pre_node = object_node.get_input_anchor(index).get_peer_output_anchor().node
            if config.get('algo') != 'ulq_retrain':
                continue
            if config.get('clip_min') is None or \
                config.get('clip_max') is None:
                config['ifmr_init'] = True

            if config.get('fixed_min') is None:
                try:
                    pre_module = model_helper.get_module(pre_node.name)
                except RuntimeError:
                    LOGGER.logw("Cannot find pre module named '{}', use '{}'"
                                " instead!".format(pre_node.name,
                                object_node_name), 'InsertRetrainPass')
                    pre_module = object_module
                if isinstance(pre_module, (torch.nn.ReLU6, torch.nn.ReLU)):
                    config['fixed_min'] = True
                else:
                    config['fixed_min'] = False

    def match_pattern(self, node):
        """
        Function: Match the node to be retrain quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if not GraphChecker.check_onnx_quantize_type(node):
            return False
        if not self.conf.quant_enable(node.name):
            return False
        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Insert some mudule about retrain quantization.
        Parameters: graph: graph structure
                    object_node: node to process
                    model: torch.nn.Module, the model to be modified. if it's
                        None, the gaph will be modified.
        Return: None
        """
        # Step1: find module and its parent
        object_node_name = object_node.name
        model_helper = ModuleHelper(model)
        object_module = model_helper.get_module(object_node_name)
        parent_module = model_helper.get_parent_module(object_node_name)
        
        # get disable index in case that layer is after split layer
        skip_quant_index = None
        if object_node.has_attr(SKIP_QUANT_INDEX):
            skip_quant_index = object_node.get_attr(SKIP_QUANT_INDEX)

        # Step2: construct a new module
        # activation quant config
        act_config = self.conf.get_retrain_config(object_node_name).get(RETRAIN_DATA_CONFIG)
        InsertRetrainPass.modify_act_config(act_config, object_node,
                                            object_module, model_helper,
                                            object_node_name)
        # weights quant config
        wts_config = self.conf.get_retrain_config(object_node_name).get(RETRAIN_WEIGHT_CONFIG)
        if wts_config.get('channel_wise') is None:
            wts_config['channel_wise'] = False
        # common quant config
        common_config = {
            'layers_name': [object_node_name],
            'node_type': object_node.type,
            'device': self.device,
            'batch_num': self.conf.get_quant_config().get('batch_num'),
            'skip_quant_index': skip_quant_index,
            'record_layers': [],
            'record_layer_indexes': [],
            'num_of_input': len(act_config),
        }

        if REPLACE_DICT.get(object_node.type):
            act_wts_qat_module = REPLACE_DICT.get(object_node.type)(
                object_module, act_config[0], wts_config, common_config)

            # Step3: replace new model
            setattr(parent_module, object_node_name.split('.')[-1],
                    act_wts_qat_module)

            LOGGER.logd(
                "Insert ActivationQAT and WeightQAT module to "
                "'{}' success!".format(object_node.name), 'InsertRetrainPass')
