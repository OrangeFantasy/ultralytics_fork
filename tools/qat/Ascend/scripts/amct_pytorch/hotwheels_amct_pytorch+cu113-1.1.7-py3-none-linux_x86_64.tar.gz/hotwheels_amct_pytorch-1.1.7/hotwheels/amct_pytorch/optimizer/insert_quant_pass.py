#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert AscendQuant in the graph

"""
from onnx import onnx_pb  # pylint: disable=import-error
from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import MULTI_INPUT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import OFFLINE_OPTIMIZE_LAYER_TYPES
from hotwheels.amct_pytorch.custom_op.utils import get_offline_optimize_index


class InsertQuantPass(BaseFusionPass):
    """
    Function: Insert AscendQuant
    APIs: match_pattern, do_pass
    """

    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
            num_bits: int number indicating the bit to be quanted such 8
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.name not in self.records:
            return False
        if node.type == 'Concat':
            return False
        return True

    def get_layer_quant_params(self, object_name, node_index):
        scale = self.records.get(object_name).get('data_scale')[node_index]
        offset = self.records.get(object_name).get('data_offset')[node_index]
        quant_bit = self.records.get(object_name).get('data_num_bits')[node_index]
        return scale, offset, quant_bit

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actually inserting AscendQuant.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        object_name = object_node.name
        length = len(object_node.input_anchors) if object_node.type in MULTI_INPUT_ONNX_TYPES else 1

        for index in range(length):
            # Step1: add a new_node
            input_anchor = object_node.get_input_anchor(index)
            node_index = input_anchor.index
            record_index = node_index
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            if peer_output_anchor is None:
                continue
            if peer_output_anchor.node.type in \
                    OFFLINE_OPTIMIZE_LAYER_TYPES:
                continue
            if object_node.type in RNN_ONNX_TYPES:
                if node_index > 0:
                    offline_optimize_index = get_offline_optimize_index(object_node)
                    record_index = node_index - offline_optimize_index
                    if record_index < 0 or record_index > 1:
                        continue
            scale, offset, quant_bit = self.get_layer_quant_params(
                object_name, record_index)
            if quant_bit == -1:
                continue
            node_proto = construct_quant_node(
                inputs=['.'.join([object_name, 'quant',
                                  'input{}'.format(node_index)])],
                outputs=['.'.join([object_name, 'quant', 'output{}'
                                  .format(node_index)])],
                attrs={
                    'scale': scale,
                    'offset': offset,
                    'quant_bit': quant_bit
                },
                layer_name=object_name,
                index=node_index)
            quant_node = graph.add_node(node_proto)
            quant_node.set_attr('object_node', object_name)

            # Step2: Relink nodes in th graph
            # remove output links
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            peer_node = peer_output_anchor.node
            if object_node.type == 'AveragePool' and peer_node.type == 'Pad':
                output_anchor = peer_node.get_output_anchor(0)
                if len(output_anchor.get_peer_input_anchor()) == 1:
                    # If AveragePool with pad, add quant before it
                    if peer_node.name == '%s_pad' % (object_node.name):
                        object_node = peer_node
                        peer_output_anchor = \
                            object_node.get_input_anchor(0).get_peer_output_anchor()
                        peer_node = peer_output_anchor.node
            peer_output_anchor_index = peer_output_anchor.index
            graph.remove_edge(peer_node, peer_output_anchor_index,
                              object_node, node_index)
            # add links
            graph.add_edge(peer_node, peer_output_anchor_index, quant_node, 0)
            graph.add_edge(quant_node, 0, object_node, node_index)

            LOGGER.logd("Insert quant layer '{}' before '{}' "
                        "success!".format(quant_node.name, object_name),
                        'InsertQuantPass')


def construct_quant_node(inputs,  # pylint: disable=no-member
                         outputs,
                         attrs,
                         layer_name,
                         index):
    """
    Function: construct quant node in onnx
    Inputs:
        input: a list of inputs' name
        output: a list of outputs' name
        attrs: a dict of attrs including
            scale: numpy.array
            offset: numpy.array
            quant_bit: a number
        quantize_layer: a string, layer to be quantized
    """
    node_proto = onnx_pb.NodeProto()

    node_proto.name = '.'.join([layer_name, 'quant{}'.format(index)])
    node_proto.op_type = 'AscendQuant'
    node_proto.input.extend(inputs)  # pylint: disable=E1101
    node_proto.output.extend(outputs)  # pylint: disable=E1101

    attr_helper = AttributeProtoHelper(node_proto)
    attr_helper.set_attr_value('scale', 'FLOAT', attrs['scale'])
    attr_helper.set_attr_value('offset', 'FLOAT', attrs['offset'])
    attr_helper.set_attr_value('quant_bit', 'INT', attrs['quant_bit'])

    return node_proto
