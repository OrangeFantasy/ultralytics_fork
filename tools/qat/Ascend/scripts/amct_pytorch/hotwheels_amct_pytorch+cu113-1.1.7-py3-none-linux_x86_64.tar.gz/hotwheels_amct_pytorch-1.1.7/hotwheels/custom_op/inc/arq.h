/*
 * Copyright (c) CompanyNameMagicTag
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief arq_quant algorithm custom op C++ implement
 *
 * @file arq.h
 *
 * @version 1.0
 */

#ifndef ARQ_H
#define ARQ_H

#include <torch/extension.h>

#include "util.h"

const int NUM_BITS = 8;

namespace arq{
void ArqClipAndQuant(
    torch::Tensor &data,
    torch::Tensor &scale,
    torch::Tensor &offset,
    const int numBits,
    bool isReal);

Status CheckCaliParams(torch::Tensor &data, const int numBits);

std::vector<torch::Tensor> FindMinAndMax(
    torch::Tensor quantData);
}

Status CheckQuantParams(
    torch::Tensor &quantData,
    torch::Tensor &scale,
    torch::Tensor &offset,
    int numBits);

std::vector<torch::Tensor> ArqCali(
    torch::Tensor input,
    int numBits,
    bool channelWise,
    bool withOffset);

std::vector<torch::Tensor> ArqReal(
    torch::Tensor input,
    torch::Tensor scale,
    torch::Tensor offset,
    int numBits);

#endif /* ARQ_H */
