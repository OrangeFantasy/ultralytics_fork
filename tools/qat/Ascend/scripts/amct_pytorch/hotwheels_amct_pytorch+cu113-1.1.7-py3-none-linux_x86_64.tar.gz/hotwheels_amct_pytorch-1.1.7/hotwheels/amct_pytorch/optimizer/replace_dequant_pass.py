#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace AscendDequant to fakeqaunt 'Dequant' with onnx's ops.

"""
import numpy as np

from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.module.dequant_module import add_fake_dequant

from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.onnx_initializer_util import \
    TensorProtoHelper
from hotwheels.amct_pytorch.utils.attrs_list import \
    ATTR_NODE_EQUIVALENT_OBJECT_LAYER
from hotwheels.amct_pytorch.utils.attrs_list import ATTR_NODE_EQUIVALENT_OUTPUT


class ReplaceDequantPass(BaseFusionPass):
    """
    Function: Replace AscendDequant to fakeqaunt 'Dequant' with onnx's ops
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    @staticmethod
    def _delete_ascend_dequant_node(graph, object_node):
        """delete dequant node and it's param node"""
        param_in_anchor = object_node.get_input_anchor(1)
        peer_output_anchor = param_in_anchor.get_peer_output_anchor()
        param_node = peer_output_anchor.node
        graph.remove_edge(param_node, peer_output_anchor.index, object_node, 1)
        if not peer_output_anchor.get_peer_input_anchor():
            graph.remove_node(param_node)
        graph.remove_node(object_node)

    def match_pattern(self, node):
        """
        Function: Match the AscendQuant node
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'AscendDequant':
            return False

        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actually replacing AscendDequant to fakeqaunt 'Dequant'
            with onnx's ops
        Parameters: graph: graph structure
                    object_node: node to process
                    model: torch.nn.Module, the model to be modified. if it's
                        None, the gaph will be modified.
        Return: None
        """
        input_anchor = object_node.get_input_anchor(0)
        # Step1: add a new_node
        quantized_node = input_anchor.get_peer_output_anchor().node
        mul_node = _get_dequant_param(graph, quantized_node, object_node)

        # record inserted dequant node info
        ori_object_name = object_node.get_attr('object_node')
        mul_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, ori_object_name)
        ori_object_node = graph.get_node_by_name(ori_object_name)
        ori_object_node.set_attr(ATTR_NODE_EQUIVALENT_OUTPUT, mul_node.name)

        # Step2: Relink nodes in th graph
        # remove input links
        peer_output_anchor = input_anchor.get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        peer_output_anchor_index = peer_output_anchor.index
        graph.remove_edge(peer_node, peer_output_anchor_index, object_node, 0)
        graph.add_edge(peer_node, peer_output_anchor_index, mul_node, 0)
        # Step2: relink fake dequant output to original dequant outputs
        output_anchor = object_node.get_output_anchor(0)
        peer_input_anchors = output_anchor.get_peer_input_anchor().copy()
        for input_anchor in peer_input_anchors:
            peer_input_node = input_anchor.node
            input_index = input_anchor.index
            graph.remove_edge(object_node, 0, peer_input_node, input_index)
            graph.add_edge(mul_node, 0, peer_input_node, input_index)
            # If peer_input_node is graph.output, rename object_node name
            # and set dequant output name to graph.output.name
            if peer_input_node.type == 'graph_anchor':
                mul_node.get_output_anchor(0).set_name(peer_input_node.name)
        # delete deploy dequant nodes
        self._delete_ascend_dequant_node(graph, object_node)

        LOGGER.logd(
            "Replace dequant layer '{}' to fake dequant layer '{}' success!".
            format(object_node.name, \
            '.'.join(object_node.name.split('.')[0:-1]) + '.fakedequant'),
            'ReplaceDequantPass')


def _get_dequant_param(graph, quantized_node, node):
    ''' get essential params for deqaunt'''
    quantized_layer_name = node.name
    weight_anchor = node.get_input_anchor(1)
    dequant_param = weight_anchor.get_peer_output_anchor().node
    fused_quant_param = TensorProtoHelper(dequant_param.proto).get_data()
    _, _, deq_scale_value = _split_dequant_param(fused_quant_param)

    dequant_shape = QuantOpInfo.get_dequant_shape(quantized_node)
    deq_scale_value = np.reshape(deq_scale_value, dequant_shape)

    return add_fake_dequant(graph, quantized_layer_name, deq_scale_value, node)


def _split_dequant_param(fused_quant_param):
    '''split dequant_param to offset_w, n, deq_scale '''
    mask = int('0x0000ff0000000000', 16)
    offset_weight = np.array((np.bitwise_and(fused_quant_param, mask)) >> 40,
                             np.int8)
    mask = int('0x000000ff00000000', 16)
    shift_n_value = np.array(
        np.bitwise_and(fused_quant_param, mask) >> 32, np.int8)
    mask = int('0x00000000ffffffff', 16)
    deq_scale_value = np.array(np.bitwise_and(fused_quant_param, mask),
                               np.uint32)
    deq_scale_value = np.frombuffer(deq_scale_value, np.float32)

    return offset_weight, shift_n_value, deq_scale_value
