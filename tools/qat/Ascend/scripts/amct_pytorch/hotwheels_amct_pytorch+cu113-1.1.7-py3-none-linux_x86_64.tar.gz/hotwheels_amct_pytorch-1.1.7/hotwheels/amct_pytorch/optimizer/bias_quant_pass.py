#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quant bias from floa32 to int32.

"""
import math
import numpy as np
from onnx import onnx_pb

from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.vars import QUANT_BIAS_BITS
from hotwheels.amct_pytorch.utils.vars import BASE
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from hotwheels.amct_pytorch.utils.vars import RETRAIN_WEIGHT_CONFIG
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.custom_op.lnq_retrain.lnq_retrain import lnq_cali_fake_quant
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.optimizer.weight_calibration import WeightsCalibrationPass


class BiasQuantPass(BaseFusionPass):
    """
    Function: Quant bias from floa32 to int32.
    APIs: match_pattern, do_pass
    """

    def __init__(self, records, is_retrain):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        if is_retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()
        self.records = records
        self.is_retrain = is_retrain

    @staticmethod
    def quant_bias(bias, offset_d, layer_name, sum_weight, deq_scale):
        '''Function: kernel function, quant bias with scale and offset
        Parameters:
            bias: float number, to be quantized
            scale: float number, quant factor
            offset: int number, quant factor
        Returns:
            quant_bias, type int32, quantized bias
        '''
        left_bound = -pow(1.0 * BASE, QUANT_BIAS_BITS - 1)
        right_bound = pow(1.0 * BASE, QUANT_BIAS_BITS - 1) - 1
        if math.isclose(deq_scale, 0):
            raise RuntimeError("deq_scale from layer {} should not be 0!".\
                format(layer_name))
        quant_bias = np.round(np.true_divide(bias, deq_scale) -
                              offset_d * sum_weight)
        # check the quant_bias in range of int32
        if quant_bias < left_bound or quant_bias > right_bound:
            invalid_value = quant_bias
            quant_bias = np.clip(quant_bias, left_bound, right_bound)
            LOGGER.logi(
                'Divide float bias {} by deqscale {} at layer {}'.format(
                    bias, deq_scale, layer_name))
            LOGGER.logi('Quantized bias {} of layer "{}" exceed int32 '
                        'range:[{}, {}], it has been clipped to {}'.format(
                invalid_value, layer_name,
                left_bound, right_bound, quant_bias))

        quant_bias = np.int32(quant_bias)
        return quant_bias

    @staticmethod
    def get_deq_scale(scale_d, scale_w):
        scale_w = np.divide(1.0, scale_w, dtype=np.float32)
        scale_d = np.divide(1.0, scale_d, dtype=np.float32)
        return np.multiply(scale_w, scale_d, dtype=np.float32)

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type in RNN_ONNX_TYPES:
            return False
        if node.type in NO_WEIGHT_QUANT_ONNX_TYPES:
            return False

        if node.name not in self.records:
            return False

        _, _, bias_index = QuantOpInfo.get_quant_index(node)

        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual quantization and node's bias is changed to int32.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        _, weight_index, bias_index = QuantOpInfo.get_quant_index(object_node)
        weight_input_anchor = object_node.get_input_anchor(weight_index)
        weight_param = weight_input_anchor.get_peer_output_anchor().node
        weight_helper = TensorProtoHelper(weight_param.proto)
        weight = weight_helper.get_data()

        attr_helper = AttributeProtoHelper(object_node.proto)
        group = 1
        if attr_helper.has_attr('group'):
            group = attr_helper.get_attr_value('group')

        if bias_index is None or len(object_node.input_anchors) == bias_index:
            bias_tensor = onnx_pb.TensorProto()
            bias_tensor.name = '%s.bias' % (object_node.name)
            bias_helper = TensorProtoHelper(bias_tensor)
            if object_node.type == 'ConvTranspose':
                empty_bias = [0] * (weight.shape[1] * group)
                bias_helper.set_data(empty_bias, type_string='FLOAT',
                                     dims=[weight.shape[1] * group])
            else:
                empty_bias = [0] * weight.shape[0]
                bias_helper.set_data(empty_bias, type_string='FLOAT',
                                     dims=[weight.shape[0]])
            if object_node.type == 'MatMul':
                bias_index = 2
            bias_node = graph.add_node(bias_tensor)
            object_node.add_input_anchor('%s.bias' % object_node.name)
            graph.add_edge(bias_node, 0, object_node, 2)

        bias_input_anchor = object_node.get_input_anchor(bias_index)
        bias_param = bias_input_anchor.get_peer_output_anchor().node
        bias_helper = TensorProtoHelper(bias_param.proto)
        bias = bias_helper.get_data()
        bias_helper.clear_data()

        scale_d = self.records.get(object_node.name).get('data_scale')[0]
        scale_w = self.records.get(object_node.name).get('weight_scale')

        scale_w = self.update_scale_w_with_bias(scale_w, len(bias))

        deq_scale_container = self.get_deq_scale_container(scale_d, scale_w, len(bias))

        int32_bias = self.quantize_bias_with_optimize(object_node,
                                                      weight,
                                                      bias,
                                                      deq_scale_container)

        bias_helper.set_data(int32_bias, 'INT32')

        LOGGER.logd("Quant bias from float32 to int32 for layer '{}' "
                    "success!".format(object_node.name), 'BiasQuantPass')

    def update_scale_w_with_bias(self, scale_w, bias_data_length):
        if scale_w.size == 1:
            scale_w = [scale_w] * bias_data_length
        return scale_w

    def get_deq_scale_container(self, scale_d, scale_w, bias_data_length):
        deq_scale_container = [0 for k in range(bias_data_length)]
        for i in range(bias_data_length):
            deq_scale_container[i] = self.get_deq_scale(scale_d, scale_w[i])
        return deq_scale_container

    def quantize_bias_with_optimize(self, object_node, quantized_weight,
                                    bias_data, deq_scale_container):
        offset_d = self.records.get(object_node.name).get('data_offset')[0]
        if object_node.type == 'ConvTranspose':
            quantized_weight = WeightsCalibrationPass. \
                adjust_deconv_weight_np_shape(object_node, quantized_weight)

        ''' get layer config of current node '''
        layer_config = self.conf.get_layer_config(object_node.name)

        ''' get wts_algo by 'retrain' of 'calibration' status '''
        if self.is_retrain:
            wts_param = layer_config.get(RETRAIN_WEIGHT_CONFIG)
            wts_algo = wts_param['algo']
        else:
            wts_param = layer_config.get(WEIGHT_QUANT_PARAMS)
            wts_algo = wts_param['wts_algo']

        ''' trans weight from int4 to int8 '''
        if wts_algo in ('lnq_retrain', 'snq_quantize'):
            quantized_weight = lnq_cali_fake_quant(quantized_weight,
                                                   self.records.get(object_node.name).get('params'))
            quantized_weight = quantized_weight.cpu().numpy()

        quantized_bias = [0] * len(bias_data)
        for index in range(len(bias_data)):
            quantized_bias[index] = \
                BiasQuantPass.quant_bias(
                    bias_data[index],
                    offset_d,
                    object_node.name,
                    quantized_weight[index].sum(),
                    deq_scale_container[index])
        return quantized_bias
