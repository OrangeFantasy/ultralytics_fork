#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Get config dict for quantization from .cfg file.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import copy
from collections import OrderedDict

from google.protobuf import text_format  # pylint: disable=E0401

from hotwheels.amct_pytorch.utils.vars import ACTIVATION_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.parser.om_config_parser import OmConfigParser
from hotwheels.amct_pytorch.common.utils.util import find_repeated_items
from hotwheels.amct_pytorch.common.utils.util import check_no_repeated
from hotwheels.amct_pytorch.common.utils.util import proto_float_to_python_float
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_ONNX_TYPES
from hotwheels.amct_pytorch.utils.log import LOGGER  # pylint: disable=relative-beyond-top-level

_MODULE_NAME = 'Proto_config'


class ProtoConfig():  # pylint: disable=too-many-instance-attributes, too-few-public-methods
    """
    Function: Cope with simple config file from proto.
    APIs:
    """

    def __init__(self, config_file,  # pylint: disable=R0913
                 capacity, graph_querier, graph, proto_config):
        self.config_file = config_file
        self.proto_config = proto_config
        with open(self.config_file, 'rb') as cfg_file:
            pbtxt_string = cfg_file.read()
            text_format.Merge(pbtxt_string, self.proto_config)
        self.capacity = capacity
        self.channel_wise_types = self.capacity.get_value('CHANNEL_WISE_ONNX_TYPES')
        self.quantizable_type = QUANTIZABLE_ONNX_TYPES
        self.no_weight_quantizable_type = NO_WEIGHT_QUANT_ONNX_TYPES
        self.graph_querier = graph_querier
        self.graph = graph
        self.layer_type = graph_querier.get_name_type_dict(graph)

    @staticmethod
    def _channel_wise_is_true(config):
        if config.get(WEIGHT_QUANT_PARAMS) is None:
            return False

        weight_params = config[WEIGHT_QUANT_PARAMS]
        if weight_params.get('wts_algo') in ('arq_quantize', 'snq_quantize',
                                             None) and weight_params.get('channel_wise', False):
            return True
        return False

    @staticmethod
    def _gen_nuq_config(steps, iterations):
        config = OrderedDict()
        weight_params = OrderedDict()
        config[WEIGHT_QUANT_PARAMS] = weight_params
        weight_params['wts_algo'] = 'nuq_quantize'
        weight_params['num_steps'] = steps
        weight_params['num_of_iteration'] = iterations
        return config

    def get_proto_config(self):
        """parse proto config"""
        global_config = self._get_global_config()

        # the priority of layer config and type config is
        # higher than nuq config
        layer_config = self._get_override_layer_configs()
        type_config = self._get_override_layer_types()
        common_config = self._get_common_config()
        om_config = self._get_om_config()

        if not common_config and not type_config:
            if hasattr(self.proto_config, 'conv_calibration_config'):
                common_config = self._get_conv_calibration_config()
            if hasattr(self.proto_config, 'fc_calibration_config'):
                fc_config = self._get_fc_calibration_config()
                for item in (set(self.quantizable_type) -
                             set(self.channel_wise_types)):
                    type_config[item] = copy.deepcopy(fc_config)
        else:
            if hasattr(self.proto_config, 'conv_calibration_config'):
                self._raise_ignore_info('conv_calibration_config')
            if hasattr(self.proto_config, 'fc_calibration_config'):
                self._raise_ignore_info('fc_calibration_config')

        LOGGER.logd('global_config is {}'.format(global_config))
        LOGGER.logd('common_config is {}'.format(common_config))
        LOGGER.logd('type_config is {}'.format(type_config))
        LOGGER.logd('layer_config is {}'.format(layer_config))
        config_collection = (global_config, common_config, type_config, layer_config, om_config)
        return config_collection

    def _get_weight_offset(self):
        if self.proto_config.HasField('weight_offset'):
            return self.proto_config.weight_offset
        return None

    def _get_skip_layers(self):
        skip_layers = list(self.proto_config.skip_layers)
        repeated_layers = find_repeated_items(skip_layers)
        check_no_repeated(repeated_layers, 'skip_layers')
        return skip_layers

    def _get_mapped_type(self, layer_type, map_types):
        if layer_type not in map_types:
            raise ValueError(
                'Unrecognized layer type:{}, only support {}'.format(
                    layer_type, map_types))
        return self.quantizable_type[map_types.index(layer_type)]

    def _transform_layer_types(self, layer_types):
        map_types = self.capacity.get_value('QUANTIZABLE_MAP_TYPES')
        if map_types is None:
            return layer_types

        if not isinstance(layer_types, list):
            return self._get_mapped_type(layer_types, map_types)

        ret = []
        for item in layer_types:
            ret.append(self._get_mapped_type(item, map_types))
        return ret

    def _get_skip_layer_types(self):
        skip_layer_types = list(self.proto_config.skip_layer_types)
        repeated_items = find_repeated_items(skip_layer_types)
        check_no_repeated(repeated_items, 'skip_layer_types')
        return self._transform_layer_types(skip_layer_types)

    def _get_do_fusion(self):
        if hasattr(self.proto_config, 'do_fusion'):
            return self.proto_config.do_fusion
        return True

    def _get_skip_fusion_layers(self):
        if not hasattr(self.proto_config, 'skip_fusion_layers'):
            return []
        skip_fusion_layers = list(self.proto_config.skip_fusion_layers)
        repeated_layers = find_repeated_items(skip_fusion_layers)
        check_no_repeated(repeated_layers, 'skip_fusion_layers')
        return skip_fusion_layers

    def _get_update_bn(self):
        if hasattr(self.proto_config, 'update_bn'):
            return self.proto_config.update_bn
        return False

    def _get_bn_momentum(self):
        if self.proto_config.HasField('bn_update_config') and \
                self.proto_config.bn_update_config.HasField('bn_momentum'):
            return self.proto_config.bn_update_config.bn_momentum
        return None

    def _get_bn_update_iterations(self):
        if self.proto_config.HasField('bn_update_config') and \
                self.proto_config.bn_update_config. \
                        HasField('bn_update_iterations'):
            return self.proto_config.bn_update_config.bn_update_iterations
        return None

    def _parser_calibration_config(self, config):
        layer_config = OrderedDict()
        act_params = OrderedDict()
        ifmr_quantize = config.ifmr_quantize

        act_params['num_bits'] = ifmr_quantize.num_bits
        act_params['max_percentile'] = \
            proto_float_to_python_float(ifmr_quantize.max_percentile)
        act_params['min_percentile'] = \
            proto_float_to_python_float(ifmr_quantize.min_percentile)
        act_params['search_range'] = \
            [proto_float_to_python_float(ifmr_quantize.search_range_start),
             proto_float_to_python_float(ifmr_quantize.search_range_end)]
        act_params['search_step'] = proto_float_to_python_float(
            ifmr_quantize.search_step)

        weight_params = OrderedDict()
        if config.HasField('arq_quantize'):
            if self.capacity.is_enable('SNQ'):
                weight_params['wts_algo'] = 'arq_quantize'
            arq_quantize = config.arq_quantize
            if arq_quantize.HasField('channel_wise'):
                weight_params['channel_wise'] = arq_quantize.channel_wise
            if arq_quantize.HasField('num_bits'):
                weight_params['num_bits'] = arq_quantize.num_bits
        elif self.capacity.is_enable('SNQ') and config.HasField(
                'snq_quantize'):
            weight_params['wts_algo'] = 'snq_quantize'
            snq_quantize = config.snq_quantize
            weight_params['max_iteration'] = snq_quantize.max_iteration
            weight_params['min_distance'] = snq_quantize.min_distance
            weight_params['init_algo'] = snq_quantize.init_algo
            weight_params['channel_wise'] = snq_quantize.channel_wise
            weight_params['num_bits'] = snq_quantize.num_bits
        layer_config[ACTIVATION_QUANT_PARAMS] = [act_params]
        layer_config[WEIGHT_QUANT_PARAMS] = weight_params
        return layer_config

    def _get_common_config(self):
        if self.proto_config.HasField('common_config'):
            common_config = self.proto_config.common_config
            return self._parser_calibration_config(common_config)
        return OrderedDict()
    
    def _get_om_config(self):
        if self.proto_config.HasField('om_config'):
            om_config = self.proto_config.om_config
            om_config_file = om_config.mapping_file
            return OmConfigParser.parse_activation_quant_config(om_config_file)
        return OrderedDict()

    def _get_override_layer_types(self):
        types = [
            item.layer_type
            for item in self.proto_config.override_layer_types
        ]
        repeated_items = find_repeated_items(types)
        check_no_repeated(repeated_items, 'override_layer_types')

        override_types = OrderedDict()
        for item in self.proto_config.override_layer_types:
            layer_type = item.layer_type
            layer_type = self._transform_layer_types(layer_type)
            if layer_type not in (self.quantizable_type +
                                  self.no_weight_quantizable_type):
                raise ValueError("Layer type {} does not support "
                                 "quantize.".format(layer_type))

            override_types[layer_type] = self._parser_calibration_config(
                item.calibration_config)
            if layer_type not in self.channel_wise_types and \
                    self._channel_wise_is_true(override_types[layer_type]):
                raise ValueError('channel_wise can only be False '
                                 'for {} type'.format(layer_type))
        return override_types

    def _get_override_layer_configs(self):
        names = [
            item.layer_name
            for item in self.proto_config.override_layer_configs
        ]
        repeated_items = find_repeated_items(names)
        check_no_repeated(repeated_items, 'override_layer_configs')
        override_layers = OrderedDict()
        for item in self.proto_config.override_layer_configs:
            layer_name = item.layer_name
            if layer_name not in self.layer_type:
                raise ValueError('Layer {} does not exist in '
                                 'the graph.'.format(layer_name))

            override_layers[layer_name] = self._parser_calibration_config(
                item.calibration_config)
            if self.layer_type[layer_name] not in self.channel_wise_types and \
                    self._channel_wise_is_true(override_layers[layer_name]):
                raise ValueError('channel_wise can only be False '
                                 'for {} layer.'.format(layer_name))
        return override_layers

    def _parse_deprecated_config(self, name, config):
        LOGGER.logi('{} field has been deprecated, use common_config and '
                    'override_layer_types instead.'.format(name))
        return self._parser_calibration_config(config)

    def _get_conv_calibration_config(self):
        name = 'conv_calibration_config'
        if not self.proto_config.HasField(name):
            return OrderedDict()
        config = self.proto_config.conv_calibration_config
        return self._parse_deprecated_config(name, config)

    def _get_fc_calibration_config(self):
        name = 'fc_calibration_config'
        if not self.proto_config.HasField(name):
            return OrderedDict()
        config = self.proto_config.fc_calibration_config
        fc_config = self._parse_deprecated_config(name, config)
        if self._channel_wise_is_true(fc_config):
            raise ValueError('channel_wise can only be False '
                             'for fc_calibration_config field')
        return fc_config

    def _raise_ignore_info(self, name):
        if self.proto_config.HasField(name):
            LOGGER.logw('{} field would be ignored when common_config '
                        'or override_layer_types exists'.format(name))

    def _get_global_config(self):
        """parse global config"""
        global_config = OrderedDict()
        if hasattr(self.proto_config, 'batch_num'):
            global_config['batch_num'] = self.proto_config.batch_num
        if hasattr(self.proto_config, 'activation_offset'):
            global_config['activation_offset'] = self.proto_config.activation_offset
        if hasattr(self.proto_config, 'weight_offset'):
            global_config['weight_offset'] = self._get_weight_offset()
        global_config['skip_layers'] = self._get_skip_layers()
        global_config['skip_layer_types'] = self._get_skip_layer_types()
        global_config['do_fusion'] = self._get_do_fusion()
        global_config['skip_fusion_layers'] = self._get_skip_fusion_layers()
        global_config['update_bn'] = self._get_update_bn()

        if self._get_update_bn():
            global_config['bn_update_config'] = {}
            if hasattr(self.proto_config, 'bn_update_config'):
                global_config['bn_update_config']['bn_momentum'] = \
                    self._get_bn_momentum()
                global_config['bn_update_config']['bn_update_iterations'] = \
                    self._get_bn_update_iterations()

        return global_config
