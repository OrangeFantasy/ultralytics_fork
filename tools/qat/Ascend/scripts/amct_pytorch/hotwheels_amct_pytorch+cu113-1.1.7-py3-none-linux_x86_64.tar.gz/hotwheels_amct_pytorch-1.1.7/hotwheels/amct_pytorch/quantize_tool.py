#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Top APIs of AMCT_TORCH tool for user

"""

import os
from io import BytesIO
from collections import namedtuple
import torch  # pylint: disable=E0401
from torch.nn.parallel import DataParallel, DistributedDataParallel
import torch.distributed as dist

from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.common.utils.check_params import check_params
from hotwheels.amct_pytorch.common.utils import files as files_util

from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from hotwheels.amct_pytorch.optimizer.weight_calibration import WeightsCalibrationPass
from hotwheels.amct_pytorch.optimizer.insert_cali_quant import InsertCaliQuantPass
from hotwheels.amct_pytorch.optimizer.rnn_weight_calibration import RNNWeightsCalibrationPass

from hotwheels.amct_pytorch.optimizer.insert_quant_pass import InsertQuantPass
from hotwheels.amct_pytorch.optimizer.insert_dequant_pass import InsertDequantPass
from hotwheels.amct_pytorch.optimizer.quant_fusion_pass import QuantFusionPass
from hotwheels.amct_pytorch.optimizer.weight_quant_pass import WeightQuantPass
from hotwheels.amct_pytorch.optimizer.bias_quant_pass import BiasQuantPass
from hotwheels.amct_pytorch.optimizer.rnn_bias_quant_pass import RNNBiasQuantPass
from hotwheels.amct_pytorch.optimizer.replace_quant_pass import ReplaceQuantPass
from hotwheels.amct_pytorch.optimizer.replace_dequant_pass import ReplaceDequantPass
from hotwheels.amct_pytorch.optimizer.replace_anti_quant_pass import ReplaceAntiQuantPass
from hotwheels.amct_pytorch.optimizer.weight_fakequant_pass import WeightFakequantPass
from hotwheels.amct_pytorch.optimizer.bias_fakequant_pass import BiasFakequantPass
from hotwheels.amct_pytorch.optimizer.rnn_bias_fakequant_pass import RNNBiasFakequantPass
from hotwheels.amct_pytorch.optimizer.rnn_weight_fakequant_pass import RNNWeightFakeQuantPass
from hotwheels.amct_pytorch.optimizer.graph_optimizer import GraphOptimizer
from hotwheels.amct_pytorch.optimizer.model_optimizer import ModelOptimizer
from hotwheels.amct_pytorch.optimizer.gen_quant_param_record_pass import \
    GenQuantParamRecordPass
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from hotwheels.amct_pytorch.optimizer.insert_retrain_pass import \
    InsertRetrainPass
from hotwheels.amct_pytorch.optimizer.share_act_comp_pass import \
    ShareActCompPass
from hotwheels.amct_pytorch.optimizer.insert_anti_quant_pass import InsertAntiQuantPass
from hotwheels.amct_pytorch.optimizer.delete_retrain_pass import \
    DeleteRetrainPass
from hotwheels.amct_pytorch.optimizer.replace_sync_bn_pass import \
    RepalceSyncBNPass
from hotwheels.amct_pytorch.optimizer.gen_fusion_json import GenFusionJsonPass
from hotwheels.amct_pytorch.optimizer.insert_depthwiseconv_pass import \
    InsertDepthwiseConvPass
from hotwheels.amct_pytorch.optimizer.rnn_weight_quant_pass import \
    RNNWeightQuantPass

from hotwheels.amct_pytorch.parser.parser import Parser
from hotwheels.amct_pytorch.parser.parse_record_file import RecordFileParser
from hotwheels.amct_pytorch.utils.save import save_onnx_model
from hotwheels.amct_pytorch.utils.save import save_float_model
from hotwheels.amct_pytorch.utils.save import generate_onnx_file_name
from hotwheels.amct_pytorch.utils.save import split_dir_prefix
from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.utils.model_util import load_pth_file
from hotwheels.amct_pytorch.optimizer.insert_no_weight_retrain_pass import \
    InsertNoWeightRetrainPass
from hotwheels.amct_pytorch.optimizer.scale_symbol_reverse_pass import \
    ScaleSymbolReversePass
from hotwheels.amct_pytorch.utils.update_record_file import update_record_file
from hotwheels.amct_pytorch.utils.vars import RETRAIN_DATA_CONFIG
from hotwheels.amct_pytorch.utils.vars import CALI_QUANT_MODULE_TYPES
from hotwheels.amct_pytorch.optimizer.rnn_insert_dequant_pass import \
    RNNInsertDequantPass
from hotwheels.amct_pytorch.optimizer.record_data_quant_param_pass import \
    RecordDataQuantParamPass
from hotwheels.amct_pytorch.fx.parser.function_replace import Func2ModuleHelper


@check_params(config_file=str,
              model=torch.nn.Module,
              skip_layers=(list, type(None)),
              batch_num=int,
              activation_offset=bool,
              config_defination=(type(None), str))
def create_quant_config(  # pylint: disable=too-many-arguments
        config_file,
        model,
        input_data,
        skip_layers=None,
        batch_num=1,
        activation_offset=True,
        config_defination=None):
    """
    Function: Create quantize configuration json file for amct_pytorch tool
    Parameter: config_file: file path of quantize configuration json file
               model: user mode instance of Torch.nn.Module
               input_data: used to compile model, can be ramdom data
               skip_layers: list of layers that not do quantize, default empty
               batch_num: number of batch that used for calibration
               activation_offset: whether activation quantize with offset
               config_defination: simply config file from user to set
    Return: None
    """
    ModuleHelper.check_is_eval_model(model)
    ModuleHelper.check_model_type(model)
    ModuleHelper.check_model_traceable(model)

    # cope inputs
    config_file = os.path.realpath(config_file)

    try:
        model = ModuleHelper.deep_copy(model)
    except RuntimeError as exception:
        LOGGER.logw(exception, "create_quant_config")

    ModuleHelper(model).check_amct_op()
    try:
        device = next(model.parameters()).device
    except StopIteration:
        device = 'cpu'
    save_dir = os.path.dirname(config_file)
    model = Func2ModuleHelper(model, save_dir).generate_replaced_model().to(device).eval()
    
    # export to onnx
    tmp_onnx = BytesIO()
    Parser.export_onnx(model, input_data, tmp_onnx)

    # parse to graph
    graph = Parser.parse_net_to_graph(tmp_onnx)
    graph.add_model(model)

    save_float_model(graph, config_file, is_retrain=False)
    # create config file for quantizetion
    Configuration.create_quant_config(config_file, graph, skip_layers,
                                      batch_num, activation_offset,
                                      config_defination)
    LOGGER.logi('Create quant config file %s success.' % (config_file))


@check_params(config_file=str,
              modified_model=str,
              record_file=str,
              model=torch.nn.Module,
              input_names=(list, type(None)),
              output_names=(list, type(None)),
              dynamic_axes=(dict, type(None)))
def quantize_model(  # pylint: disable=too-many-arguments
        config_file,
        modified_model,
        record_file,
        model,
        input_data,
        input_names=None,
        output_names=None,
        dynamic_axes=None):
    """
    Function: Init AMCT_PYTORCH tool, trans scale_offset_record_file path to
              abspath, initialize Configuration module.
    Parameter: config_file: quantize configuration json file
               record_file: temporary file to store scale and offset
               model: user pytorch model's model file
               input_data: used to compile model, can be ramdom data
               input_names: list of strings, names to assign to the
                   input nodes of the graph, in order
               output_names: names to assign to the
                   output nodes of the graph, in order
               dynamic_axes: a dictionary to specify dynamic axes of
                   input/output
    Return: model: modified pytorch model for calibration inference.
    """
    try:
        device = next(model.parameters()).device
    except StopIteration:
        device = 'cpu'

    ModuleHelper.check_is_eval_model(model)
    ModuleHelper.check_model_type(model)
    ModuleHelper.check_model_traceable(model)

    config_file = os.path.realpath(config_file)
    file_realpath = files_util.create_empty_file(record_file)

    try:
        model = ModuleHelper.deep_copy(model)
    except RuntimeError as exception:
        LOGGER.logw(exception, "quantize_model")

    ModuleHelper(model).check_amct_op()

    save_dir = os.path.dirname(config_file)
    model = Func2ModuleHelper(model, save_dir).generate_replaced_model().to(device).eval()

    # export to onnx
    tmp_onnx = BytesIO()
    Parser.export_onnx(model, input_data, tmp_onnx,
                       {'input_names': input_names,
                        'output_names': output_names,
                        'dynamic_axes': dynamic_axes})

    # parse to graph
    graph = Parser.parse_net_to_graph(tmp_onnx)
    graph.add_model(model)

    files_util.is_valid_name(modified_model, 'modified model')
    modified_model = os.path.realpath(modified_model)
    save_onnx_model(graph, modified_model)

    Configuration().init(config_file, file_realpath, graph)

    # export modified onnx
    optimizer = ModelOptimizer()
    optimizer.add_pass(InsertDepthwiseConvPass())
    optimizer.do_optimizer(graph, model)
    model.to(device)

    tmp_onnx = BytesIO()
    Parser.export_onnx(model, input_data, tmp_onnx,
                       {'input_names': input_names,
                        'output_names': output_names,
                        'dynamic_axes': dynamic_axes})
    graph = Parser.parse_net_to_graph(tmp_onnx)
    graph.add_model(model)

    save_onnx_model(graph, modified_model)

    optimizer = ModelOptimizer()
    optimizer.add_pass(ScaleSymbolReversePass())
    optimizer.add_pass(RNNWeightsCalibrationPass())
    optimizer.add_pass(WeightsCalibrationPass())
    optimizer.do_optimizer(graph, model)

    save_onnx_model(graph, modified_model)

    # quantize
    optimizer = ModelOptimizer()
    optimizer.add_pass(InsertCaliQuantPass())
    optimizer.do_optimizer(graph, model)

    return model


@check_params(modified_onnx_file=str,
              record_file=str,
              save_path=str,
              calibration_torch_model=torch.nn.Module)
def save_model(modified_onnx_file, record_file, save_path,
               calibration_torch_model):
    """
    Function: save modified_onnx_file to fakequant_onnx_file and
        deploy_onnx_file.
    Parameter:
        modified_onnx_file: a string, the file export from quantize_model
        record_file: a string, path of file containing the scale and offset.
        save_path: a string, the path where to store model and model's name
        calibration_torch_model: original module without conv+bn fuse
    Return: None

    """
    ModuleHelper.check_is_eval_model(calibration_torch_model)
    ModuleHelper.check_model_type(calibration_torch_model)
    ModuleHelper.check_forward_iterations(calibration_torch_model)

    # check inputs
    files_util.is_valid_name(modified_onnx_file, 'modified_onnx_file')
    modified_onnx_file = os.path.realpath(modified_onnx_file)
    graph = Parser.parse_net_to_graph(modified_onnx_file)

    optimizer = ModelOptimizer()
    optimizer.add_pass(RecordDataQuantParamPass())
    optimizer.do_optimizer(graph, calibration_torch_model)

    update_record_file(graph, calibration_torch_model, is_retrain=False)

    optimizer = ModelOptimizer()
    if Configuration().get_fusion_switch():
        optimizer.add_pass(ConvBnFusionPass(is_retrain=False))
    optimizer.do_optimizer(graph, calibration_torch_model)
    files_util.is_valid_name(modified_onnx_file, 'modified_onnx_file')
    modified_onnx_file = os.path.realpath(modified_onnx_file)
    save_onnx_model(graph, modified_onnx_file)

    record_file = Configuration().get_record_file_path()

    # parse record_file
    record_parser = RecordFileParser(record_file, graph, modified_onnx_file)
    if record_parser.is_records_empty():
        raise RuntimeError(
            "record_file is empty, no layers to be quantized. Please "
            "ensure calibration is finished by checking information!")
    records, _ = record_parser.parse()

    _generate_model(graph, records, save_path)


@check_params(config_file=str,
              model=torch.nn.Module,
              config_defination=(type(None), str))
def create_quant_retrain_config(  # pylint: disable=too-many-arguments
        config_file,
        model,
        input_data,
        config_defination=None):
    """
    Function: Create retrain quantize configuration json file for amct_pytorch
        tool
    Parameter: config_file: file path of quantize configuration json file
               model: user mode instance of Torch.nn.Module
               input_data: used to compile model, can be ramdom data
               config_defination: simply config file from user to set
    Return: None
    """
    ModuleHelper.check_is_training_model(model)
    ModuleHelper.check_model_type(model)
    ModuleHelper.check_model_traceable(model)

    # cope inputs
    config_file = os.path.realpath(config_file)

    try:
        model = ModuleHelper.deep_copy(model)
    except RuntimeError as exception:
        LOGGER.logw(exception, "create_quant_retrain_config")

    ModuleHelper(model).check_amct_op()
    try:
        device = next(model.parameters()).device
    except StopIteration:
        device = 'cpu'
    save_dir = os.path.dirname(config_file)

    model = Func2ModuleHelper(model, save_dir).generate_replaced_model().to(device).train()

    # export to onnx
    tmp_onnx = BytesIO()
    Parser.export_onnx(model, input_data, tmp_onnx)

    # parse to graph
    graph = Parser.parse_net_to_graph(tmp_onnx)
    graph.add_model(model)

    save_float_model(graph, config_file, is_retrain=True)

    if config_defination is None:
        RetrainConfig.create_default_retrain_config(config_file, graph)
    # create config file for quantizetion
    else:
        RetrainConfig.create_quant_retrain_config(
            config_file,
            graph,
            config_defination)
    LOGGER.logi('Create quant retrain config file %s success.' %
                (config_file))


@check_params(config_file=str,
              model=torch.nn.Module,
              record_file=str)
def create_quant_retrain_model(  # pylint: disable=too-many-arguments
        config_file,
        model,
        record_file,
        input_data):
    """
    Function: Modify user's model for retrain in train and inference process.
    Parameter: config_file: retrain quantize configuration json file
               model: user pytorch model's model file
               record_file: temporary file to store scale and offset
               input_data: used to compile model, can be ramdom data
    Return: model: modified pytorch model for retrain.
    """
    ModuleHelper.check_is_training_model(model)
    ModuleHelper.check_model_type(model)
    ModuleHelper.check_model_traceable(model)

    config_file = os.path.realpath(config_file)
    record_file = files_util.create_empty_file(record_file)

    try:
        model = ModuleHelper.deep_copy(model)
    except RuntimeError as exception:
        LOGGER.logw(exception, "create_quant_retrain_model")

    model = _modify_original_model(
        model, input_data, config_file, record_file)

    return model


@check_params(config_file=str,
              model=torch.nn.Module,
              record_file=str,
              pth_file=str,
              state_dict_name=(str, type(None)))
def restore_quant_retrain_model(  # pylint: disable=too-many-arguments
        config_file,
        model,
        record_file,
        input_data,
        pth_file,
        state_dict_name=None):
    """
    Function: Modify user's model and restore retrain network from last
        checkpoint.
    Parameter: config_file: retrain quantize configuration json file
               model: user pytorch model's model file
               record_file: temporary file to store scale and offset
               input_data: used to compile model, can be ramdom data
               pth_file: user quant aware training checkpoint file path
               state_dict_name: key value of weight parameter in pth_file
    Return: model: modified pytorch model for retrain.
    """
    ModuleHelper.check_is_training_model(model)
    ModuleHelper.check_model_type(model)
    ModuleHelper.check_model_traceable(model)

    config_file = os.path.realpath(config_file)
    pth_file = os.path.realpath(pth_file)
    record_file = files_util.create_empty_file(record_file)

    try:
        model = ModuleHelper.deep_copy(model)
    except RuntimeError as exception:
        LOGGER.logw(exception, "restore_quant_retrain_model")

    model = _modify_original_model(
        model, input_data, config_file, record_file)

    model = load_pth_file(model, pth_file, state_dict_name)

    return model


@check_params(config_file=str,
              model=torch.nn.Module,
              record_file=str,
              save_path=str,
              input_names=(list, type(None)),
              output_names=(list, type(None)),
              dynamic_axes=(dict, type(None)))
def save_quant_retrain_model(  # pylint: disable=R0913
        config_file,
        model,
        record_file,
        save_path,
        input_data,
        input_names=None,
        output_names=None,
        dynamic_axes=None):
    """
    Function: save modified_onnx_file to fakequant_onnx_file and
        deploy_onnx_file.
    Parameter:
        config_file: retrain quantize configuration json file
        model: retrain model
        record_file: temporary file to store scale and offset
        save_path: a string, the path where to store model and model's name.
        input_data: used to compile model, can be ramdom data
        input_names: list of strings, names to assign to the input nodes of
            the graph, in order
        output_names: names to assign to the output nodes of the graph
            in order
        dynamic_axes: a dictionary to specify dynamic axes of input/output
    Return: None.
    """
    ModuleHelper.check_is_eval_model(model)
    ModuleHelper.check_model_type(model)

    if isinstance(model, (DataParallel, DistributedDataParallel)):
        model = model.module

    # check inputs
    files_util.is_valid_name(config_file, 'config_file')
    config_file = os.path.realpath(config_file)
    record_file = RetrainConfig().get_record_file_path()
    # preprocess retrain model
    export_onnx_item = ExportOnnxItem(input_names=input_names, output_names=output_names, dynamic_axes=dynamic_axes)
    graph, model_copy = _preprocess_retrain_model(model, input_data,
                                                  config_file, export_onnx_item)
    # save model to fakequant and deploy
    record_file = RetrainConfig().get_record_file_path()
    record_parser = RecordFileParser(
        record_file, graph, 'modified_onnx_file after retrain')
    if record_parser.is_records_empty():
        raise RuntimeError(
            "record_file is empty, no layers to be quantized. Please "
            "confirm the process of retrain quantification: whether "
            "the inference process is omitted after the training!")
    records, _ = record_parser.parse()

    _generate_model(graph, records, save_path, is_retrain=True)


def parameters(module):
    """Returns an iterator over module parameters."""

    def _parameters(recurse=True):
        for name, param in module.named_parameters(recurse=recurse):
            if 'acts_comp_reuse' not in name:
                yield param

    return _parameters


def _modify_original_model(model, input_data, config_file, record_file):
    """
    Function: Modify the original model to quantify retraining.
    Inputs:
        model: original model
        input_data: used to compile model, can be ramdom data
        config_file: retrain quantize configuration json file
        record_file: temporary file to store scale and offset
    Returns:
        model: a model processed
    """
    ModuleHelper(model).check_amct_op()

    try:
        device = next(model.parameters()).device
    except StopIteration:
        device = 'cpu'

    save_dir = os.path.dirname(config_file)

    model = Func2ModuleHelper(model, save_dir).generate_replaced_model().to(device).train()

    # export to onnx
    tmp_onnx = BytesIO()
    Parser.export_onnx(model, input_data, tmp_onnx)

    # parse to graph
    graph = Parser.parse_net_to_graph(tmp_onnx)
    graph.add_model(model)

    RetrainConfig.init_retrain(config_file, record_file, graph)

    # quantize
    optimizer = GraphOptimizer()
    optimizer.add_pass(InsertNoWeightRetrainPass(device))
    optimizer.add_pass(InsertRetrainPass(device))
    optimizer.add_pass(ShareActCompPass())
    optimizer.do_optimizer(graph, model)

    # Rewrite the parameters function to eliminate the shared variables
    for item in model.named_modules():
        item[1].parameters = parameters(item[1])

    return model


ExportOnnxItem = namedtuple('ExportOnnxItem', ['input_names', 'output_names', 'dynamic_axes'])


def _preprocess_retrain_model(model, input_data, config_file,
                              export_onnx_item):
    """
    Function: process retrain model before saving as follows:
            1. delete retain module
            2. fuse bn
    Inputs:
        model: retrain model
        input_data: used to compile model, can be ramdom data
        config_file: retrain quantize configuration json file
        record_file: temporary file to store scale and offset (deleted on 2022.04.16, reason: unused)
        input_names: list of strings, names to assign to the input nodes of
            the graph, in order
        output_names: names to assign to the output nodes of the graph
            in order
        dynamic_axes: a dictionary to specify dynamic axes of input/output
        export_onnx_item: combination of field : input_data, output_names, dynamic_axes (Add on 2022.04.16)
    Returns:
        model_copy: a model processed
    """
    ModuleHelper(model).check_amct_retrain_op()

    try:
        device = next(model.parameters()).device
    except StopIteration:
        device = 'cpu'

    # copy model to a new one
    try:
        model_copy = ModuleHelper.deep_copy(model)
    except RuntimeError as exception:
        model_copy = model
        LOGGER.loge(exception, "save_quant_retrain_model")

    # delete retrain pass
    optimizer = ModelOptimizer()
    optimizer.add_pass(DeleteRetrainPass())
    optimizer.add_pass(RepalceSyncBNPass())
    optimizer.do_optimizer(None, model_copy)

    # fuse bn in model
    if 'module' in dir(model_copy):
        model_copy = model_copy.module
    tmp_onnx = BytesIO()
    Parser.export_onnx(model_copy, input_data, tmp_onnx)
    graph = Parser.parse_net_to_graph(tmp_onnx)
    graph.add_model(model_copy)
    update_record_file(graph, model_copy, is_retrain=True)

    retrain_config = RetrainConfig().parse_retrain_config(config_file, graph)

    optimizer = ModelOptimizer()
    optimizer.add_pass(InsertDepthwiseConvPass(is_retrain=True))
    optimizer.do_optimizer(graph, model_copy)
    model_copy.to(device)

    tmp_onnx = BytesIO()
    Parser.export_onnx(model_copy, input_data, tmp_onnx, 
                {'input_names': export_onnx_item.input_names,
                 'output_names': export_onnx_item.output_names,
                 'dynamic_axes': export_onnx_item.dynamic_axes})
    graph = Parser.parse_net_to_graph(tmp_onnx)
    graph.add_model(model_copy)

    optimizer = ModelOptimizer()
    optimizer.add_pass(WeightsCalibrationPass(is_retrain=True))
    optimizer.add_pass(ConvBnFusionPass(is_retrain=True))
    optimizer.do_optimizer(graph, model_copy)

    return graph, model_copy


def _check_config_consistency(retrain_config, single_instance_config):
    ''' Verify the consistency between retrain_config and
        single_instance_config.
    '''

    def _check_retrain_data_config_consistency(value, key, value2):
        for index, val in enumerate(value):
            consistency = _check_item_consistency(val, value2.get(key)[index])
            if not consistency:
                return False
        return True

    def _check_dict_item_consistency(value1, value2):
        for key, value in value1.items():
            if key not in value2.keys():
                return False
            if key == RETRAIN_DATA_CONFIG:
                consistency = _check_retrain_data_config_consistency(
                    value, key, value2)
            else:
                consistency = \
                    _check_item_consistency(value, value2.get(key))
            if not consistency:
                return False
        return True

    def _check_item_consistency(value1, value2):
        ''' Verify the consistency between value1 and value2. '''
        if not isinstance(value1, type(value2)):
            return False
        if isinstance(value1, dict):
            consistency = _check_dict_item_consistency(value1, value2)
            if not consistency:
                return False
        else:
            if value1 != value2:
                return False
        return True

    if retrain_config.keys() != single_instance_config.keys():
        return False

    consistency = True
    for key, value in retrain_config.items():
        consistency = _check_item_consistency(
            value, single_instance_config.get(key))
        if not consistency:
            return False
    return consistency


def _generate_model(graph, records, save_path, is_retrain=False):
    ''' Generate deploy and fakequant onnx model. '''
    save_dir, save_prefix = split_dir_prefix(save_path)
    files_util.create_path(save_dir)

    # generate and save deploy model
    optimizer = GraphOptimizer()
    optimizer.add_pass(WeightQuantPass(records, is_retrain))
    optimizer.add_pass(RNNWeightQuantPass(records, is_retrain))
    optimizer.add_pass(BiasQuantPass(records, is_retrain))
    optimizer.add_pass(RNNBiasQuantPass(records, is_retrain))
    optimizer.do_optimizer(graph)
    deploy_file = generate_onnx_file_name(save_dir, save_prefix, 'Deploy')
    save_onnx_model(graph, deploy_file)

    # generate and save fakequant model
    optimizer = GraphOptimizer()
    optimizer.add_pass(GenQuantParamRecordPass(save_dir, save_prefix,
                                               is_retrain))
    optimizer.add_pass(InsertQuantPass(records))
    optimizer.add_pass(QuantFusionPass())
    optimizer.add_pass(InsertAntiQuantPass(records))
    optimizer.add_pass(RNNInsertDequantPass(records))
    optimizer.add_pass(InsertDequantPass(records))
    optimizer.add_pass(ReplaceQuantPass(records))
    optimizer.add_pass(ReplaceAntiQuantPass(records))
    optimizer.add_pass(ReplaceDequantPass(records))
    optimizer.add_pass(WeightFakequantPass(records, is_retrain))
    optimizer.add_pass(BiasFakequantPass(records))
    optimizer.add_pass(RNNBiasFakequantPass(records))
    optimizer.add_pass(RNNWeightFakeQuantPass(records))

    if not is_retrain:
        gen_fusion_json_pass = GenFusionJsonPass()
        gen_fusion_json_pass.set_dump_file_dir(save_dir, save_prefix)
        optimizer.add_pass(gen_fusion_json_pass)

    optimizer.do_optimizer(graph)
    deploy_file = generate_onnx_file_name(save_dir, save_prefix, 'Fakequant')
    save_onnx_model(graph, deploy_file)


def update_bn_status(calibration_model, training=True):
    """
    Function: Update bn status.
    Parameter:
        model: model to generate graph
        calibration_model: model to be changed
    Return: None.
    """
    update_bn = Configuration().get_update_bn_switch()
    if not update_bn:
        return
    bn_update_config = Configuration().get_bn_update_config()
    bn_momentum = bn_update_config.get('bn_momentum')
    for module in calibration_model.modules():
        if type(module).__name__ == 'BatchNorm2d':
            if training:
                module.train()
                module.momentum = bn_momentum
            else:
                module.eval()
        if type(module).__name__ in CALI_QUANT_MODULE_TYPES:
            if training:
                module.cali_enable = False
            else:
                module.cali_enable = True

