import os
import sys
import copy
import importlib
from typing import Set, Dict, List, Any
import time
import torch
from torch.fx import symbolic_trace, Transformer
import torch.distributed as dist
from hotwheels.amct_pytorch.capacity.capacity_config import REPLACEABLE_FUNC_TYPES
from torch.fx.graph_module import GraphModule
from hotwheels.amct_pytorch.common.utils import files as files_util
from torch.fx.node import Node, Argument, Target, map_arg
from torch.fx.graph import (_format_target, _format_args, get_qualified_name,
                            magic_methods, _type_repr)
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import register_no_weight_quant_type
from hotwheels.amct_pytorch.utils.vars import clear_tmp_register_quant_type
from hotwheels.amct_pytorch.utils.vars import NON_REPLACEABLE_TYPES


TMP_OP_DIR = '.temp_op'
TMP_MODEL_DIR = '.temp_model'

TARGET_OP = ('call_function', 'call_method')


class Func2ModuleHelper():
    def __init__(self, model, save_dir):
        self.model = model
        self.save_dir = save_dir
        self.tmp_op_dir = None
        self.tmp_model_dir = None
        self._init_dir()
        self.node_to_module_mapping = {}

    @classmethod
    def check_node_type(cls, graph_module):
        def _check_un_quantizable_node(node):
            if node.op != 'call_function':
                return
            if node.target in NON_REPLACEABLE_TYPES:
                LOGGER.logw(f"Node with type {repr(node.target)} does not support quant, please "
                        "change its definition to standard module starts with 'torch.nn'!", "symbolic trace")
                raise RuntimeError(f"Node with type {repr(node.target)} does not support quant, "
                        "please change its definition to standard torch.nn.Module!")

        all_nodes = list(graph_module.graph.nodes)
        for node in all_nodes:
            _check_un_quantizable_node(node)

    @classmethod
    def _process_one_define_multi_use_module(cls, graph_module):
        '''
        if a module has been used more than once, make a copy of the module,
        add it to the model, use fx node.name to be its name, make sure each 
        module used only once. Module with learnable parameters like conv, 
        batchnorm can't do copy
        '''
        all_nodes = list(graph_module.graph.nodes)
        used_modules = []
        modules = dict(graph_module.named_modules())
        for node in all_nodes:
            if node.op != 'call_module':
                continue
            # module with learnable parameters should not do deep copy
            cur_module = modules[node.target]
            if len(dict(cur_module.named_parameters())) > 0:
                continue
            if node.target not in used_modules:
                used_modules.append(node.target)
            else:
                module = copy.deepcopy(cur_module)
                used_modules.append(node.name)
                setattr(graph_module, node.name, module)
                node.target = node.name
        return graph_module

    def generate_replaced_model(self):
        '''
        generated model with function replaced to module
        '''
        graph_module = symbolic_trace(self.model)
        self.check_node_type(graph_module)
        graph_module = self._process_one_define_multi_use_module(graph_module)
        self._generate_tmp_module_for_func(graph_module)
        graph_module = self._replace_function_with_tmp_module(graph_module)
        model = self._generate_model_with_function_replaced_by_tmp_module(graph_module)
        self._remove_temp_dir()
        return model

    def _register_fx_node_to_module_mapping(self, fx_node_name, module):
        self.node_to_module_mapping[fx_node_name] = module

    def _get_fx_node_to_module_mapping(self):
        return self.node_to_module_mapping

    def _init_dir(self):
        if dist.is_initialized():
            self.save_dir = os.path.join(self.save_dir, f'rank_{dist.get_rank()}')
        time_str = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
        self.tmp_op_dir = os.path.join(self.save_dir, f'{TMP_OP_DIR}_{time_str}')
        self.tmp_model_dir = os.path.join(self.save_dir, f'{TMP_MODEL_DIR}_{time_str}')

    def _generate_tmp_module_for_func(self, graph_module):
        '''
        generate tmp module to node with node.op 'call_method' or 'call_function'
        '''
        all_nodes = list(graph_module.graph.nodes)
        custom_nodes = []

        def add_placeholder(sub_graph, args):
            for arg in args:
                if isinstance(arg, Node):
                    sub_graph.placeholder(repr(arg))
                if isinstance(arg, tuple) or isinstance(arg, list):
                    sub_graph = add_placeholder(sub_graph, arg)
            return sub_graph

        env: Dict[Any, Any] = {}

        def load_arg(a):
            return map_arg(a, lambda node: env[node.name])

        sys.path.insert(0, self.tmp_op_dir)
        clear_tmp_register_quant_type()

        for node in all_nodes:
            if node.op not in TARGET_OP or node.target not in REPLACEABLE_FUNC_TYPES:
                env[node.name] = node
                continue
            # construct a sub graph for single node
            sub_root_module = dict()
            sub_graph = torch.fx.graph.Graph()
            #expand input args, and those with type 'Node' will be set as input
            sub_graph = add_placeholder(sub_graph, node.args)
            env[node.name] = sub_graph.node_copy(node, load_arg)
            sub_graph.output(node)
            sub_graph_module = GraphModule(sub_root_module, sub_graph)
            # modify code of graph_module.graph
            setattr(sub_graph_module, '_code', _python_code(sub_graph_module.graph))
            files_util.create_path(self.tmp_op_dir)
            sub_graph_module.to_folder(f'{self.tmp_op_dir}/{node.name}', node.name)
            register_no_weight_quant_type(node.name)
            if LOGGER.is_debug_level():
                LOGGER.logi(f"Generate custom op {node.name} in {self.tmp_op_dir}!")
            custom_nodes.append(node)

        for node in custom_nodes:
            if node.name in sys.modules:
                del sys.modules[node.name]
            if f'{node.name}.module' in sys.modules:
                del sys.modules[f'{node.name}.module']
            import_model = importlib.import_module(f'{node.name}')
            custom_op_module = getattr(import_model, node.name)
            self._register_fx_node_to_module_mapping(node.name, custom_op_module)

    def _replace_function_with_tmp_module(self, graph_module):
        '''
        replace function op with module op
        '''
        def get_node_args(args):
            node_args = []
            for arg in args:
                if isinstance(arg, Node):
                    node_args.append(arg)
                if isinstance(arg, tuple) or isinstance(arg, list):
                    node_args.extend(get_node_args(arg))
            return node_args
        fx_node_to_module_mapping = self._get_fx_node_to_module_mapping()
        for node in graph_module.graph.nodes:
            if node.name in fx_node_to_module_mapping.keys():
                # expand input args 
                node_args = get_node_args(node.args)
                node.args = tuple(node_args)
                node.op = 'call_module'
                node.kwargs = {}
                node_name = node.name
                setattr(graph_module, node_name, fx_node_to_module_mapping.get(node.name)())
                node.target = node_name

        graph_module.recompile()
        graph_module.graph.lint()
        return graph_module

    def _generate_model_with_function_replaced_by_tmp_module(self, graph_module):
        sys.path.insert(0, self.tmp_model_dir)
        # modify code of graph_module.graph
        setattr(graph_module, '_code', _python_code(graph_module.graph))
        # generate graph module to module.py
        module_name = "FxModule"
        files_util.create_path(self.tmp_model_dir)
        graph_module.to_folder(self.tmp_model_dir, module_name)
        if 'module' in sys.modules:
            del sys.modules['module']
        model = getattr(importlib.import_module('module'), module_name)
        model = model()
        return model

    def _remove_temp_dir(self):
        if LOGGER.is_debug_level():
            LOGGER.logd(f"Generate op defination in {self.tmp_op_dir}!")
            LOGGER.logd(f"Generate model defination in {self.tmp_model_dir}!")
        else:
            # remove tmp model file
            import shutil
            if os.path.exists(self.tmp_op_dir):
                shutil.rmtree(self.tmp_op_dir)
            if os.path.exists(self.tmp_model_dir):
                shutil.rmtree(self.tmp_model_dir)
            sys.path.remove(self.tmp_op_dir)
            sys.path.remove(self.tmp_model_dir)

            if dist.is_initialized() and dist.get_world_size() > 1:
                LOGGER.logi(f'distributed model: world size is : {dist.get_world_size()}')
                if os.path.exists(self.save_dir):
                    shutil.rmtree(self.save_dir)


def _addindent(s_, numSpaces):
    s = s_.split('\n')
    # don't do anything for single-line stuff
    s = [(numSpaces * ' ') + line for line in s]
    s = '\n'.join(s)
    s = '\n' + s
    return s


def _python_code(graph, root_module='self') -> str:
    """
    Turn this ``Graph`` into valid Python code. This code is changed from
    original python_code method in pytorch source code

    Args:

        root_module (str): The naSetme of the root module on which to look-up
            qualified name targets. This is usually 'self'.

    Returns:

        The string source code generated from this ``Graph``.
    """
    free_vars: List[str] = []
    modules_used: Set[str] = set()
    body: List[str] = []

    # Wrap string in list to pass by reference
    maybe_return_annotation: List[str] = ['']

    def register_modules_used(qualified_name: str):
        if '.' in qualified_name:
            module_name = qualified_name.split('.', maxsplit=1)[0]
            modules_used.add(module_name)

    def type_repr(o: Any):
        typename = _type_repr(o)
        if all(x.isidentifier() for x in typename.split('.')):
            register_modules_used(typename)
        else:
            # this is a constructor type, e.g. typing.List[torch.Tensor]
            modules_used.add(o.__module__)
            for sub_type in o.__args__:
                # make sure we have torch.Tensor
                type_repr(sub_type)
        return typename

    # Run through reverse nodes and record the first instance of a use
    # of a given node. This represents the *last* use of the node in the
    # execution order of the program, which we will use to free unused
    # values
    node_to_last_use: Dict[Node, Node] = {}
    user_to_last_uses: Dict[Node, List[Node]] = {}

    def register_last_uses(n: Node, user: Node):
        if n not in node_to_last_use:
            node_to_last_use[n] = user
            user_to_last_uses.setdefault(user, []).append(n)

    for node in reversed(graph.nodes):
        map_arg(node.args, lambda n: register_last_uses(n, node))
        map_arg(node.kwargs, lambda n: register_last_uses(n, node))

    def delete_unused_values(user: Node):
        """
        Delete values after their last use. This ensures that values that are
        not used in the remainder of the code are freed and the memory usage
        of the code is optimal.
        """
        if user.op == 'placeholder':
            return
        if user.op == 'output':
            body.append('\n')
            return
        nodes_to_delete = user_to_last_uses.get(user, [])
        if len(nodes_to_delete):
            to_delete_str = ' = '.join(
                [n.name for n in nodes_to_delete] + ['None'])
            body.append(f';  {to_delete_str}\n')
        else:
            body.append('\n')

    def emit_node(node: Node):
        if node.op == 'placeholder':
            maybe_type_annotation = '' if node.type is None else f' : {type_repr(node.type)}'
            maybe_default_arg = '' if not node.args else f' = {repr(node.args[0])}'
            free_vars.append(
                f'{node.target}{maybe_type_annotation}{maybe_default_arg}')
            raw_name = node.target.replace('*', '')
            if raw_name != node.name:
                body.append(f'{node.name} = {raw_name}\n')
            return
        elif node.op == 'call_method':
            body.append(
                f'{node.name} = {_format_target(repr(node.args[0]), node.target)}'
                f'({_format_args(node.args[1:], node.kwargs)})')
            return
        elif node.op == 'call_function':
            # pretty print operators
            if node.target.__module__ == '_operator' and node.target.__name__ in magic_methods:
                body.append(
                    f'{node.name} = {magic_methods[node.target.__name__].format(*(repr(a) for a in node.args))}')
                return
            qualified_name = get_qualified_name(node.target)
            register_modules_used(qualified_name)
            if qualified_name == 'getattr' and \
                    isinstance(node.args, tuple) and \
                    isinstance(node.args[1], str) and \
                    node.args[1].isidentifier():
                # pretty print attribute access
                body.append(
                    f'{node.name} = {_format_target(repr(node.args[0]), node.args[1])}')
                return
            body.append(
                f'{node.name} = {qualified_name}({_format_args(node.args, node.kwargs)})')
            return
        elif node.op == 'call_module':
            body.append(
                f'{node.name} = {_format_target(root_module, node.target)}({_format_args(node.args, node.kwargs)})')
            return
        elif node.op == 'get_attr':
            body.append(
                f'{node.name} = {_format_target(root_module, node.target)}')
            return
        elif node.op == 'output':
            if node.type is not None:
                maybe_return_annotation[0] = f" -> {type_repr(node.type)}"
            body.append(f'return {repr(node.args[0])}')
            return
        raise NotImplementedError(f'node: {node.op} {node.target}')

    for node in graph.nodes:
        # NOTE: emit_node does not emit a string with newline. It depends
        # on delete_unused_values to append one
        emit_node(node)
        delete_unused_values(node)

    # repr() for inf and nan floating point values aren't parseable by
    # python as literals. Explicitly import the names from the ``math`` module.
    import_strs = [f'import {name}' for name in sorted(modules_used)]
    import_block = '\n'.join(import_strs)

    if len(body) == 0:
        # If the Graph has no non-placeholder nodes, no lines for the body
        # have been emitted. To continue to have valid Python code, emit a
        # single pass statement
        body.append('pass\n')

    # the following code is different from original code
    # add a '\n' before the first import_block, to make sure its indent peforms well,
    # add _addindent(import_block, 4) in forward method to make sure the extend model
    # can be imported before used
    code = ''.join(body)
    code = '\n'.join('    ' + line for line in code.split('\n'))
    fn_code = f"""\
\n
{import_block}
def forward(self, {', '.join(free_vars)}){maybe_return_annotation[0]}:
{_addindent(import_block, 4)}\n
{code}"""

    return fn_code