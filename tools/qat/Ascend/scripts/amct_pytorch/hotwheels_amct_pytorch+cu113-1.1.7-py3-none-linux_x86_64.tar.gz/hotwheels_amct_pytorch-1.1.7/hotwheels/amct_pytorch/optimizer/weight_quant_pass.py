#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quant weight from float32 to int8.

"""
import numpy as np

from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.custom_op.arq.arq import weight_quant_np
from hotwheels.amct_pytorch.custom_op.lnq_retrain.lnq_retrain import lnq_cali_real
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import RETRAIN_WEIGHT_CONFIG
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.optimizer.weight_calibration import WeightsCalibrationPass
from hotwheels.amct_pytorch.configuration.check import GraphChecker


class WeightQuantPass(BaseFusionPass):
    """
    Function: Quant weight from float32 to int8
    APIs: match_pattern, do_pass, quant_weight
    """

    def __init__(self, records, is_retrain):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        if is_retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()
        self.records = records
        self.is_retrain = is_retrain

    def match_pattern(self, node):
        """
        Function: Match the node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if not GraphChecker.check_onnx_quantize_type(node):
            return False
        if node.name not in self.records:
            return False
        if node.type in RNN_ONNX_TYPES:
            return False

        return True

    def weight_quant(self, weight, object_node, scale_w_array, offset_w_array):
        layer_config = self.conf.get_layer_config(object_node.name)
        if self.is_retrain:
            wts_param = layer_config.get(RETRAIN_WEIGHT_CONFIG)
            wts_algo = wts_param['algo']
        else:
            wts_param = layer_config.get(WEIGHT_QUANT_PARAMS)
            wts_algo = wts_param['wts_algo']

        int8_weight = weight_quant_np(
            weight,
            scale_w_array,
            offset_w_array,
            self.records.get(object_node.name).get('weight_num_bits'))

        if wts_algo == 'lnq_retrain' or wts_algo == 'snq_quantize':
            int4_weight = lnq_cali_real(
                int8_weight,
                self.records.get(object_node.name).get('params'))
            int4_weight = int4_weight.cpu().numpy()
            return int4_weight
        else:
            return int8_weight

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual quantization and node's weight is changed to int8.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the graph will be modified.
        Return: None
        """
        # get weight quantization information
        weight_param = QuantOpInfo.get_weight_node(object_node)
        weight_helper = TensorProtoHelper(weight_param.proto)
        weight = weight_helper.get_data().astype(np.float32)

        if object_node.type == 'ConvTranspose':
            weight = WeightsCalibrationPass. \
                adjust_deconv_weight_np_shape(object_node, weight)
            scale_w = self.records.get(object_node.name).get('weight_scale')
            offset_w = self.records.get(object_node.name).get('weight_offset')
            int8_weight = self.weight_quant(weight, object_node, scale_w,
                                            offset_w)
            int8_weight = WeightsCalibrationPass. \
                adjust_deconv_weight_np_shape(object_node, int8_weight)
            int8_weight = int8_weight.reshape([-1])
        else:
            scale_w = self.records.get(object_node.name).get('weight_scale')
            offset_w = self.records.get(object_node.name).get('weight_offset')
            int8_weight = self.weight_quant(weight, object_node, scale_w,
                                            offset_w)
            int8_weight = int8_weight.reshape([-1])

        weight_helper.clear_data()
        weight_helper.set_data(int8_weight, 'INT8')

        LOGGER.logd("Quant weight from int32 to int8 for layer '{}' "
                    "success!".format(object_node.name), 'WeightQuantPass')
