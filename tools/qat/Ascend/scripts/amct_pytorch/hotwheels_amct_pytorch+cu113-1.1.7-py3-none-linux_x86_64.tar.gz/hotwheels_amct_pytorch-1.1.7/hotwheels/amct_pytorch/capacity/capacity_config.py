import operator as op
import torch
import torch.nn.functional as F


QUANTIZABLE_TYPES = ('Conv2d', 'Linear', 'ConvTranspose2d', 'LSTM')
QUANTIZABLE_ONNX_TYPES = ('Conv', 'Gemm', 'MatMul', 'ConvTranspose', 'LSTM')

REPLACEABLE_FUNC_TYPES = ('add', 'add_', op.add, torch.add, 'mul', 'mul_',
    'multipy', 'multiply_', op.mul, torch.mul, torch.multiply, 'sub', op.sub, torch.sub,
    'reshape', torch.reshape, 'max', torch.max, 'mean', torch.mean, 'min', torch.min, 
    'split', torch.split, 'chunk', torch.chunk, 'matmul', torch.matmul, 'sigmoid', torch.sigmoid, 
    F.sigmoid, 'tanh', torch.tanh_, F.tanh, torch.tanh, 'transpose',
    'transpose_', torch.transpose, 'view', 'flatten', torch.flatten, torch.cat,
    torch.transpose, F.avg_pool2d, F.max_pool2d, F.adaptive_max_pool2d,
    F.adaptive_avg_pool2d, F.relu, F.relu_, F.softmax, torch.argmin, 'argmin', torch.exp,
    torch.sum, torch.log, torch.div, torch.squeeze, torch.clamp, torch.argmax, torch.reciprocal, 'permute')
     
NO_WEIGHT_QUANT_TYPES = ['MaxPool2d', 'AvgPool2d', 'AdaptiveMaxPool2d',
    'AdaptiveAvgPool2d', 'BatchNorm2d', 'ReLU', 'Sigmoid', 'Tanh', 'Softmax', 'Flatten', 'Upsample', 'LeakyReLU',
                         'ELU', 'LogSoftmax', 'InstanceNorm2d']
NO_WEIGHT_QUANT_ONNX_TYPES = ('MaxPool', 'AveragePool', 'GlobalMaxPool', 'GlobalAveragePool',
    'Add', 'Concat', 'Split', 'Transpose', 'Reshape', 'Mul', 'Max', 'ReduceMax', 'Min',
    'ReduceMin', 'Mean', 'ReduceMean', 'BatchNormalization', 'Relu', 'Sigmoid', 'Tanh',
    'Softmax', 'Slice', 'Flatten', 'MatMul', 'Resize', 'ArgMin', 'Exp', 'Sub', 'ReduceSum', 'LeakyRelu', 'Log', 'Div',
                              'Squeeze', 'Clip', 'ArgMax', 'Elu', 'LogSoftmax', 'InstanceNormalization')
DEFAULT_UNQUANTIZE_ONNX_TYPES = ('Relu', 'BatchNormalization')