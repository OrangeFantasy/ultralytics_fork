#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

lnqRetrain Function

"""
import torch  # pylint: disable=E0401
import numpy as np
from torch.autograd import Function  # pylint: disable=E0401

import hotwheels.amct_pytorch.custom_op.amct_pytorch_ops as amct_pytorch_ops
from hotwheels.amct_pytorch.custom_op.utils import check_quant_data
from hotwheels.amct_pytorch.common.config.field import MAX_ITERATION
from hotwheels.amct_pytorch.common.config.field import MIN_DISTANCE
from hotwheels.amct_pytorch.utils.vars import CLUSTER_FREQ


class LnqRetrainFunction(Function):
    """
    Function: Run learnable uniform retrain process for quantization of the
        given layer.
    APIs: luq retrain forward
    """

    @staticmethod
    def forward(ctx, weight_tensor, clip_max, centroids, wts_config):
        check_quant_data(weight_tensor, 'weight')
        lnq_param = amct_pytorch_ops.LnqParam(wts_config['num_tracked_batches'],
                                              int(wts_config['training']), 0, wts_config['cluster_freq'],
                                              wts_config['max_iteration'], wts_config['min_distance'])
        status, fakequant_weight = amct_pytorch_ops.lnq_retrain_forward(
            weight_tensor, clip_max, wts_config['num_bits'], centroids,
            lnq_param)
        if status != 0:
            raise RuntimeError("lnq retrain forward failed!")

        ctx.save_for_backward(clip_max, weight_tensor, centroids)
        return fakequant_weight

    @staticmethod
    def backward(ctx, input_grad):
        clip_max, weight_tensor, centroids = ctx.saved_tensors
        output_grad, clip_max_grad = amct_pytorch_ops.lnq_retrain_backward(
            input_grad, weight_tensor, clip_max, centroids)
        output_gradient = (output_grad, clip_max_grad, None, None, None, None)
        return output_gradient


def lnq_fake_quant(weight_tensor, weight_clip_max, num_bits, centroids):
    lnq_param = amct_pytorch_ops.LnqParam(0, 0, 0, CLUSTER_FREQ,
                                          MAX_ITERATION, MIN_DISTANCE)
    status, fake_quant_weight = amct_pytorch_ops.lnq_retrain_forward(
        weight_tensor,
        torch.tensor(weight_clip_max).to(weight_tensor.device),
        num_bits, torch.tensor(centroids).to(weight_tensor.device),
        lnq_param)
    if status != 0:
        raise RuntimeError("lnq retrain fakequant forward failed!")
    return fake_quant_weight


def lnq_cali_real(weight_tensor, params):
    params = np.frombuffer(params, dtype=np.uint8)
    return amct_pytorch_ops.lnq_quant(torch.tensor(weight_tensor),
                                      torch.tensor(params))


def lnq_cali_fake_quant(weight_tensor, params):
    params = np.frombuffer(params, dtype=np.uint8)
    return amct_pytorch_ops.lnq_dequant(torch.tensor(weight_tensor),
                                        torch.tensor(params))


@torch.no_grad()
def lnq_export_param(weight_tensor, clip_max, centroids):
    status, scale, cluster_info = amct_pytorch_ops.lnq_export_param(
        weight_tensor, clip_max, centroids)
    if status != 0:
        raise RuntimeError("lnq export param failed!")
    return scale, cluster_info