# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

field defination in json config.

"""
import os
import json
from collections import namedtuple
from collections import OrderedDict
from hotwheels.amct_pytorch.custom_op.utils import get_node_input_num
from hotwheels.amct_pytorch.utils.vars import RETRAIN_WEIGHT_CONFIG
from hotwheels.amct_pytorch.utils.vars import RETRAIN_DATA_CONFIG
from hotwheels.amct_pytorch.utils.vars import MULTI_INPUT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import NON_INSIST_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import CUBE_OPERATIONS
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.common.utils.check_params import check_outputs_consistency
from hotwheels.amct_pytorch.common.utils.check_params import check_no_command_layer_consistency
from hotwheels.amct_pytorch.common.utils.util import config_optimize_with_om
from hotwheels.amct_pytorch.common.config.config_base import ConfigBase
from hotwheels.amct_pytorch.common.utils.util import find_repeated_items
from hotwheels.amct_pytorch.common.utils.util import check_no_repeated
from hotwheels.amct_pytorch.common.retrain_config.retrain_field import RootConfig
from hotwheels.amct_pytorch.common.retrain_config.retrain_proto import RetrainProtoConfig
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_ONNX_TYPES
from hotwheels.amct_pytorch.utils.log import LOGGER  # pylint: disable=relative-beyond-top-level
from hotwheels.amct_pytorch.common.utils.files import (
    create_empty_file,
    FILE_ACCESS_FLAG,
    FILE_MODE
)
from hotwheels.amct_pytorch.common.utils.vars import WITH_OFFSET

GraphObjects = namedtuple('GraphObjects', ['graph_querier', 'graph_checker'])

_MODULE_NAME = 'Retrain Config'


class RetrainConfigBase():
    '''retraon config base'''

    def __init__(self, graph_objects, capacity):
        ''' inner method '''
        self.graph_objects = graph_objects
        self.capacity = capacity
        self.graph_querier = graph_objects.graph_querier
        self.graph_checker = graph_objects.graph_checker
        self.config_tree = RootConfig(self.graph_querier, self.capacity, self.graph_checker)
        self.supported_types = QUANTIZABLE_ONNX_TYPES
        self.supported_onnx_types = QUANTIZABLE_ONNX_TYPES
        self.supported_no_weight_types = NO_WEIGHT_QUANT_ONNX_TYPES

    @staticmethod
    def check_deconv_layer_config(node, layer_config):
        if not layer_config.get('retrain_enable', False):
            return
        if node.type != 'ConvTranspose':
            return
        attr_helper = AttributeProtoHelper(node.proto)
        group = 1
        if attr_helper.has_attr('group'):
            group = attr_helper.get_attr_value('group')
        if group <= 1:
            return
        raise ValueError('ConvTranspose layer {} does not support '
            'retrain as it has more than one group'.format(node.name))

    @staticmethod
    def check_retrain_consistency(graph, retrain_layers, retrain_config):
        check_outputs_consistency(graph, retrain_layers, retrain_config, is_retrain=True)
        for layer in retrain_layers:
            try:
                node = graph.get_node_by_name(layer)
            except RuntimeError:
                LOGGER.logw('layer {} not in graph, it might exist in training'
                        ' mode.'.format(layer))
                continue
            check_no_command_layer_consistency(node, retrain_config, graph, is_retrain=True)
            RetrainConfigBase.check_deconv_layer_config(node, retrain_config[layer])

    @staticmethod
    def disable_quant_config(
            supported_layers, unquantize_layers, ordered_config, graph):
        '''find all layers in white list and disable their quant config'''
        for key, value in ordered_config.items():
            if isinstance(value, dict):
                if key in unquantize_layers:
                    value['retrain_enable'] = False

        def set_consistent_quant_config(output_anchor, layer_name):
            for input_anchor in output_anchor.get_peer_input_anchor():
                output_name = input_anchor.node.name
                if output_name in ordered_config.keys() and \
                        ordered_config[output_name]['retrain_enable']:
                    ordered_config[layer_name]['retrain_enable'] = True
                    break

        def set_no_command_layer_config(output_anchor, layer_name):
            node = output_anchor.node
            if node.type in NON_INSIST_ONNX_TYPES:
                ordered_config[layer_name]['retrain_enable'] = True
        # The same bottom should share the quantization strategy,
        # quantize the layers in white list if they
        # share bottoms with other layers to be quantized
        for layer_name in unquantize_layers:
            node = graph.get_node_by_name(layer_name)
            # traverse all bottoms and find
            # the only top connected with each bottom
            for in_anchor in node.input_anchors:
                peer_output_anchor = in_anchor.get_peer_output_anchor()
                # find all bottoms linked to this top,
                # if anyone to be quantized, quantize the whole layer
                set_consistent_quant_config(peer_output_anchor, layer_name)
                # no command layers should have same quant config for inputs
                # and outputs
                set_no_command_layer_config(peer_output_anchor, layer_name)

        for layer_name in ordered_config.keys():
            if layer_name not in supported_layers:
                continue
            node = graph.get_node_by_name(layer_name)
            if node.type == 'ConvTranspose':
                attr_helper = AttributeProtoHelper(node.proto)
                group = 1
                if attr_helper.has_attr('group'):
                    group = attr_helper.get_attr_value('group')
                if group > 1:
                    ordered_config[layer_name][
                        'retrain_weight_config']['channel_wise'] = False

    @staticmethod
    def check_override_layers(override_layers, valid_layers):
        if not set(override_layers).issubset(set(list(valid_layers.keys()))):
            raise ValueError("some override_layer in {} not in valid_layers "
                "{}".format(override_layers, valid_layers.keys()))

    @staticmethod
    def check_skip_layer(skip_layers, valid_layers):
        if not set(skip_layers).issubset(set(list(valid_layers.keys()))):
            raise ValueError("some skip layers in {} not in valid_layers {}".
                             format(skip_layers, valid_layers.keys()))

    @staticmethod
    def check_override_types(override_types, supported_onnx_types):
        if not set(override_types).issubset(set(list(supported_onnx_types))):
            raise ValueError("some override layers types {} not supported,"
                             " {} are supported".format(override_types,
                             supported_onnx_types))

    @staticmethod
    def check_skip_layer_types(skip_layer_types, supported_onnx_types):
        if not set(skip_layer_types).issubset(set(list(supported_onnx_types))):
            raise ValueError("some skip layers types {} not supported, {} are "
                             "supported".format(skip_layer_types,
                                                supported_onnx_types))

    @staticmethod
    def set_retrain_data_weight_with_no_offset(ordered_config, graph, config_key):
        '''
        Function: insert with_offset into retrain_data_config of each matmul layer
        Paramter: ordered config & graph
        return: None (ordered_config modified internally)
        '''
        # filter node type
        def _check_matmul(node):
            return node.type == 'MatMul'
        for node in filter(_check_matmul, graph.nodes):
            # get retrain_data_config of layer node.name
            retrain_data_config = ordered_config.\
                get(node.name, {}).\
                get(RETRAIN_DATA_CONFIG, [])
            '''
            traverse each input on matmul node and ensure peer input from parent node being same
            index in traverse used to get corresponding input anchor -> output_anchor -> all input anchors
            '''
            for index, input_data_config in enumerate(retrain_data_config):
                if input_data_config.get('algo') == 'luq_retrain':
                    input_data_config[WITH_OFFSET] = input_data_config.get(WITH_OFFSET, False)
                # get all peer_input_anchors from parent node with call chaining
                peer_input_anchors = node.get_input_anchor(index). \
                    get_peer_output_anchor(). \
                    get_peer_input_anchor()
                RetrainConfigBase.no_insist_to_matmul_setter(node.get_input_anchor(index).get_peer_output_anchor().node,
                                                             ordered_config, config_key)
                for peer_input_anchor in peer_input_anchors:
                    # if peer_input_anchor indicates the init matmul node, skip current process
                    if peer_input_anchor.node.name == node.name:
                        continue
                    '''
                    get peer retrain data config list by peer_input_anchor.node
                    find the sub_config need modifying using peer_input_anchor.index
                    '''
                    peer_retrain_data_config = ordered_config. \
                        get(peer_input_anchor.node.name, {}). \
                        get(RETRAIN_DATA_CONFIG, [])
                    peer_retrain_data_config[peer_input_anchor.index][WITH_OFFSET] = input_data_config. \
                        get(WITH_OFFSET)

    @staticmethod
    def no_insist_to_matmul_setter(node, ordered_config, config_key):
        if node.type in NON_INSIST_ONNX_TYPES:
            node_config = ordered_config.get(node.name, {}).get(config_key, [])
            for idx, input_config in enumerate(node_config):
                input_config[WITH_OFFSET] = input_config.get(WITH_OFFSET, False)
                peer_output_anchor = node.get_input_anchor(idx).get_peer_output_anchor()
                peer_node = peer_output_anchor.node
                ConfigBase.no_insist_to_matmul_setter(peer_node, ordered_config, config_key)

    def set_config_by_graph_construct(self, ordered_config, graph):
        '''set the config by the graph's construction'''
        self.set_retrain_data_weight_with_no_offset(ordered_config, graph, RETRAIN_DATA_CONFIG)

    def get_supported_layers(self, graph):
        ''' inner method '''
        layers_info = self.graph_querier.get_name_type_dict(graph)
        quant_layers = self.graph_querier.get_support_quant_layers(graph)

        supported_layers = {}
        for layer, layer_type in layers_info.items():
            if layer_type in self.supported_onnx_types and layer in quant_layers:
                supported_layers[layer] = layer_type
        for layer, layer_type in layers_info.items():
            if layer_type in self.supported_no_weight_types and \
                    layer in quant_layers:
                supported_layers[layer] = layer_type

        quant_layers = self.check_quant_layers_valid(
            graph, list(supported_layers.keys()), level='warning')
        supported_layers = {
            layer: supported_layers[layer]
            for layer in quant_layers
        }

        return supported_layers

    def concat_optimize(self, ordered_config, graph):
        """
        concat layer will be modified specificly
        case1: all inputs of concat layer is one out one referenced
                conv1 conv2 conv3
                  \     |     /
                   \    |    /
                    \   |   /
                     \  |  /
                      concat
                        |
                      conv4
                        |
        in this case, the retrain layer will be added before conv4, no quant
        layer will be added before concat layer
                conv1 conv2 conv3
                  \     |     /
                   \    |    /
                    \   |   /
                     \  |  /
                      concat
                        |
                      retrain
                        |
                      conv4
                        |
        case2: one input of concat layer is non inst layer
              concat1 conv2 conv3
                  \     |     /
                   \    |    /
                    \   |   /
                     \  |  /
                      concat2
                        |
                      conv4
                        |
        in this case, one retrain layer will be added between concat1 and
        concat2, the retrain quant params are from concat1, if concat1 is
        replaced to other non inst layer like split or reshape, the
        retrain layer will also be added at the same way
               concat1 conv2 conv3
                  \     |     /
                retrain |    /
                    \   |   /
                     \  |  /
                      concat2
                        |
                      conv4
                        |
        case3: one input of concat layer is one out multiple referenced
                conv1 conv2 conv3
                  \     |     /\
                   \    |    /  \
                    \   |   /    \
                     \  |  /    conv5
                      concat
                        |
                      conv4
        in this case, conv3 is one out two referenced, one retrain layer will be
        added between conv3 and concat, the retrain quant params are from conv5
                conv1 conv2 conv3
                  \     |     |
                   \    |  retrain
                    \   |   /    \
                     \  |  /    conv5
                      concat
                        |
                      quant
                        |
                      conv4
        """
        supported_layers = self.get_supported_layers(graph)
        for layer_name in ordered_config.keys():
            if layer_name not in supported_layers.keys():
                continue
            node = graph.get_node_by_name(layer_name)
            if node.type != 'Concat':
                continue
            for input_anchor in node.input_anchors:
                index = input_anchor.index
                peer_output_anchor = input_anchor.get_peer_output_anchor()
                input_node = peer_output_anchor.node
                # case2
                if input_node.type in NON_INSIST_ONNX_TYPES:
                    continue
                # case3
                if len(peer_output_anchor.get_peer_input_anchor()) > 1:
                    continue
                ordered_config[layer_name]['retrain_data_config'][index]['num_bits'] = -1

    def check_quant_layers_valid(self, graph, quant_layers, level='error'):
        '''check quant layer's validation by the graph'''
        # only tensorflow need to check matmul_transpose and placeholder and
        # gradient_op
        if hasattr(self.graph_checker, 'check_gradient_op'):
            quant_layers = self.graph_checker.check_gradient_op(
                graph, quant_layers, level)
        if hasattr(self.graph_checker, 'check_matmul_transpose'):
            quant_layers = self.graph_checker.check_matmul_transpose(
                graph, quant_layers, level)
        if hasattr(self.graph_checker, 'check_quantize_placeholder'):
            quant_layers = self.graph_checker.check_quantize_placeholder(
                graph, quant_layers, level)
        return quant_layers

    def create_default_config(self, config_file, graph):
        ''' inner method '''
        supported_layers = self.get_supported_layers(graph)

        if not supported_layers:
            raise ValueError("No supported layers")

        self._clear_config_tree()
        self.config_tree.build_default(supported_layers, graph)
        ordered_config = self.config_tree.dump()
        self.set_config_by_graph_construct(ordered_config, graph)

        unquantize_layers = \
            self.graph_querier.get_default_unquantize_layers(graph)
        RetrainConfigBase.disable_quant_config(
            supported_layers, unquantize_layers, ordered_config, graph)
        remove_layers = \
            self.graph_querier.get_default_remove_layers(graph)
        ConfigBase.remove_quant_config(remove_layers, ordered_config)

        config_file = create_empty_file(config_file)
        with os.fdopen(os.open(config_file, FILE_ACCESS_FLAG, FILE_MODE), 'w') as fid:
            json.dump(ordered_config, fid, indent=4, separators=(',', ':'))

    def generate_layer_config(self, proto, valid_layers, graph):
        ''' inner method '''
        data_config = proto.get_retrain_data_quant_config()
        weights_config = proto.get_retrain_weights_config()
        override_layers = proto.get_override_layers()
        override_types = proto.get_override_layer_types()
        skip_layers = proto.get_skip_layers()
        skip_layer_types = proto.get_skip_layer_types()
        om_config = proto.get_om_config()

        RetrainConfigBase.check_override_layers(override_layers, valid_layers)
        RetrainConfigBase.check_skip_layer(skip_layers, valid_layers)
        RetrainConfigBase.check_override_types(override_types,
            self.supported_onnx_types)
        RetrainConfigBase.check_skip_layer_types(skip_layer_types,
            self.supported_onnx_types)

        config = {}
        # fill params
        for layer, layer_type in valid_layers.items():
            config[layer] = OrderedDict()
            node = graph.get_node_by_name(layer)
            input_num = get_node_input_num(node)
            # set quant_enable
            if layer in skip_layers or layer_type in skip_layer_types:
                config[layer]['retrain_enable'] = False
            else:
                config[layer]['retrain_enable'] = True
            # set retrain_data_config and retrain_weight_config
            if layer in override_layers:
                retrain_data_params, retrain_weight_params = \
                    proto.read_override_config(layer)
                config[layer][RETRAIN_DATA_CONFIG] = \
                    [retrain_data_params] * input_num
                if layer_type in self.supported_onnx_types:
                    config[layer][RETRAIN_WEIGHT_CONFIG] = \
                        retrain_weight_params
            elif layer_type in override_types:
                retrain_data_params, retrain_weight_params = \
                    proto.read_override_type_config(layer_type)
                config[layer][RETRAIN_DATA_CONFIG] = \
                    [retrain_data_params] * input_num
                if layer_type in self.supported_onnx_types:
                    config[layer][RETRAIN_WEIGHT_CONFIG] = \
                        retrain_weight_params
            else:
                config[layer][RETRAIN_DATA_CONFIG] = []
                for _ in range(input_num):
                    config[layer][RETRAIN_DATA_CONFIG].append(
                        data_config.copy())
                if layer_type in self.supported_onnx_types:
                    config[layer][RETRAIN_WEIGHT_CONFIG] = \
                        weights_config.copy()
            config_optimize_with_om(config, node, layer, om_config, True)
        return config

    def create_config_from_proto(self, config_file, graph, config_defination):
        '''
        create json config file from proto config.
        Inputs:
            config_file: json config file path
            graph: a graph
            config_defination: proto config path
        Returns:
            None
        '''
        config_defination = os.path.realpath(config_defination)
        proto = RetrainProtoConfig(config_defination, self.capacity)
        valid_layers = self.get_supported_layers(graph)

        config = self.generate_layer_config(proto, valid_layers, graph)

        global_config = proto.get_proto_config()
        for item in global_config.keys():
            if global_config[item] is not None:
                config[item] = global_config[item]

        self._clear_config_tree()
        self.config_tree.set_strong_check(False)
        self.config_tree.build(config, valid_layers, graph)
        ordered_config = self.config_tree.dump()
        self.set_config_by_graph_construct(ordered_config, graph)

        unquantize_layers = \
            self.graph_querier.get_default_unquantize_layers(graph)
        RetrainConfigBase.disable_quant_config(
            valid_layers, unquantize_layers, ordered_config, graph)
        remove_layers = \
            self.graph_querier.get_default_remove_layers(graph)
        ConfigBase.remove_quant_config(remove_layers, ordered_config)

        config_file = create_empty_file(config_file)
        with os.fdopen(os.open(config_file, FILE_ACCESS_FLAG, FILE_MODE), 'w') as fid:
            json.dump(ordered_config, fid, indent=4, separators=(',', ':'))

    def parse_config_file(self, config_file, graph):
        '''
        parse config file, check incorrect value, and fill default value.
        Inputs:
            config_file: json config file path
            graph: a graph
        Returns:
            quant_config: quant config dict
        '''
        def _detect_repetitive_key_hook(lst):
            '''
            a hook function for detect repeated key in config file.
            '''
            keys = [key for key, val in lst]
            repeat_keys = find_repeated_items(keys)
            check_no_repeated(repeat_keys, config_file)
            result = {}
            for key, val in lst:
                result[key] = val
            return result

        with open(config_file, 'r') as fid:
            quant_config = json.load(
                fid, object_pairs_hook=_detect_repetitive_key_hook)

        valid_layers = self.get_supported_layers(graph)
        remove_layers = \
            self.graph_querier.get_default_remove_layers(graph)
        valid_layer_keys = []
        for item in valid_layers.keys():
            valid_layer_keys.append(item)
        for item in valid_layer_keys:
            if item in remove_layers:
                del valid_layers[item]

        for layer in valid_layers:
            if valid_layers[layer] in CUBE_OPERATIONS \
                and (layer not in quant_config or not quant_config[layer]['retrain_enable']):
                    raise ValueError("Layer {} must be quantized, "
                    'as it is an operation calculated on CUBE.'.format(layer))

        self.check_quant_layers_valid(graph, list(valid_layers.keys()))
        self.config_tree.build(quant_config, valid_layers, graph)
        quant_config = self.config_tree.dump()

        LOGGER.logd('quant_config is {}'.format(quant_config),
                    module_name=_MODULE_NAME)
        quant_config['support_types'] = self.supported_types
        quant_config['activation_offset'] = True
        layers_to_delete = []
        layers_to_quant = []
        for key, value in quant_config.items():
            if isinstance(value, dict):
                if not value['retrain_enable']:
                    layers_to_delete.append(key)
                else:
                    layers_to_quant.append(key)
        for layer in layers_to_delete:
            del quant_config[layer]
        RetrainConfigBase.check_retrain_consistency(
            graph, list(layers_to_quant), quant_config)
        self.concat_optimize(quant_config, graph)
        return quant_config

    def _clear_config_tree(self):
        ''' inner method '''
        self.config_tree = RootConfig(self.graph_querier, self.capacity, self.graph_checker)


def get_layers_from_config(quant_config, global_keys):
    '''Get all layer names form quant_config '''
    layer_names = list()
    for key in quant_config:
        if key not in global_keys:
            layer_names.append(key)
    return layer_names
