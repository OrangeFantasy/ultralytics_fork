#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

activation luq retrain function

"""
import torch # pylint: disable=E0401
from torch.autograd import Function # pylint: disable=E0401

import hotwheels.amct_pytorch.custom_op.amct_pytorch_ops as amct_pytorch_ops
from hotwheels.amct_pytorch.custom_op.utils import get_distributed_info


class ActsLuqRetrainFunction(Function):
    """
    Function: Run learnable uniform retrain process for quantization of
        the given layer.
    APIs: activation luq retrain forward
    """
    @staticmethod
    def forward(ctx, input_tensor, clip_max, num_bits, is_symmetric,
                cur_batch):
        fakequant_input, scale, offset = amct_pytorch_ops.\
            acts_luq_retrain_forward(input_tensor,
            clip_max, num_bits, is_symmetric)

        need_sync, process_group, world_size = get_distributed_info()

        if need_sync and cur_batch == 1:
            clip_max_all = torch.empty(
                world_size, 1, dtype=clip_max.dtype, device=clip_max.device)
            clip_max_l = list(clip_max_all.unbind(0))
            clip_max_all_reduce = torch.distributed.all_gather(
                clip_max_l, clip_max, process_group, async_op=True)

            # wait on the async communication to finish
            clip_max_all_reduce.wait()
            clip_max_tmp = clip_max_all.mean()
            clip_max.data.copy_(clip_max_tmp.data)

        ctx.save_for_backward(fakequant_input, clip_max,
            torch.tensor(num_bits), is_symmetric)
        return fakequant_input, scale, offset

    @staticmethod
    def backward(ctx, input_grad, grad_scale, grad_offset):
        fakequant_input, clip_max, num_bits, is_symmetric = ctx.saved_tensors
        output_grad, clip_max_grad = amct_pytorch_ops.luq_retrain_backward(
            input_grad, fakequant_input, clip_max, num_bits, is_symmetric)
        output_gradient = (output_grad, clip_max_grad, \
            None, None, None)
        return output_gradient