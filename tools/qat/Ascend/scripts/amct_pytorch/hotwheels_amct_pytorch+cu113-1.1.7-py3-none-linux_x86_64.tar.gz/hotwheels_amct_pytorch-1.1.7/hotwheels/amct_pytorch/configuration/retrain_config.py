#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Create quantize config file and parse config file.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import copy
from pathlib import Path

from hotwheels.amct_pytorch.graph.graph import Graph
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.configuration.check import GraphChecker
from hotwheels.amct_pytorch.configuration.check import GraphQuerier
from hotwheels.amct_pytorch.common.utils.check_params import check_params
from hotwheels.amct_pytorch.common.retrain_config.retrain_config_base import \
    RetrainConfigBase
from hotwheels.amct_pytorch.common.config.config_base import GraphObjects

from hotwheels.amct_pytorch.capacity import CAPACITY
from hotwheels.amct_pytorch.utils.vars import RETRAIN_ENABLE

CLIBRATION_BIT = 8

CONFIGURER = RetrainConfigBase(
    GraphObjects(graph_querier=GraphQuerier, graph_checker=GraphChecker), CAPACITY
)


class RetrainConfig():
    """
    Function: manage configuration of project including quant_config
              and record_file.
    APIs: init, get_quant_config, get_layer_config, get_record_file_path;
        create_quant_config, parse_quant_config
    """
    __instance = None
    __initialized = False
    __record_file_path = None
    __record_file_name_update = False
    __inserted_depthwise_layers = list()

    def __new__(cls, *args, **kw):
        if cls.__instance is None:
            cls.__instance = object.__new__(cls, *args, **kw)
        return cls.__instance

    def __init__(self):
        super(RetrainConfig, self).__init__()
        if not RetrainConfig.__initialized:
            raise RuntimeError(
                "Classmethod RetrainConfig.init() should be called firstly.")
        self.__skip_fusion_layers = list()

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def parse_retrain_config(file_name, graph):
        """parse quantize configuration from config json file"""
        GraphChecker.check_quant_behaviours(graph)
        quant_config = CONFIGURER.parse_config_file(file_name, graph)
        return quant_config

    @staticmethod
    @check_params(config_name=str, graph=Graph, config_defination=(str))
    def create_quant_retrain_config(config_name, graph, config_defination):
        """
        Function: Create retrain config.
        Inputs:
            config_name: a string, the file(including path information) to
                save retrain config.
            graph: IR Graph, the graph to be retrainized.
            config_defination: the file containing the simple retrain config
                according to proto.
        Returns: None
        """
        config_name = os.path.realpath(config_name)
        config_file = os.path.realpath(config_defination)

        LOGGER.logi(
            "Create %s according to %s, other configuration will be ignored."
            % (config_name, config_file), module_name='RetrainConfig')

        CONFIGURER.create_config_from_proto(config_name, graph, config_file)

        LOGGER.logi(
            "Create quant config success!", module_name='RetrainConfig')

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def create_default_retrain_config(file_name, graph):
        """create deafult config"""

        CONFIGURER.create_default_config(
            file_name,
            graph)
        LOGGER.logd("Create retrain config by file success!",
                    module_name='RetrainConfig')

    @classmethod
    def un_init(cls):
        """uninitialize class"""
        cls.__initialized = False

    @classmethod
    @check_params(config_file=str, record_file=str, graph=Graph)
    def init_retrain(cls, config_file, record_file, graph):
        """
        Function: init the RetrainConfig.
        Inputs:
            config_file: a string, the file containing the quant config.
            record_file: a string, the file storing scale and offset.
            graph: IR Graph
        Returns: None
        """
        cls.__retrain_config = cls.parse_retrain_config(
            os.path.realpath(config_file), graph)
        RetrainConfig.__initialized = True
        RetrainConfig.__record_file_path = os.path.realpath(record_file)

    def get_retrain_config(self, layer):
        """get retrain config"""
        return self.__retrain_config[layer]

    def quant_enable(self, layer):
        """if retrain enable"""
        if layer not in self.__retrain_config.keys():
            return False
        return self.__retrain_config[layer][RETRAIN_ENABLE]

    def get_layer_config(self, layer_name):
        """get retrain layer config"""
        if not self.__initialized:
            raise RuntimeError('Must init RetrainConfig before access it.')
        return self.__retrain_config.get(layer_name)

    def get_quant_config(self):
        """get retrain config"""
        config = copy.deepcopy(self.__retrain_config)
        return config

    def get_skip_fusion_layers(self):
        """Get layers that need to skip do fusion"""
        return self.__skip_fusion_layers

    def update_quant_config(self, retrain_config):
        """Update member quant_config to new input quant_config"""
        if not self.__initialized:
            raise RuntimeError('Must init RetrainConfig before access it.')
        self.__retrain_config = retrain_config

    def add_depthwise_layer(self, depthwise_layer):
        """add depthwise conv layer to layer list"""
        self.__inserted_depthwise_layers.append(depthwise_layer)

    def get_inserted_depthwise_layers(self):
        """get inserted_depthwise_layers list"""
        return self.__inserted_depthwise_layers

    def get_record_file_path(self):
        """ get record_file_path. """
        return self.__record_file_path

    def update_record_file(self, update_record_file):
        """Update record file path
        """
        if not self.__initialized:
            raise RuntimeError('Must init RetrainConfig before access it.')
        new_record_file_path = os.path.realpath(update_record_file)
        if not Path(new_record_file_path).exists():
            raise RuntimeError('Cannot find new record file:{}'.format(
                new_record_file_path))
        self.__record_file_name_update = True
        self.__record_file_path = new_record_file_path

    def is_record_file_name_update(self):
        """return wether record file name has been updated in RetrainConfig"""
        if not self.__initialized:
            raise RuntimeError('Must init RetrainConfig before access it.')
        return self.__record_file_name_update
