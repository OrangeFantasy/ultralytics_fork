#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

CaliQuantMultiInput module and Function

"""

from hotwheels.amct_pytorch.custom_op.cali_quant.cali_quant import \
    CaliQuantBase


class CaliQuantMultiInput(CaliQuantBase):
    """
    Function: Customized torch.nn.Module of the multi input calibration 
        operator.
    APIs: forward
    """
    def __init__(self,
                layer_name,
                sub_module,
                act_config):
        super(CaliQuantMultiInput, self).__init__(layer_name,
                sub_module,
                act_config)

    def cali_quant(self, *inputs):
        for index, input_item in enumerate(inputs):
            if type(input_item).__name__ != 'Tensor':
                continue
            ifmr_param = self.ifmr_param[index]
            self.cali_quant_common(input_item, index, ifmr_param)

        return self.sub_module(*inputs)

    def forward_without_cali(self, *inputs):
        return self.sub_module(*inputs)


