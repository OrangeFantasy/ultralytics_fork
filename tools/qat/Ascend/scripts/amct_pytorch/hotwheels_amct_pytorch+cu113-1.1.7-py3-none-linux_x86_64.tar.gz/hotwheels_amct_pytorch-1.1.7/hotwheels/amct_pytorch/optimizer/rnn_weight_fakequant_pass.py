#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quant weight from int8 to float32.

"""
import numpy as np
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from hotwheels.amct_pytorch.optimizer.weight_quant_pass import WeightQuantPass
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.utils.rnn_utils import get_rnn_helper


class RNNWeightFakeQuantPass(WeightQuantPass):
    """
    Function: Quant weight from int8 to float32
    APIs: match_pattern, do_pass, quant_weight
    """

    def __init__(self, records, is_retrain=False):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        WeightQuantPass.__init__(self, records, is_retrain)

    def match_pattern(self, node):
        """
        Function: Match the node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.name not in self.records:
            return False
        if node.type not in RNN_ONNX_TYPES:
            return False
        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual lstm quantization and node's weight is changed to float32.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the graph will be modified.
        Return: None
        """
        # get weight quantization information
        x_weight_param, h_weight_param, _ = \
            QuantOpInfo.get_rnn_weight_node(object_node)
        rnn_helper = get_rnn_helper(object_node)
        fc_num = rnn_helper.weights_count()

        x_weight_helper = TensorProtoHelper(x_weight_param.proto)
        h_weight_helper = TensorProtoHelper(h_weight_param.proto)

        x_weight = x_weight_helper.get_data().astype(np.float32)
        h_weight = h_weight_helper.get_data().astype(np.float32)
        
        scale_w = self.records.get(object_node.name).get('weight_scale')
        offset_w = self.records.get(object_node.name).get('weight_offset')

        x_weight_shape = x_weight.shape
        x_weight = x_weight.reshape(fc_num, 1, -1, x_weight_shape[-1])

        h_weight_shape = h_weight.shape
        h_weight = h_weight.reshape(fc_num, 1, -1, h_weight_shape[-1])

        x_scale_w = scale_w[:fc_num]
        x_offset_w = offset_w[:fc_num]
        h_scale_w = scale_w[fc_num:]
        h_offset_w = offset_w[fc_num:]

        float32_x_weight = self.weight_dequant(x_weight, object_node, x_scale_w, x_offset_w)
        float32_x_weight = float32_x_weight.reshape([-1])
        x_weight_helper.clear_data()
        x_weight_helper.set_data(float32_x_weight, 'FLOAT')

        float32_h_weight = self.weight_dequant(h_weight, object_node, h_scale_w, h_offset_w)
        float32_h_weight = float32_h_weight.reshape([-1])
        h_weight_helper.clear_data() 
        h_weight_helper.set_data(float32_h_weight, 'FLOAT')

        LOGGER.logd("Quant weight from int8 to float32 for layer '{}' "
                    "success!".format(object_node.name), 'RNNWeightQuantPass')
        
    def weight_dequant(self, weight, object_node, scale_w, offset_w):
        return (weight - offset_w) / scale_w
