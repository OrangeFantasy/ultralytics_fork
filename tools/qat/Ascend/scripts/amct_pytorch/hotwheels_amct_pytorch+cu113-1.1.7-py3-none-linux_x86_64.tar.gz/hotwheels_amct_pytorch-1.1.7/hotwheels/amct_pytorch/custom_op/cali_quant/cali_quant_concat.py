#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

CaliQuantConcat module and Function

"""

from hotwheels.amct_pytorch.custom_op.cali_quant.cali_quant import \
    CaliQuantBase


class CaliQuantConcat(CaliQuantBase):
    """
    Function: Customized torch.nn.Module of the concat calibration operator.
    APIs: forward
    """
    def __init__(self,
                layer_name,
                sub_module,
                act_config):
        super(CaliQuantConcat, self).__init__(
            layer_name,
            sub_module,
            act_config)
        self.ifmr_after_concat_list = None

    def set_ifmr_after_concat_list(self, ifmr_after_concat_list):
        self.ifmr_after_concat_list = ifmr_after_concat_list

    def cali_quant(self, *inputs):
        output = self.sub_module(*inputs)
        for index, input_item in enumerate(inputs):
            if type(input_item).__name__ != 'Tensor':
                continue
            ifmr_param = self.ifmr_param[index]
            if not self.ifmr_after_concat_list[index]:
                self.cali_quant_common(input_item, index, ifmr_param)
            else:
                self.cali_quant_common(output, index, ifmr_param)
        return output
    
    def forward_without_cali(self, *inputs):
        return self.sub_module(*inputs)

