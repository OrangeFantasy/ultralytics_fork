#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Base Module of activation retrain

"""

import torch
import torch.nn as nn
from hotwheels.amct_pytorch.custom_op.utils import tensor
import numpy as np


class ActRetrainModuleBase(nn.Module):
    """
    Function: Base class module for quantized retrain.
    APIs: __init__, get_data_scale, get_data_offset
    """

    def __init__(self, module,
                 act_config=None,
                 common_config=None):
        super(ActRetrainModuleBase, self).__init__()
        self.replaced_module = module
        self.act_config = act_config
        self.common_config = common_config
        self._init_output()

    def get_data_scale(self):
        if self._check_zero():
            raise ValueError("acts_scale of act retrain is zero")
        return 1.0 / self.acts_scale

    def get_data_offset(self):
        return self.acts_offset

    def _init_output(self):
        self.register_buffer('acts_scale', tensor(np.nan))
        self.register_buffer('acts_offset', tensor(np.nan))

    def _check_zero(self):
        return torch.isclose(self.acts_scale, torch.zeros_like(self.acts_scale)).all()