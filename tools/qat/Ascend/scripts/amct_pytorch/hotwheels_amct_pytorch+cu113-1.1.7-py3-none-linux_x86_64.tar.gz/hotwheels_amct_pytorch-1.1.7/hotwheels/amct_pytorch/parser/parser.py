#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Parse to save and parse onnx graph

"""

import os
from io import BytesIO
import pathlib
import torch

from onnx import onnx_pb
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.graph.graph import Graph
from hotwheels.amct_pytorch.configuration.check import GraphChecker
from hotwheels.amct_pytorch.common.utils import files as files_util
from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.custom_op.quant_identity.quant_identity import \
    MarkedQuantizableModule
from hotwheels.amct_pytorch.custom_op.quant_identity.quant_identity import \
    LSTMMarkedQuantizableModule
from hotwheels.amct_pytorch.utils.vars import TORCH_VERSION
from hotwheels.amct_pytorch.utils.vars import OP_SET_VERSION
from torch.onnx import TrainingMode

SUPPORT_TYPES = tuple([torch.nn.BatchNorm2d, torch.nn.ReLU6, torch.nn.PReLU])


class Parser:
    """ Helper of onnx file
    """
    def __init__(self, ckpt_path):
        self.__ckpt_path = ckpt_path

    @staticmethod
    def parse_proto(proto_file):
        """ parse the onnx pb pb file to """
        if isinstance(proto_file, str):
            with open(proto_file, 'rb') as onnx_pb_file:
                onnx_pb_str = onnx_pb_file.read()
                model = onnx_pb.ModelProto()
                model.ParseFromString(onnx_pb_str)
                LOGGER.logd('Parse onnx model from %s success.' % (proto_file))
                return model
        elif isinstance(proto_file, BytesIO):
            onnx_pb_str = proto_file.getvalue()
            model = onnx_pb.ModelProto()
            model.ParseFromString(onnx_pb_str)
            LOGGER.logd('Parse onnx model from %s success.' % (proto_file))
            return model
        else:
            raise TypeError('Unsupport proto type: "%s"' % (type(proto_file)))

    @staticmethod
    def parse_net_to_graph(proto_file):
        """" parse the onnx pb graph to inner graph,
        """
        if isinstance(proto_file, str):
            proto_file_path = pathlib.Path(proto_file)
            # parse by proto
            if not proto_file_path.is_file():
                raise ValueError('The input onnx pb file is not exist.')
        model = Parser.parse_proto(proto_file)
        graph = Graph(model)
        return graph

    @staticmethod
    def export_onnx(model,
                    args,
                    onnx_file,
                    export_setting=None):
        """
        Function: Save nn.module to onnx
        Inputs: model: an instance of torch.nn.Module
                args: tuple, the input data.
                onnx_file: a string, file path to save onnx file
                export_setting: a dict, some args for torch.onnx.export
        Returns: torch_out: model's output from args
        """
        if isinstance(onnx_file, str):
            files_util.create_file_path(onnx_file)

        if export_setting is None:
            export_setting = dict()
        export_setting['opset_version'] = OP_SET_VERSION

        if model.training:
            export_setting['training'] = TrainingMode.TRAINING

        if TORCH_VERSION == '1.8.1':
            export_setting['enable_onnx_checker'] = False

        try:
            model = ModuleHelper.deep_copy(model)
        except RuntimeError as exception:
            LOGGER.logw(exception, "Parser::export_onnx")

        # add quantize mark op to user model
        model_helper = ModuleHelper(model)
        # check and add warning if op would be split during onnx exporting
        model_helper.check_op_split()
        for name, mod in model.named_modules():
            if isinstance(mod, SUPPORT_TYPES) or \
                    GraphChecker.check_quantize_type(name, mod) or \
                    GraphChecker.check_quantizable_type_without_weight(\
                        name, mod):
                parent_module = model_helper.get_parent_module(name)
                if type(mod).__name__ == 'LSTM':
                    marked_module = LSTMMarkedQuantizableModule(mod, name)
                else:
                    marked_module = MarkedQuantizableModule(mod, name)
                setattr(parent_module, name.split('.')[-1], marked_module)
        model.to('cpu')
        # enable input_data processed by CPU
        args = Parser.recursive_to_cpu(args)
        try:
            torch_out = torch.onnx.export(
                model, args, onnx_file, **export_setting)
        except Exception as e:
            raise RuntimeError('Model cannot be quantized for it cannnot be '
                               'export to onnx!') from e

        # remove quantize mark op to user model
        model_helper = ModuleHelper(model)
        for name, mod in model.named_modules():
            if isinstance(mod, MarkedQuantizableModule) or \
                isinstance(mod, LSTMMarkedQuantizableModule):
                parent_module = model_helper.get_parent_module(name)
                original_module = mod.sub_module
                setattr(parent_module, name.split('.')[-1], original_module)

        # set file's permission 640
        if isinstance(onnx_file, str):
            os.chmod(onnx_file, files_util.FILE_MODE)

        return torch_out

    @staticmethod
    # Reason of trans: avoid too much GPU memory consumed when export onnx
    def recursive_to_cpu(input_data):
        if isinstance(input_data, tuple):
            tmp = []
            for data in input_data:
                tmp.append(Parser.recursive_to_cpu(data))
            return tuple(tmp)
        elif isinstance(input_data, list):
            lst = []
            for data in input_data:
                lst.append(Parser.recursive_to_cpu(data))
            return lst
        elif isinstance(input_data, torch.Tensor):
            return input_data.to('cpu')
        elif isinstance(input_data, dict):
            for key in input_data.keys():
                input_data[key] = Parser.recursive_to_cpu(input_data[key])
            return input_data
        return input_data

