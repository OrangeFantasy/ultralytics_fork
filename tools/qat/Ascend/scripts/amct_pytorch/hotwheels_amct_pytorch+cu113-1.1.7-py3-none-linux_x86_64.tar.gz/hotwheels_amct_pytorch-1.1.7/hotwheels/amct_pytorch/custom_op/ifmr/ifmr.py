#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

IFMR module and Function

"""

from torch import nn
import torch

from hotwheels.amct_pytorch.custom_op.amct_pytorch_ops import \
    ifmr_forward
from hotwheels.amct_pytorch.custom_op.utils import check_quant_data
from hotwheels.amct_pytorch.utils.log import LOGGER


class IFMR(nn.Module):
    """
    Function: Run calibration process for quantization of the given layer.
    APIs: forward
    """
    def __init__(self,
                 layers_name,
                 num_bits=8,
                 batch_num=2,
                 with_offset=False,
                 max_percentile=0.999999,
                 min_percentile=0.999999,
                 search_start=0.7,
                 search_end=1.3,
                 search_step=0.01):
        super().__init__()
        self.param = dict()
        self.param['num_bits'] = num_bits
        self.param['batch_num'] = batch_num
        self.param['with_offset'] = with_offset
        self.param['max_percentile'] = max_percentile
        self.param['min_percentile'] = min_percentile
        self.param['search_start'] = search_start
        self.param['search_end'] = search_end
        self.param['search_step'] = search_step
        self.layers_name = layers_name

        self.ifmr_data = None
        self.cur_batch = 0

    def forward(self, inputs): # pylint: disable=W0221
        """
        Function: IFMR foward funtion.
        """
        self.cur_batch += 1
        self._accm_data(inputs)

        ifmr_param = self.param
        do_calibration = (self.cur_batch == ifmr_param.get('batch_num'))
        if not do_calibration:
            scale = torch.tensor(1.0)
            offset = torch.tensor(0)
            return scale, offset

        if inputs.is_cuda:
            device_id = inputs.device.index
        else:
            device_id = -1

        if ifmr_param['num_bits'] == -1:
            retrun_code = torch.tensor(0)
            scale = torch.tensor(1.0)
            offset = torch.tensor(0)
        else:
            retrun_code, scale, offset = ifmr_forward(self.ifmr_data,
                                           device_id,
                                           ifmr_param.get('num_bits'),
                                           inputs.is_cuda,
                                           ifmr_param.get('with_offset'),
                                           ifmr_param.get('max_percentile'),
                                           ifmr_param.get('min_percentile'),
                                           ifmr_param.get('search_start'),
                                           ifmr_param.get('search_end'),
                                           ifmr_param.get('search_step'))
        del self.ifmr_data
        self.ifmr_data = None
        if retrun_code.item() == 0:
            LOGGER.logi("Do layer {} data calibration succeeded!".format(self.layers_name), 'IFMR')
        else:
            LOGGER.loge("Do layer {} data calibration failed!".format(self.layers_name), 'IFMR')
            raise RuntimeError("Do layer {} data calibration failed!".format(self.layers_name), 'IFMR')

        if torch.isclose(scale, torch.zeros_like(scale)).all():
            raise ValueError("scale of layer name %s should not be closed to zero" % self.layers_name)

        return 1.0 / scale, offset

    def _accm_data(self, inputs):
        """ Accumulate data for ifmr and search"""
        if self.cur_batch > self.param.get('batch_num'):
            return

        # check and accumelate data
        check_quant_data(inputs, 'activation')

        if self.ifmr_data is None:
            self.ifmr_data = inputs.cpu().reshape([-1])
        else:
            self.ifmr_data = torch.cat([self.ifmr_data, # pylint: disable=E1101
                                        inputs.cpu().reshape([-1])])
        LOGGER.logi(
            "Doing layer {} data calibration: data already stored {}/{}"
            .format(self.layers_name, self.cur_batch, self.param.get('batch_num')),
            'IFMR')
