#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of graph IR

"""
from hotwheels.amct_pytorch.utils.log import LOGGER  # pylint: disable=E0402


class GraphBase():
    """
    Function: Data structure of graph IR
    APIs: init_graph, nodes, topologic_sort, add_edge, remove_edge,
          add_node, add_data_node, remove_node, get_node, dump_proto,
          deep_copy
    """

    def __init__(self, net):  # pylint: disable=W0613
        """
        Function: init object
        Parameter: None
        Return: None
        """
        self._data_nodes = list()
        self._nodes = list()
        self._node_ids = list()
        self._tail_index = 0

    @property
    def nodes(self):
        """
        Function: Get all nodes in graph
        Parameter: None
        Return: nodes in graph
        """
        return self._nodes

    @property
    def node_ids(self):
        """
        Function: Get all node_ids in graph
        Parameter: None
        Return: node_ids in graph
        """
        return self._node_ids

    @property
    def _tail(self):
        current_index = self._tail_index
        self._tail_index += 1
        return current_index

    def get_node(self, node_index):
        """
        Function: Get specific node in graph by index
        Parameter: None
        Return: node in graph
        """
        object_node = None
        for node in self._nodes:
            if node.index == node_index:
                object_node = node
                break
        if object_node is None:
            raise RuntimeError("Cannot find node {} in "
                               "graph".format(node_index))
        return object_node

    def get_node_by_name(self, node_name):
        """
        Function: Get specific node in graph by index
        Parameter: None
        Return: node in graph
        """
        object_node = None
        for node in self._nodes + self._data_nodes:
            if node.name == node_name:
                object_node = node
                break
        if object_node is None:
            raise RuntimeError('Cannot find node "{}" in '
                               'graph'.format(node_name))
        return object_node

    def topologic_sort(self):
        """
        Function: Do whole grpah topologic sort
        Parameter: None
        Return: None
        """
        # Step1: record all zero indegree node as sorted
        sorted_nodes_index = set()
        sorted_indexes = set()
        sorted_nodes = list()
        sorted_node_ids = list()
        self._record_zero_indegree_nodes(sorted_nodes_index, sorted_indexes,
                                         sorted_nodes, sorted_node_ids)
        # Step2: record nodes that all input peer_node is in sorted_nodes_index
        record_sorted_num = len(sorted_nodes_index)
        whole_set = set(range(len(self._nodes)))
        while len(sorted_nodes_index) < len(self._nodes):
            for index in whole_set - sorted_indexes:
                node = self._nodes[index]
                if node.index not in sorted_nodes_index:
                    all_input_ready = True
                    for input_anchor in node.input_anchors:
                        producer = input_anchor.get_peer_output_anchor()
                        if producer is None or producer.node.is_data_node:
                            continue
                        if producer.node.index not in sorted_nodes_index:
                            all_input_ready = False
                            break
                    if all_input_ready:
                        sorted_nodes_index.add(node.index)
                        sorted_indexes.add(index)
                        sorted_nodes.append(node)
                        sorted_node_ids.append(node.name)
                        break
            if record_sorted_num == len(sorted_nodes_index):
                raise RuntimeError('May exist loop in graph, topological '
                                   'sort failed!')

            record_sorted_num = len(sorted_nodes_index)

        self._nodes = sorted_nodes
        self._node_ids = sorted_node_ids
        self._renumber_node_index()

    def add_edge(self, src_node, src_index, dst_node, dst_index):
        """
        Function: Add edge from src_node[src_index] to dst_node[dst_index]
        Parameter: None
        Return: None
        """
        # Prepare src anchor info
        src_anchor = self._prepare_src_anchor(src_node, src_index)
        # Prepare dst anchor info
        dst_anchor = self._prepare_dst_anchor(dst_node, dst_index)

        if dst_anchor.get_peer_output_anchor() is not None:
            raise RuntimeError("Node:{} input:{} already has peer output "
                               "anchor, disconnect it first".format(dst_node.name, dst_index))
        # add link between src_anchor and dst_anchor
        src_anchor.add_link(dst_anchor)
        dst_anchor.add_link(src_anchor)
        LOGGER.logd("Add edge from {}[{}] to {}[{}] success!".format(
            src_node.name, src_index, dst_node.name, dst_index), 'Graph')

    def remove_edge(self, src_node, src_index, dst_node, dst_index):
        """
        Function: Remove edge from src_node[src_index] to dst_node[dst_index]
        Parameter: None
        Return: None
        """
        # Prepare src anchor info
        src_anchor = self._prepare_src_anchor(src_node, src_index)
        if not src_anchor.get_peer_input_anchor():
            raise RuntimeError("Src node {} output {} have no peer input "
                               "anchor".format(src_node.name, src_index))
        # Prepare dst anchor
        dst_anchor = self._prepare_dst_anchor(dst_node, dst_index)
        if dst_anchor.get_peer_output_anchor() is None:
            raise RuntimeError("Node:{} input:{} have no peer output "
                               "anchor".format(dst_node.name, dst_index))
        # Disconnct link between src anchor and dst anchor
        if src_anchor is not dst_anchor.get_peer_output_anchor() or \
                dst_anchor not in src_anchor.get_peer_input_anchor():
            raise RuntimeError('There is no link from {}[{}] to {}[{}]'.format(
                src_node.name, src_index, dst_node.name, dst_index))
        src_anchor.del_link(dst_anchor)
        dst_anchor.del_link()
        LOGGER.logd("Remove edge from {}[{}] to {}[{}] success!".format(
            src_node.name, src_index, dst_node.name, dst_index), 'Graph')

    def _record_zero_indegree_nodes(self, sorted_nodes_index, sorted_indexes,
                                    sorted_nodes, sorted_node_ids):
        """
        Function: Record all zero indegree nodes in graph
        Parameter: None
        Return: List of zero indegree nodes' index
        """
        for index, node in enumerate(self._nodes):
            # Check if node's all input is come from 'input' of net
            all_input_ready = True
            for input_anchor in node.input_anchors:
                if input_anchor.get_peer_output_anchor() is None:
                    continue
                peer_node = input_anchor.get_peer_output_anchor().node
                if not peer_node.is_data_node:
                    all_input_ready = False
                    break
            if all_input_ready:
                sorted_nodes_index.add(node.index)
                sorted_indexes.add(index)
                sorted_nodes.append(node)
                sorted_node_ids.append(node.name)
        return sorted_nodes_index, sorted_indexes

    def _prepare_src_anchor(self, src_node, src_index):
        """
        Function: Find src anchor according to src_node name and index
        Parameter: None
        Return: Src output anchor
        """
        if src_node not in self._nodes:
            raise RuntimeError('Cannot find node "%s" in graph.' % (
                src_node.name))
        if src_index >= len(src_node.output_anchors):
            raise RuntimeError("Get output of {} from node:{} out of "
                               "range".format(src_index, src_node))

        return src_node.get_output_anchor(src_index)

    def _prepare_dst_anchor(self, dst_node, dst_index):
        """
        Function: Find dst anchor according to dst_node name and index
        Parameter: None
        Return: Dst input anchor
        """
        if dst_node not in self._nodes:
            raise RuntimeError('Cannot find node "%s" in graph.' % (
                dst_node.name))
        if dst_index >= len(dst_node.input_anchors):
            raise RuntimeError("Get input of {} from node:{} out of " \
                               "range".format(dst_index, dst_node))
        return dst_node.get_input_anchor(dst_index)

    def _renumber_node_index(self):
        """
        Function: Renumber index of nodes
        Parameter: None
        Return: None
        """
        for index, node in enumerate(self._nodes):
            node.set_index(index)
        self._tail_index = len(self._nodes)

    def _decorate_node_name(self, node_name):
        """decorate node_name to generate unique node_id"""
        node_id = node_name
        dec_index = 1
        while node_id in self._node_ids:
            node_id = '{}{}'.format(node_name, dec_index)
            dec_index += 1
        self._node_ids.append(node_id)
        return node_id
