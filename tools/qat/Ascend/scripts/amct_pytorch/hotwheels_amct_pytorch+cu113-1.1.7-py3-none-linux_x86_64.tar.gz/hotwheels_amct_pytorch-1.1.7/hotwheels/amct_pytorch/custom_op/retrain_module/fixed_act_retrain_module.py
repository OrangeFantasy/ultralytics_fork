#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

fixed quant param module

"""

import numpy as np
import torch
from hotwheels.amct_pytorch.custom_op.utils import copy_tensor
from hotwheels.amct_pytorch.custom_op.utils import tensor
from hotwheels.amct_pytorch.custom_op.retrain_module.act_retrain_module_base \
    import ActRetrainModuleBase


class FixedActRetrainModule(ActRetrainModuleBase):
    """
    Function: fixed quant param activation retrain module.
    APIs: __init__, _init_output, acts_forward, get_data_scale, get_data_offset
    """
    def __init__(self, *args, **kwargs):
        super(FixedActRetrainModule, self).__init__(*args, **kwargs)

    def acts_forward(self, inputs):
        """
        Function: activation quantization function.
        Inputs: inputs: data used for calibration in torch.tensor.
        """
        # Forward with fake-quantized activations.
        act_config = self.act_config
        scale = torch.tensor(act_config['scale_d'], device=inputs.device)
        offset = torch.tensor(act_config['offset_d'], device=inputs.device)
        with torch.no_grad():
            copy_tensor(self.acts_scale, scale)
            copy_tensor(self.acts_offset, offset)
        clip_min = torch.tensor(-pow(2, act_config['num_bits'] - 1),
                                device=inputs.device)
        clip_max = torch.tensor(pow(2, act_config['num_bits'] - 1) - 1,
                                device=inputs.device)
        if torch.isclose(scale, torch.zeros_like(scale)).all():
            raise ValueError("scale of fixed act retrain is zero")
        quant_inputs = (torch.clamp(torch.round(inputs * scale) + offset,
            clip_min, clip_max) - offset) / scale
        return quant_inputs
    
    def get_data_scale(self):
        return self.acts_scale

    def get_data_offset(self):
        return self.acts_offset

    def _init_output(self):
        # Register quantitative parameters.
        self.register_buffer('acts_scale', tensor(np.nan))
        self.register_buffer('acts_offset', tensor(np.nan))
