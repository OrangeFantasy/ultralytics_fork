#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace AscendQuant to fakeqaunt 'Quant' with onnx's ops.

"""
from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.module.quant_module import add_fakequant

from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.attrs_list import ATTR_NODE_EQUIVALENT_INPUT

from hotwheels.amct_pytorch.common.utils.record_file_operator import ActivationQuantParam


class ReplaceQuantPass(BaseFusionPass):
    """
    Function: Replace AscendQuant to fakeqaunt 'Quant' with onnx's ops
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    @staticmethod
    def _generate_fake_quant_nodes(graph, object_node):
        """Generate fake Quant nodes"""
        quantized_layer_name = object_node.name
        attr_helper = AttributeProtoHelper(object_node.proto)
        quant_param = ActivationQuantParam(scale=attr_helper.get_attr_value('scale'),
                                           offset=attr_helper.get_attr_value('offset'),
                                           index=None,
                                           num_bits=attr_helper.get_attr_value('quant_bit'))
        mul_node, sub_node = add_fakequant(
            graph,
            quantized_layer_name,
            quant_param,
            object_node)
        return quantized_layer_name, mul_node, sub_node

    def match_pattern(self, node):
        """
        Function: Match the AscendQuant node
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'AscendQuant':
            return False

        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actually replacing AscendQuant to fakeqaunt 'Quant'
            with onnx's ops
        Parameters: graph: graph structure
                    object_node: node to process
                    model: torch.nn.Module, the model to be modified. if it's
                        None, the gaph will be modified.
        Return: None
        """
        ori_object_name = object_node.get_attr('object_node')
        # Step1: add a new_node
        quantized_layer_name, mul_node, sub_node = \
            self._generate_fake_quant_nodes(graph, object_node)

        ori_object_node = graph.get_node_by_name(ori_object_name)
        ori_object_node.set_attr(ATTR_NODE_EQUIVALENT_INPUT, mul_node.name)

        # Step2: Relink nodes in th graph
        # remove input links
        input_anchor = object_node.get_input_anchor(0)
        peer_output_anchor = input_anchor.get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        peer_output_anchor_index = peer_output_anchor.index
        graph.remove_edge(peer_node, peer_output_anchor_index, object_node, 0)
        graph.add_edge(peer_node, peer_output_anchor_index, mul_node, 0)
        # remove output links
        output_anchor = object_node.get_output_anchor(0)

        peer_input_anchors = list()
        for input_anchor in output_anchor.get_peer_input_anchor():
            peer_input_anchors.append(input_anchor)

        for input_anchor in peer_input_anchors:
            peer_input_node = input_anchor.node
            input_index = input_anchor.index
            graph.remove_edge(object_node, 0, peer_input_node, input_index)
            graph.add_edge(sub_node, 0, peer_input_node, input_index)

        graph.remove_node(object_node)

        LOGGER.logd(
            "Replace quant layer '{}' to fake quant layer '{}' success!".
            format(object_node.name,
                   quantized_layer_name + '.fakequant'), 'ReplaceQuantPass')
