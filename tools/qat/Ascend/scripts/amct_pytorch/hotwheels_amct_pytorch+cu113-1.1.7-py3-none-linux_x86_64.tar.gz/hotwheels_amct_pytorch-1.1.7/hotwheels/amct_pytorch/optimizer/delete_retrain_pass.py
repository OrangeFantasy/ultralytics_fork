#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Delete some mudule about retrain quantization.

"""
import torch
from hotwheels.amct_pytorch.optimizer.base_module_fusion_pass \
    import BaseModuleFusionPass

from hotwheels.amct_pytorch.utils.model_util import ModuleHelper
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.vars import NO_WEIGHT_RETRAIN_MODULE_TYPES
from hotwheels.amct_pytorch.utils.vars import RETRAIN_MODULE_TYPES
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from hotwheels.amct_pytorch.proto import scale_offset_record_pb2
from hotwheels.amct_pytorch.custom_op.utils import check_scale_offset
from hotwheels.amct_pytorch.custom_op.utils import check_record_params
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    record_activation_scale_offset
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    record_weights_scale_offset
from google.protobuf import text_format 
from hotwheels.amct_pytorch.common.utils import files as files_util
from hotwheels.amct_pytorch.custom_op.lnq_retrain.lnq_retrain import \
    lnq_fake_quant

from hotwheels.amct_pytorch.common.utils.record_file_operator import WeightQuantParam, ActivationQuantParam


class DeleteRetrainPass(BaseModuleFusionPass):
    """
    Function: Delete some mudule about retrain quantization
    APIs: match_pattern, do_pass
    """

    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseModuleFusionPass.__init__(self)
        self.conf = RetrainConfig()
        self.record_file_path = self.conf.get_record_file_path()
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()

    @staticmethod
    def get_conv_data_quant_module(module):
        if module.acts_comp_reuse:
            return [module.acts_comp_reuse]
        else:
            return [module]

    @staticmethod
    def get_no_weight_quant_module(module, num_of_input, model_helper):
        activation_retrain_module = []
        for i in range(num_of_input):
            retrain_module = getattr(module, 'retrain_module%d' % i)
            if retrain_module.acts_comp_reuse:
                activation_retrain_module.append(retrain_module.acts_comp_reuse)
            else:
                activation_retrain_module.append(retrain_module)
        return activation_retrain_module

    @staticmethod
    def get_data_quant_module(module, num_of_input, model_helper):
        if type(module).__name__ in RETRAIN_MODULE_TYPES:
            return DeleteRetrainPass.get_conv_data_quant_module(module)
        else:
            return DeleteRetrainPass.get_no_weight_quant_module(
                module, num_of_input, model_helper)

    @staticmethod
    def get_weight_quant_module(module):
        if type(module).__name__ in RETRAIN_MODULE_TYPES:
            weight_retrain_module = module
        else:
            weight_retrain_module = None
        return weight_retrain_module

    @staticmethod
    def trans_weight_distibute(wts_config, weight_retrain_module,
        replaced_module):
        if wts_config is not None and wts_config['algo'] == 'lnq_retrain':
            num_bits = wts_config['num_bits']
            weight_clip_max = weight_retrain_module.wts_module.wts_clip_max
            centroids = weight_retrain_module.wts_module.centroids
            fakequant_weight = lnq_fake_quant(replaced_module.weight,
                weight_clip_max, num_bits, centroids)
            replaced_module.weight.data.copy_(fakequant_weight.data)
        return replaced_module

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        self.record_file_path = files_util.create_empty_file(
            self.record_file_path)
        with open(self.record_file_path, "w") as record_write_file:
            record_write_file.write(text_format.MessageToString(
                self.records, as_utf8=True))

    def match_pattern(self, module, name, graph=None):
        """
        Function:Match the module quantized in model.
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure, not necessary
        Return: True: matched
                False: mismatch
        """
        if type(module).__name__ not in (RETRAIN_MODULE_TYPES +
            NO_WEIGHT_RETRAIN_MODULE_TYPES):
            return False
        return True

    def record_data_quant_params(self, activation_retrain_module,
        object_module, object_name, num_of_input):
        """
        Function: Record activation quant param from activation retrain module.
        Parameters: activation_retrain_module: retrain module
                    object_module: module to process
                    layer_name: name of current layer
                    num_of_input: input number of current layer
        Return: None
        """
        common_config = object_module.common_config
        act_config = object_module.act_config
        scale_d = None
        offset_d = None 
        for i in range(num_of_input):
            if i == common_config['skip_quant_index']:
                continue
            if activation_retrain_module[i] is None:
                continue
            if activation_retrain_module[i].skip_quant:
                continue
            scale_d = activation_retrain_module[i].act_module.get_data_scale()
            offset_d = activation_retrain_module[i].act_module.get_data_offset()
            num_bits = \
                activation_retrain_module[i].act_module.act_config['num_bits']
            if num_bits == -1:
                scale_d = torch.tensor(1.0)
                offset_d = torch.tensor(0)
            check_scale_offset(scale_d, offset_d)
            scale_d = scale_d.cpu().tolist()
            offset_d = offset_d.cpu().int().tolist()
            activation_quant_param = ActivationQuantParam(scale=scale_d, offset=offset_d, index=i,
                                                          num_bits=num_bits)
            record_activation_scale_offset(self.records, object_name, activation_quant_param)

    def record_weight_quant_params(self, weight_retrain_module, object_module,
        layer_name):
        """
        Function: Record weight quant param from weight retrain module.
        Parameters: weight_retrain_module: retrain module
                    object_module: module to process
                    layer_name: name of current layer
        Return: None
        """
        wts_config = object_module.wts_config
        scale_w = weight_retrain_module.wts_module.get_weight_scale()
        offset_w = weight_retrain_module.wts_module.get_weight_offset()
        params = None
        if hasattr(weight_retrain_module.wts_module, 'params'):
            params = weight_retrain_module.wts_module.get_weight_param()
        check_record_params(wts_config['num_bits'], params)
        if params is not None:
            params = params.cpu().numpy().tobytes()

        check_scale_offset(scale_w, offset_w)
        scale_w = scale_w.cpu().tolist()
        offset_w = offset_w.cpu().int().tolist()

        weight_quant_param = WeightQuantParam(scale=scale_w, offset=offset_w,
                                              num_bits=wts_config.get('num_bits'))

        record_weights_scale_offset(self.records, layer_name, weight_quant_param, params)

    def do_pass(self, model, object_module, object_name, graph=None):
        """
        Function: Delete some mudule about retrain quantization.
        Parameters: model: torch.nn.Module, the model to be modified.
                    object_module: module to process
                    object_name: name of object_module
                    graph: graph structure, not necessary
        Return: None
        """
        act_config = object_module.act_config
        wts_config = object_module.wts_config
        num_of_input = object_module.common_config['num_of_input']

        # Step1: find module and its parent
        model_helper = ModuleHelper(model)
        parent_node = model_helper.get_parent_module(object_name)

        activation_retrain_module = \
            DeleteRetrainPass.get_data_quant_module(
                object_module, num_of_input, model_helper)
        weight_retrain_module = \
            DeleteRetrainPass.get_weight_quant_module(object_module)

        if type(object_module).__name__ in NO_WEIGHT_RETRAIN_MODULE_TYPES:
            replaced_module = object_module.retrain_module0.replaced_module
        else:
            replaced_module = object_module.replaced_module

        # Step2: trans weight from non uniform dirtibution to uniform dirtibution
        replaced_module = DeleteRetrainPass.trans_weight_distibute(
            wts_config, weight_retrain_module, replaced_module)

        self.record_data_quant_params(activation_retrain_module, object_module,
            object_name, num_of_input)
        if type(object_module).__name__ in RETRAIN_MODULE_TYPES:
            self.record_weight_quant_params(weight_retrain_module,
                object_module, object_name)

        # Step3: replace new model
        setattr(parent_node, object_name.split('.')[-1], replaced_module)

        LOGGER.logd(
            "Delete ActivationQAT and WeightQAT module "
            "of '{}' success!".format(object_name), 'DeleteRetrainPass')
