#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of node IR
"""
from copy import deepcopy


class NodeBase():
    """
    Function: Data structure of node which contains LayerParameter info
    APIs: is_data_node, index, set_index, name, type, layer, get_input_anchor,
          get_input_anchors, get_output_anchor, get_output_anchors,
          get_data, get_all_data, set_data, set_all_data, add_data,
          dump_proto
    """
    def __init__(self, node_id, node_index, node_proto):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        self._basic_info = {'node_index': node_index,
                            'name': node_id,
                            'type': ''}
        self._input_anchors = list()
        self._output_anchors = list()
        self._attrs = dict()
        self._node_proto = node_proto

    @property
    def is_data_node(self):
        """current node is data node"""
        return False

    @property
    def index(self):
        """
        Function: Get index of current node
        Parameter: None
        Return: node index
        """
        return self._basic_info['node_index']

    @property
    def name(self):
        """
        Function: Get name of current node
        Parameter: None
        Return: Name of node
        """
        return self._basic_info['name']

    @property
    def type(self):
        """
        Function: Get type of current node
        Parameter: None
        Return: Type of node
        """
        return self._basic_info['type']

    @property
    def proto(self):
        """
        Function: Get nodeParameter of current node
        Parameter: None
        Return: nodeParameter of node
        """
        return self._node_proto

    @property
    def attrs(self):
        """
        Function: Get all attrs from node
        Parameter: None
        Return: None
        """
        return self._attrs

    @property
    def input_anchors(self):
        """
        Function: Get current node's all input anchors
        Parameter: None
        Return: Input anchors
        """
        return self._input_anchors

    @property
    def output_anchors(self):
        """
        Function: Get current node's all output anchors
        Parameter: None
        Return: Output anchors
        """
        return self._output_anchors

    def set_attr(self, key, value):
        """
        Function: Set attr of 'key' with 'value' to node
        Parameter: key: name of attr to set
                   value: value of attr to set
        Return: None
        """
        self._attrs[key] = value

    def set_attrs(self, attrs):
        """
        Function: Set list of attrs to node
        Parameter: attrs: list of attrs
        Return: None
        """
        self._attrs = deepcopy(attrs)

    def has_attr(self, key):
        """
        Function: Check whether node have attr of 'key'
        Parameter: key: name of attr to find
        Return: None
        """
        if key in self._attrs:
            return True
        return False

    def get_attr(self, key):
        """
        Function: Get attr of 'key' from node
        Parameter: key: name of attr to find
        Return: None
        """
        if key not in self._attrs:
            raise RuntimeError('Cannot find {} in node {}'.format(
                key,
                self._basic_info['name']))
        return self._attrs[key]

    def set_index(self, node_index):
        """
        Function: set index of current node
        Parameter: None
        Return: None
        """
        self._basic_info['node_index'] = node_index

    def get_input_anchor(self, index):
        """
        Function: Get input anchor by index
        Parameter: None
        Return: Input anchor
        """
        if index >= len(self._input_anchors):
            raise RuntimeError('Node:{} get {} input out of range'.format(
                self._basic_info['name'], index))
        return self._input_anchors[index]

    def get_output_anchor(self, index):
        """
        Function: Get output anchor by index
        Parameter: None
        Return: Output anchor
        """
        if index >= len(self._output_anchors):
            raise RuntimeError('Node:{} get {} output out of range'.format(
                self._basic_info['name'], index))
        return self._output_anchors[index]

    def dump_proto(self):
        """
        Function: Dump node to proto object
        Parameter: None
        Return: proto object
        """
        raise NotImplementedError
