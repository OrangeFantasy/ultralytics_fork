# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

from hotwheels.amct_pytorch.quantize_tool import create_quant_config
from hotwheels.amct_pytorch.quantize_tool import quantize_model
from hotwheels.amct_pytorch.quantize_tool import save_model
from hotwheels.amct_pytorch.quantize_tool import create_quant_retrain_config
from hotwheels.amct_pytorch.quantize_tool import create_quant_retrain_model
from hotwheels.amct_pytorch.quantize_tool import restore_quant_retrain_model
from hotwheels.amct_pytorch.quantize_tool import save_quant_retrain_model
from hotwheels.amct_pytorch.quantize_tool import update_bn_status


__all__ = [
    'create_quant_config', 'quantize_model', 'save_model',
    'create_quant_retrain_config', 'create_quant_retrain_model',
    'restore_quant_retrain_model', 'save_quant_retrain_model',
    'update_bn_status', '__version__'
]

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]

with open(os.path.join(CUR_DIR, '.version')) as fid:
    __version__ = fid.readlines()[0].strip()
