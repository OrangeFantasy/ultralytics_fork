#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

model checker and model quirer

"""

from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_TYPES
from hotwheels.amct_pytorch.capacity.capacity_config import QUANTIZABLE_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import AMCT_OPERATIONS
from hotwheels.amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from hotwheels.amct_pytorch.utils.vars import QUANT_LAYER_SUFFIX
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_TYPES
from hotwheels.amct_pytorch.utils.vars import MULTI_INPUT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import DEFAULT_UNQUANTIZE_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import FUSE_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import RNN_TYPES
from hotwheels.amct_pytorch.utils.vars import get_no_weight_quant_type
from hotwheels.amct_pytorch.capacity.capacity_config import NO_WEIGHT_QUANT_ONNX_TYPES
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo


class GraphQuerier():
    '''provide some APIs to query the model'''

    @staticmethod
    def get_name_type_dict(graph):
        '''get all layer name to type dict'''
        layer_type = {}
        for node in graph.nodes:
            layer_type[node.name] = node.type
        LOGGER.logd("get name type dict from graph",
                    module_name="Configuration")
        return layer_type

    @staticmethod
    def get_support_quant_layers(graph, need_quant=True):
        '''return supported quant layers in model'''
        layers = []
        for node in graph.nodes:
            if need_quant:
                if not node.has_attr('need_quant') or \
                        not node.get_attr('need_quant'):
                    continue
            if GraphChecker.check_onnx_quantize_type(node):
                layers.append(node.name)
            elif GraphChecker.check_onnx_quantize_type_without_weight(node):
                layers.append(node.name)
        LOGGER.logd("get support quant nodes from graph",
                    module_name="Configuration")
        return layers

    @staticmethod
    def get_default_unquantize_layers(graph):
        '''return supported no weight quant layers in white list in graph'''
        layers = []
        for node in graph.nodes:
            if node.type in DEFAULT_UNQUANTIZE_ONNX_TYPES:
                layers.append(node.name)
        return layers

    @staticmethod
    def get_default_remove_layers(graph):
        '''return layers should remove by default'''
        layers = []
        for node in graph.nodes:
            if node.type != 'BatchNormalization':
                continue
            if len(node.input_anchors) < 1:
                continue
            peer_output_anchor = \
                node.get_input_anchor(0).get_peer_output_anchor()
            previous_node = peer_output_anchor.node
            if previous_node.type in FUSE_ONNX_TYPES:
                layers.append(node.name)
        return layers

    @staticmethod
    def check_op_matching(graph, fused_op_list):
        """
        Function: Check whether the ops in json the ops in the original graph
        Inputs:
            graph: Graph, to be quantized
            fused_op_list: list, the ops parsed from the json file
        """
        # check whether the ops in json the ops in the original graph
        original_graph_ids = graph.node_ids
        for json_op_name in fused_op_list:
            is_quant_op = False
            for quant_suffix in QUANT_LAYER_SUFFIX:
                if quant_suffix in json_op_name:
                    is_quant_op = True
            if is_quant_op:
                continue
            if json_op_name not in original_graph_ids:
                raise RuntimeError(
                    "Op '{}' in the given mapping_file do not exist in the original graph. "
                    "The mapping_file may not match the original graph, please check!".format(json_op_name))

    @staticmethod
    def get_support_no_weight_quant_layers(graph):
        '''return supported no weight quant layers in graph'''
        layers = []
        for node in graph.nodes:
            if GraphChecker.check_onnx_quantize_type_without_weight(node):
                layers.append(node.name)
        return layers

    @staticmethod
    def get_multi_input_layers(graph):
        '''return multi input layers in graph'''
        layers = []
        for node in graph.nodes:
            if node.type in MULTI_INPUT_ONNX_TYPES:
                if GraphChecker.is_matmul_with_weight(node):
                    continue
                layers.append(node.name)
        return layers

    @staticmethod
    def get_layer_input_num_dict(graph):
        '''return input num dict of layer in graph'''
        input_num_dict = {}
        for node in graph.nodes:
            if node.type in RNN_ONNX_TYPES:
                # LSTM: x, (h, c)
                # GRU: x, h
                input_num_dict[node.name] = 2
            else:
                input_num_dict[node.name] = len(node.input_anchors)
        return input_num_dict


class GraphChecker():
    """Check the model."""

    @staticmethod
    def check_quantize_type(mod_name, mod, graph=None):
        """ check if mod in model can be quantized or not."""
        mod_type = type(mod).__name__

        if mod_type == 'Conv1d':
            raise ValueError('Layer {} with type {} does not support quant, '
                'please replace it with type in {}.'.format(mod_name,
                mod_type, QUANTIZABLE_TYPES))

        # check type
        if mod_type not in QUANTIZABLE_TYPES:
            return False

        if mod_type in ['Conv2d', 'ConvTranspose2d']:
            not_support = False
            if mod.padding_mode != 'zeros':
                LOGGER.logd("Layer %s's padding_mode is %s." %
                            (mod_name, mod.padding_mode),
                            module_name="Configuration")
                not_support = True
            if not_support:
                return False
        if mod_type in RNN_TYPES:
            if mod.num_layers != 1:
                LOGGER.logi("Layer %s with type %s has more than one layers, "
                    "not support quant now!" % (mod_name, mod_type),
                    module_name="Configuration")
                return False
            if not mod.bias:
                LOGGER.logi("Layer %s with type %s has no bias, "
                    "not support quant now!" % (mod_name, mod_type),
                    module_name="Configuration")
                return False
        if graph is not None:
            try:
                node = graph.get_node_by_name(mod_name)
                return GraphChecker.check_special_limit(node)
            except RuntimeError:
                # the mod is not in graph
                return False
        return True

    @staticmethod
    def check_quantizable_type_without_weight(mod_name, mod, graph=None):
        """ check if mod in model can be quantized or not."""
        mod_type = type(mod).__name__
        # check type
        if mod_type not in get_no_weight_quant_type():
            return False
        return True

    @staticmethod
    def check_onnx_quantize_type(node):
        """ check if node in graph can be quantized or not."""
        # check type
        if node.type not in QUANTIZABLE_ONNX_TYPES:
            return False
        if node.type == 'MatMul' and not GraphChecker.is_matmul_with_weight(node):
            return False
        if node.type in ['Conv', 'ConvTranspose']:
            # conv2D
            if not _check_kernel_shape(node, [2]):
                return False

        return GraphChecker.check_special_limit(node)

    @staticmethod
    def check_onnx_quantize_type_without_weight(node):
        """ check if node in graph can be quantized or not."""
        # check type
        if node.type not in NO_WEIGHT_QUANT_ONNX_TYPES:
            return False
        if GraphChecker.is_matmul_with_weight(node):
            return False
        # Check not support reused node do quantize\
        if node.type != 'Add':
            return GraphChecker.check_special_limit(node)
        return True

    @staticmethod
    def is_matmul_with_weight(node):
        if node.type == 'MatMul':
            weight_node = QuantOpInfo.get_weight_node(node)
            weight_type = weight_node.type
            if weight_type == 'initializer':
                return True
        return False

    @staticmethod
    def check_special_limit(node):
        """ Check if the node in graph satisfy special limits to be quantized,
            limits include:
                1. Gemm's transA must be false
                2. reused module is not support
        """
        # Check not support Gemm with transA:True
        attr_helper = AttributeProtoHelper(node.proto)
        if node.type == 'Gemm':
            if attr_helper.has_attr('transA') and \
                    attr_helper.get_attr_value('transA') == 1:
                LOGGER.logw('Cannot support quantize "Gemm" layer "{}" with '
                            'transA:True.'.format(node.name))
                return False
        return True

    @staticmethod
    def check_quant_behaviours(graph):
        """
        Function: Check whether there're quant behaviours in the model.
            If there're layers defined by AMCT, raise error.
        Inputs: None
        Return: None
        """

        quant_defined_layers = []
        if graph.model is None:
            # find all layers whose type is in AMCT_OPERATIONS in onnx graph
            for node in graph.nodes:
                if node.type in AMCT_OPERATIONS:
                    quant_defined_layers.append(node.name)
        else:
            # find all the layers whose type is in AMCT_OPERATIONS in model
            for name, mod in graph.model.named_modules():
                if type(mod).__name__ in AMCT_OPERATIONS:
                    quant_defined_layers.append(name)

        if quant_defined_layers:
            raise RuntimeError("The model cannot be quantized for following "
                               "quant layers are in the model %s" % quant_defined_layers)


def _check_kernel_shape(node, kernel_shape_range):
    """ Check whether the node's kernel_shape satisfy kernel_shape_range"""
    kernel_shape = AttributeProtoHelper(
        node.proto).get_attr_value('kernel_shape')
    if len(kernel_shape) not in kernel_shape_range:
        LOGGER.logd("Layer %s's kernel_shape is %s." %
                    (node.name, kernel_shape),
                    module_name="Configuration")
        return False

    return True


def _check_dilation(node, dilation_range):
    """ Check whether the node's dilation satisfy dilation_range"""
    dilation = AttributeProtoHelper(node.proto).get_attr_value('dilations')
    if dilation not in dilation_range:
        LOGGER.logd("Layer %s's dilation is %s." % (node.name, dilation),
                    module_name="Configuration")
        return False

    return True


def _check_group(node, group_range):
    """ Check whether the node's group satisfy group_range"""
    try:
        group = AttributeProtoHelper(node.proto).get_attr_value('group')
    except RuntimeError:
        group = 1
    if group != group_range:
        LOGGER.logd("Layer %s's group is %s." % (node.name, group))
        return False
    return True