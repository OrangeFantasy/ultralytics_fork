#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Generate json file that contains fusion layer infos

"""
import os
import json
from collections import OrderedDict
from copy import deepcopy
import datetime
import stat

from hotwheels.amct_pytorch.common.utils import files as files_util
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_FLAG
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_MODE
from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.attrs_list import \
    ATTR_NODE_EQUIVALENT_OBJECT_LAYER
from hotwheels.amct_pytorch.utils.attrs_list import ATTR_NODE_EQUIVALENT_INPUT
from hotwheels.amct_pytorch.utils.attrs_list import ATTR_NODE_EQUIVALENT_OUTPUT
from hotwheels.amct_pytorch.utils.attrs_list import ATTR_NODE_FUSION_INFO
from hotwheels.amct_pytorch.utils.attrs_list import ATTR_NODE_OUTPUT_NODE

DEFAULT_ORIGINAL_OP_INFO = {
    "key": "_datadump_original_op_names",
    "value": {
        "list": {
            "val_type": 1
        }
    }
}

DEFAULT_OUTPUT_DESC = {
    "attr": [
        {
            "key": "_datadump_origin_format",
            "value": {
                "s": "NCHW"
            }
        },
        {
            "key": "_datadump_data_type",
            "value": {
                "s": "DT_FLOAT"
            }
        },
        {
            "key": "_datadump_origin_output_index",
            "value": {
                "i": 0
            }
        },
        {
            "key": "_datadump_origin_name",
            "value": {
                "s": ""
            }
        }
    ]
}

DUMP_FILE_MOD = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP


class GenFusionJsonPass(BaseFusionPass):
    """
    Function: Generate json file that contains fusion layer infos
    APIs: match_pattern, do_pass
    """

    def __init__(self):
        """
        Function: Init object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.__ops = []
        self.__graph_name = None
        self.__dump_file = ''
        self.__save_path = None
        self.__save_prefix = None

    def tear_down(self):
        """
        Function: write the fusion info to json file.
        Inputs: None
        Returns: None
        """
        dump_info = OrderedDict()
        dump_info['graph'] = [{'op': self.__ops}]

        if self.__save_prefix != '':
            dump_info['name'] = self.__save_prefix
        elif self.__graph_name is not None:
            dump_info['name'] = self.__graph_name
        else:
            time = datetime.datetime.now()
            time_str = '{:0>4}{:0>2}{:0>2}{:0>2}{:0>2}{:0>2}{:0>2}'.format(
                time.year, time.month, time.day, time.hour, time.minute,
                time.second, time.microsecond // 10000)
            dump_info['name'] = 'default_{}'.format(time_str)

        dump_file = os.path.join(self.__save_path,
                                 '{}_quant.json'.format(self.__save_prefix))

        files_util.create_path(self.__save_path)
        with os.fdopen(os.open(dump_file, FILE_ACCESS_FLAG, FILE_ACCESS_MODE),
            'w') as write_file:
            json.dump(dump_info, write_file, indent=4)
        os.chmod(dump_file, DUMP_FILE_MOD)

    def match_pattern(self, node):
        """
        Function: Find node need dump info in graph
        Parameters: node: node in graph
        Return: True: node that need to dump info
                False: skip the node
        """
        return True

    def set_dump_file_dir(self, save_path, save_prefix):
        """
        Function: Set file name and path to save dump file
        Parameters: dump_file: file name and path to save dump file
        Return: None
        """
        self.__save_path = save_path
        self.__save_prefix = save_prefix

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual fusion info record.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        single_node_info = OrderedDict()
        single_node_info['name'] = object_node.name
        single_node_info['type'] = object_node.type
        # Generate dump info of layer to quantize
        is_quant = 0
        is_quant += int(object_node.has_attr(ATTR_NODE_EQUIVALENT_INPUT))
        is_quant += int(object_node.has_attr(ATTR_NODE_EQUIVALENT_OUTPUT))
        is_quant += int(object_node.has_attr(ATTR_NODE_FUSION_INFO))
        if is_quant > 0:
            LOGGER.logd('Find node {} as object node'.format(
                object_node.name))
            single_node_attr = deepcopy(DEFAULT_ORIGINAL_OP_INFO)
            single_node_attr['value']['list']['s'] = [object_node.name]
            if object_node.has_attr(ATTR_NODE_FUSION_INFO):
                single_node_attr['value']['list']['s'] = \
                    object_node.get_attr(ATTR_NODE_FUSION_INFO)
            single_node_info['attr'] = [single_node_attr]
        # Generate Quant/DeQuant layer dump info
        if object_node.has_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER):
            LOGGER.logd('Find node {} as add node'.format(object_node.name))
            single_node_attr = deepcopy(DEFAULT_ORIGINAL_OP_INFO)
            eq_node_name = object_node.get_attr(
                ATTR_NODE_EQUIVALENT_OBJECT_LAYER)

            def generate_equivalent_info(graph, eq_node_name, node_attr):
                """Generate equivalent info from eq_node_name
                """
                if eq_node_name != '':
                    eq_node = graph.get_node_by_name(eq_node_name)
                    node_attr['value']['list']['s'] = \
                        [eq_node.name]
                    if eq_node.has_attr(ATTR_NODE_FUSION_INFO):
                        node_attr['value']['list']['s'] = \
                            eq_node.get_attr(ATTR_NODE_FUSION_INFO)

                    if eq_node.has_attr(ATTR_NODE_EQUIVALENT_OUTPUT):
                        if object_node.name == eq_node.get_attr(
                                ATTR_NODE_EQUIVALENT_OUTPUT):
                            output_attr = [deepcopy(DEFAULT_OUTPUT_DESC)]
                            output_origin_name = eq_node.name
                            if eq_node.has_attr(ATTR_NODE_FUSION_INFO):
                                output_origin_name = eq_node.get_attr(
                                    ATTR_NODE_OUTPUT_NODE)
                            output_attr[0]['attr'][3]['value']['s'] = \
                                output_origin_name
                            single_node_info['output_desc'] = output_attr

            generate_equivalent_info(graph, eq_node_name, single_node_attr)
            single_node_info['attr'] = [single_node_attr]
        self.__ops.append(single_node_info)

        LOGGER.logd('Record node {} fusion info success!'.format(
            object_node.name), 'GenFusionJsonPass')
