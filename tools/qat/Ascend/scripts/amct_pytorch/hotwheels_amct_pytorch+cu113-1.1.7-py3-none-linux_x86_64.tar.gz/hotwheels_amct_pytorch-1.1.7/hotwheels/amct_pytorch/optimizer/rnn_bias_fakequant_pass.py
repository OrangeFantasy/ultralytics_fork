#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fakequant rnn bias from int32 to float32.

"""
import numpy as np
from hotwheels.amct_pytorch.utils.quant_node import QuantOpInfo
from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.optimizer.bias_fakequant_pass import BiasFakequantPass
from hotwheels.amct_pytorch.optimizer.rnn_bias_quant_pass import \
    RNNBiasQuantPass
from hotwheels.amct_pytorch.utils.rnn_utils import get_rnn_helper


class RNNBiasFakequantPass(BiasFakequantPass):
    """
    Function: Fakequant bias from int32 to float32
    APIs: match_pattern, do_pass
    """

    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BiasFakequantPass.__init__(self, records)

    @staticmethod
    def get_fakequant_bias(weight, int32_bias, dequant_scales, offset_d, object_node):
        quant_bias = np.array([0] * int32_bias.size).astype(np.float32)
        for fc_index in range(weight.shape[0]):
            dequant_scale = dequant_scales[fc_index]
            for bias_index in range(len(int32_bias[fc_index])):
                bias_iter_index = \
                    len(int32_bias[fc_index]) * fc_index + bias_index
                quant_bias[bias_iter_index] = BiasFakequantPass.fake_quant_bias(
                    int32_bias[fc_index][bias_index],
                    offset_d,
                    object_node.name,
                    weight[fc_index][bias_index].sum()
                )
                quant_bias[bias_iter_index] = quant_bias[bias_iter_index] / dequant_scale
        return quant_bias

    @staticmethod
    def get_weight_bias(rnn_helper, bias_helper, x_weight_param, h_weight_param):
        fc_num = rnn_helper.weights_count()
        if not rnn_helper.bidirectional:
            x_weight, h_weight = RNNBiasQuantPass.get_weight(x_weight_param,
                                                             h_weight_param, fc_num)
            x_int32_bias, h_int32_bias = RNNBiasQuantPass.get_bias(bias_helper, fc_num)
        else:
            fc_num = rnn_helper.weights_count()
            half = fc_num // 2
            x_xr_weight, h_hr_weight = RNNBiasQuantPass.get_weight(x_weight_param,
                                                                   h_weight_param, fc_num)
            x_weight, h_weight = x_xr_weight[:half], h_hr_weight[:half]

            # onnx lstm bias
            #   one_way           >> x_b, h_b
            #   bidirectional     >> x_b h_b, x_b_reverse h_b_reverse
            xh_int32_bias, xh_int32_bias_reverse = RNNBiasQuantPass.get_bias(bias_helper, fc_num)
            half = len(xh_int32_bias) // 2
            x_int32_bias, h_int32_bias = xh_int32_bias[:half], xh_int32_bias[half:]
        return x_weight, h_weight, x_int32_bias, h_int32_bias

    @staticmethod
    def get_weight_bias_reverse(rnn_helper, bias_helper, x_weight_param, h_weight_param):
        fc_num = rnn_helper.weights_count()
        half = fc_num // 2
        x_xr_weight, h_hr_weight = RNNBiasQuantPass.get_weight(x_weight_param,
                                                               h_weight_param, fc_num)
        x_weight_reverse, h_weight_reverse = x_xr_weight[half:], h_hr_weight[half:]
        # onnx lstm bias
        #   one_way           >> x_b, h_b
        #   bidirectional     >> x_b h_b, x_b_reverse h_b_reverse
        xh_int32_bias, xh_int32_bias_reverse = RNNBiasQuantPass.get_bias(bias_helper, fc_num)
        half = len(xh_int32_bias) // 2
        x_int32_bias_reverse, h_int32_bias_reverse = xh_int32_bias_reverse[:half], xh_int32_bias_reverse[half:]
        return x_weight_reverse, h_weight_reverse, x_int32_bias_reverse, h_int32_bias_reverse

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type not in RNN_ONNX_TYPES:
            return False
        if node.name not in self.records:
            return False
        '''
        input_anchor[0]: x
        input_anchor[1]: x_w
        input_anchor[2]: h_w
        input_anchor[3]: bias
        '''
        bias_index = 3
        peer_output_anchor = node.input_anchors[bias_index].get_peer_output_anchor()
        if peer_output_anchor is None:
            return False
        if peer_output_anchor.node.type != 'initializer':
            return False

        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual quantization and node's bias is changed to float32.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        rnn_helper = get_rnn_helper(object_node)
        fc_num = rnn_helper.weights_count()

        # get weight quantization information
        x_weight_param, h_weight_param, bias_param = \
            QuantOpInfo.get_rnn_weight_node(object_node)

        x_offset_d = self.records.get(object_node.name).get('data_offset')[0]
        h_offset_d = self.records.get(object_node.name).get('data_offset')[1]
        x_scale_d = self.records.get(object_node.name).get('data_scale')[0]
        h_scale_d = self.records.get(object_node.name).get('data_scale')[1]
        weight_scale = self.records.get(object_node.name).get('weight_scale').reshape(2, -1)
        if rnn_helper.bidirectional:
            half = fc_num // 2
            x_weight_scale = weight_scale[0][:half]
            x_weight_scale_reverse = weight_scale[0][half:]
            h_weight_scale = weight_scale[1][:half]
            h_weight_scale_reverse = weight_scale[1][half:]
        else:
            x_weight_scale = weight_scale[0]
            h_weight_scale = weight_scale[1]

        bias_helper = TensorProtoHelper(bias_param.proto)
        x_weight, h_weight, x_int32_bias, h_int32_bias = \
            self.get_weight_bias(rnn_helper, bias_helper, x_weight_param, h_weight_param)
        x_dequant_scales = x_scale_d * x_weight_scale
        quant_bias_x = self.get_fakequant_bias(x_weight, x_int32_bias,
                                               x_dequant_scales,
                                               x_offset_d, object_node)
        h_dequant_scales = h_scale_d * h_weight_scale
        quant_bias_h = self.get_fakequant_bias(h_weight, h_int32_bias,
                                               h_dequant_scales,
                                               h_offset_d, object_node)
        float_bias = np.concatenate([quant_bias_x, quant_bias_h]).astype(np.float32)
        if rnn_helper.bidirectional:
            x_weight_reverse, h_weight_reverse, x_int32_bias_reverse, h_int32_bias_reverse = \
                self.get_weight_bias_reverse(rnn_helper, bias_helper, x_weight_param, h_weight_param)
            x_dequant_scales_reverse = x_scale_d * x_weight_scale_reverse
            quant_bias_x_reverse = self.get_fakequant_bias(x_weight_reverse, x_int32_bias_reverse,
                                                           x_dequant_scales_reverse,
                                                           x_offset_d, object_node)
            h_dequant_scales_reverse = h_scale_d * h_weight_scale_reverse
            quant_bias_h_reverse = self.get_fakequant_bias(h_weight_reverse, h_int32_bias_reverse,
                                                           h_dequant_scales_reverse,
                                                           h_offset_d, object_node)
            float_bias = np.concatenate([float_bias, quant_bias_x_reverse,
                                         quant_bias_h_reverse])

        bias_helper.clear_data()
        bias_helper.set_data(float_bias, 'FLOAT')

        LOGGER.logd("Fakequant bias from int32 to float32 for layer '{}' "
                    .format(object_node.name), 'RNNBiasFakequantPass')
