# !/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Generate quant param record operation

"""

import os
import ctypes
from hotwheels.amct_pytorch.proto import scale_offset_record_pb2
from hotwheels.amct_pytorch.proto import quant_param_record_pb2
from hotwheels.amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from hotwheels.amct_pytorch.configuration.configuration import Configuration
from hotwheels.amct_pytorch.configuration.retrain_config import RetrainConfig
from google.protobuf import text_format
from hotwheels.amct_pytorch.utils.vars import AMCT_OPERATIONS
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    record_activation_scale_offset
from hotwheels.amct_pytorch.common.utils.record_file_operator import \
    read_activation_scale_offset
from hotwheels.amct_pytorch.custom_op.utils import is_valid_input_node
from hotwheels.amct_pytorch.custom_op.utils import get_offline_optimize_index
from hotwheels.amct_pytorch.utils.vars import SNQ_WEIGHT_BIT_NUM
from hotwheels.amct_pytorch.utils.vars import RNN_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import NON_INSIST_ONNX_TYPES
from hotwheels.amct_pytorch.utils.vars import AICPU_LAYER
from hotwheels.amct_pytorch.utils.vars import OFFLINE_OPTIMIZE_LAYER_TYPES
from hotwheels.amct_pytorch.custom_op.utils import is_graph_input_node
from hotwheels.amct_pytorch.utils.rnn_utils import get_rnn_helper
from hotwheels.amct_pytorch.common.utils.util import get_data_cal_type
from hotwheels.amct_pytorch.common.utils.util import get_weights_cal_type
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_FLAG
from hotwheels.amct_pytorch.common.utils.files import FILE_ACCESS_MODE

from hotwheels.amct_pytorch.common.utils.record_file_operator import ActivationQuantParam

FISRT_BUF_LEN = 256
SECOND_BUF_LEN = 16
_MODULE_NAME = 'GenQuantParamRecordPass'


class BitParams(ctypes.Structure):
    """
    The stucture defined in HMCT libraries
    * :attr:`buf_first` first save buffer
    * :attr:`buf_second` second save buffer
    """
    _fields_ = [("buf_first", ctypes.c_int8 * FISRT_BUF_LEN),
                ("buf_second", ctypes.c_int8 * SECOND_BUF_LEN)]


DEFAULT_SCALE = 1
DEFAULT_OFFSET = 0
DEFAULT_ACTIVATION_QUANT_BIT = 32


class GenQuantParamRecordPass(BaseFusionPass):
    """
    Function: Do generate quant param record operation
    APIs: set_up,  match_pattern, tear_down, do_pass
    """

    def __init__(self, save_dir, save_prefix, is_retrain=False):
        """
        Inputs: the directory to save quant param
        Returns: None
        """
        if is_retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()
        self.is_retrain = is_retrain
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.record_file_path = self.conf.get_record_file_path()
        self.quant_param_records = quant_param_record_pb2.CalibrationParam()
        self.save_dir = save_dir
        self.save_prefix = save_prefix

    @staticmethod
    def get_input_index(share_input_node, peer_input_node):
        if len(peer_input_node.input_anchors) == 1:
            return 0
        for input_anchor in peer_input_node.input_anchors:
            if input_anchor.get_peer_output_anchor().node.name == \
                    share_input_node.name:
                return input_anchor.index
        raise RuntimeError("Can not find index of node '{}' with share node "
                           "'{}'".format(peer_input_node.name,
                                         share_input_node.name))

    @classmethod
    def match_pattern(cls, node, model):
        """
        Function: Only the layers to be quantized will be picked
        Inputs: The node to be checked
        Returns: None
        """
        if node.type in AMCT_OPERATIONS:
            return False
        if node.type in ('initializer', 'sparse_initializer'):
            return False
        return True

    @classmethod
    def generate_quant_params(cls, quant_param, item, node):
        """
        Function: Do generate quant param file operation.
        Inputs: quant_param: The quant_param added for current layer
                item: record in original record file
                node: the node to be recorded
        Returns: None
        """
        for index in range(len(item.value.record_d)):
            for record_d in item.value.record_d:
                if record_d.index != index:
                    continue
                input_param = quant_param.input.add()
                input_param.data_type = get_data_cal_type(record_d.num_bits_d)
                input_param.scale.append(record_d.scale_d)
                input_param.offset.append(record_d.offset_d)

            if item.value.scale_w:
                weight_param = quant_param.weight
                weight_param.data_type = get_weights_cal_type(
                    item.value.num_bits_w)
                if item.value.num_bits_w == SNQ_WEIGHT_BIT_NUM:
                    weight_param.params = item.value.params
                for scale_w in item.value.scale_w:
                    weight_param.scale.append(scale_w)

    def generate_output_node_params(self, quant_param, item, node):
        """
        generate quant param for output of no insist layer which is tail node
        :param quant_param: The quant_param added for current layer
        :param item: record in original record file
        :param node: the node to be recorded
        :return: None
        """
        if len(node.output_anchors) == 0:
            return
        output_anchors = node.output_anchors
        outputs_count = 0
        for output_anchor in output_anchors:
            peer_input_anchors = output_anchor.get_peer_input_anchor()
            if len(peer_input_anchors) == 0:
                return
            # judge current node is tail node or not and count its outputs path
            for peer_input_anchor in peer_input_anchors:
                # output is effective when peer node is output node,
                # compatible with one and multi outputs case
                if len(peer_input_anchor.node.output_anchors) == 0:
                    outputs_count = outputs_count + 1
        # output param will not be added to quant_param if outputs_count is 0
        if outputs_count and len(item.value.record_d) > 0:
            record_d = item.value.record_d[0]
            for _ in range(outputs_count):
                output_param = quant_param.output.add()
                output_param.data_type = get_data_cal_type(record_d.num_bits_d)
                output_param.scale.append(record_d.scale_d)
                output_param.offset.append(record_d.offset_d)


    def set_up(self):
        """
        Function: Open the record file
        Inputs: None
        Returns: None
        """
        with os.fdopen(os.open(self.record_file_path, os.O_RDONLY,
            FILE_ACCESS_MODE), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: Write quant param into file
        Inputs: None
        Returns: None
        """
        file_suffix = 'quant_param_record.txt'

        if self.save_prefix != '':
            save_path = os.path.join(self.save_dir, '_'.join([self.save_prefix,
                                                              file_suffix]))
        else:
            save_path = os.path.join(self.save_dir, file_suffix)
        with os.fdopen(os.open(save_path, FILE_ACCESS_FLAG, FILE_ACCESS_MODE),
            'w') as record_file:
            record_file.write(text_format.MessageToString(
                self.quant_param_records, as_utf8=True))

    def get_number_of_node_input_anchors(self, node):
        """
        Function: Get real number of node input
        """
        num_input = 0
        if node.type in RNN_ONNX_TYPES:
            rnn_helper = get_rnn_helper(node)
            return rnn_helper.input_num()
        if node.type == 'graph_anchor':
            return 1
        for input_anchor in node.input_anchors:
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            if peer_output_anchor is None:
                continue
            input_node = peer_output_anchor.node
            if is_valid_input_node(input_node):
                num_input = num_input + 1
        return num_input

    def get_nodes_activation_record_fill_dict(self, matched_nodes):
        """
        Function: Find nodes with imcompleted or without activation records
        Inputs: all nodes
        Return: activation record dicts, specify if every input of the node 
                has record
        """
        activation_record_dict = {}
        for node in matched_nodes:
            input_anchor_num = self.get_number_of_node_input_anchors(node)
            activation_record_dict[node.name] = [False] * input_anchor_num
            for record in self.records.record:
                if node.name != record.key:
                    continue
                for index in range(input_anchor_num):
                    try:
                        scale, _, num_bits_d = \
                            read_activation_scale_offset(self.records,
                                                         node.name,
                                                         index)
                    except RuntimeError:
                        continue
                    activation_record_dict[node.name][index] = True
        return activation_record_dict

    def get_peer_node_of_input_node(self, input_node):
        """
        Function: Get peer node of input node
        Inputs: input node 
        Return: peer node
        """
        peer_node = None
        peer_node_index = 0
        if len(input_node.output_anchors) < 0:
            return peer_node_index, peer_node
        output_anchor = input_node.output_anchors[0]
        if len(output_anchor.get_peer_input_anchor()) == 1:
            peer_input_anchor = output_anchor.get_peer_input_anchor()[0]
            peer_node_index = peer_input_anchor.index
            peer_node = peer_input_anchor.node
        else:
            for peer_input_anchor in output_anchor.get_peer_input_anchor():
                if is_valid_input_node(peer_input_anchor.node):
                    peer_node_index = peer_input_anchor.index
                    peer_node = peer_input_anchor.node
                    break
        if peer_node is None:
            return peer_node_index, peer_node
        if peer_node.type in RNN_ONNX_TYPES:
            if peer_node_index == 0:
                return peer_node_index, peer_node
            offline_optimize_index = get_offline_optimize_index(peer_node)
            peer_node_index = peer_node_index - offline_optimize_index
        return peer_node_index, peer_node

    def get_scale_offset_of_peer_node(self, peer_node, peer_node_index):
        """
        Function: Get data scale and data offset of peer node
        Inputs: peer_node
        Return: data scale and data offset
        """
        if peer_node is None:
            return DEFAULT_SCALE, DEFAULT_OFFSET, DEFAULT_ACTIVATION_QUANT_BIT
        else:
            return read_activation_scale_offset(
                self.records, peer_node.name, peer_node_index)

    def fill_activation_record_to_input_layer(self,
                                              activation_record_fill_dict,
                                              matched_nodes):
        """
        Function: Fill quant params to input layer with as same as next layer
        Inputs: original record and all nodes
        Return: records with all layers having quant params 
        """
        for node in matched_nodes:
            # type of input node should be 'graph_anchor'
            # the number of output node of input node should be larger than 0 
            if not is_graph_input_node(node):
                continue
            peer_node_index, peer_node = self.get_peer_node_of_input_node(node)

            scale_d, offset_d, num_bit_d = \
                self.get_scale_offset_of_peer_node(peer_node, peer_node_index)
            activation_quant_param = ActivationQuantParam(scale=scale_d, offset=offset_d,
                                                          index=0, num_bits=num_bit_d)
            record_activation_scale_offset(
                self.records, node.name, activation_quant_param)
            activation_record_fill_dict[node.name][0] = True

    def fill_activation_record_with_default_value(
            self, activation_record_fill_dict, matched_nodes):
        """
        Function: Fill quant params to the layers without quant params with 
            default value
        Inputs: original record and all nodes
        Return: records with all layers having quant params 
        """
        for node in matched_nodes:
            record_dict = activation_record_fill_dict[node.name]
            if not record_dict:
                continue
            for index, val in enumerate(record_dict):
                if val:
                    continue
                activation_quant_param = ActivationQuantParam(scale=DEFAULT_SCALE, offset=DEFAULT_OFFSET,
                                                              index=index, num_bits=DEFAULT_ACTIVATION_QUANT_BIT)
                record_activation_scale_offset(
                    self.records, node.name, activation_quant_param)
                activation_record_fill_dict[node.name][index] = True

    def fill_layer_record_with_one_input_multi_reference(self,
                                                         activation_record_fill_dict,
                                                         matched_nodes):
        def fill_layer_record(peer_output_anchor):
            for peer_input_anchor in peer_output_anchor.get_peer_input_anchor():
                peer_output_node_name = peer_input_anchor.node.name
                if peer_output_node_name == node.name:
                    continue
                try:
                    scale, offset, num_bit = read_activation_scale_offset(
                        self.records, peer_output_node_name,
                        peer_output_anchor.index)
                except RuntimeError:
                    continue
                activation_quant_param = ActivationQuantParam(scale=scale, offset=offset,
                                                              index=record_index,
                                                              num_bits=num_bit)
                record_activation_scale_offset(self.records, node.name, activation_quant_param)
                activation_record_fill_dict[node.name][record_index] = True

        for node in matched_nodes:
            if node.type not in AICPU_LAYER:
                continue
            optimizer_index = 0
            for input_anchor in node.input_anchors:
                index = input_anchor.index
                peer_output_anchor = input_anchor.get_peer_output_anchor()
                input_node = peer_output_anchor.node
                if input_node.type in OFFLINE_OPTIMIZE_LAYER_TYPES:
                    optimizer_index = index + 1
                    continue
                # one input of concat layer is one out multiple referenced
                if len(peer_output_anchor.get_peer_input_anchor()) <= 1:
                    continue
                record_index = index - optimizer_index
                fill_layer_record(peer_output_anchor)

    def fill_activation_record(self, activation_record_fill_dict,
                               matched_nodes):
        self.fill_activation_record_with_default_value(
            activation_record_fill_dict, matched_nodes)
        self.fill_layer_record_with_one_input_multi_reference(
            activation_record_fill_dict, matched_nodes)
        self.fill_activation_record_to_input_layer(
            activation_record_fill_dict, matched_nodes)

    def do_pass(self, graph, matched_nodes):
        """
        Function: Do generate quant param file operation.
        Inputs: Graph: The graph to be iterated
                Node: The node to insert quant param
        Returns: None
        """
        activation_record_fill_dict = \
            self.get_nodes_activation_record_fill_dict(matched_nodes)
        self.fill_activation_record(activation_record_fill_dict, matched_nodes)
        for node in matched_nodes:
            for item in self.records.record:
                if node.name != item.key:
                    continue
                layer_param = self.quant_param_records.layer.add()
                layer_param.name = item.key
                quant_param = layer_param.quant_param
                if node.type in NON_INSIST_ONNX_TYPES:
                    self.generate_output_node_params(quant_param, item, node)
                if node.type in RNN_ONNX_TYPES:
                    rnn_helper = get_rnn_helper(node)
                    rnn_helper.generate_quant_params(quant_param, layer_param,
                                                     item)
                    continue
                else:
                    self.generate_quant_params(quant_param, item, node)

        for node in matched_nodes:
            if node.type not in RNN_ONNX_TYPES:
                continue
            rnn_helper = get_rnn_helper(node)
            rnn_helper.refresh_param_for_input_nodes(self.quant_param_records)

    def run(self, graph, model):
        """
        Function: Find all quantizable layers at once,
                  generate quant param record file
        Parameters: Graph: The graph to be iterated
        Return: None
        """
        self.set_up()
        # Step1: match pattern and record first matched node
        matched_nodes = []
        for node in graph.nodes:
            if self.match_pattern(node, model):
                matched_nodes.append(node)
        # Step2: do each matched node fusion operation
        self.do_pass(graph, matched_nodes)
        # Step3: do topoligical sort
        graph.topologic_sort()
        self.tear_down()
