#!/usr/bin/python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) CompanyNameMagicTag

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct tool quant configuration class

"""
import os
from pathlib import Path

from hotwheels.amct_pytorch.utils.log import LOGGER
from hotwheels.amct_pytorch.graph.graph import Graph
from hotwheels.amct_pytorch.configuration.check import GraphChecker
from hotwheels.amct_pytorch.configuration.check import GraphQuerier
from hotwheels.amct_pytorch.common.utils.check_params import check_params
from hotwheels.amct_pytorch.common.utils.files import is_valid_name
from hotwheels.amct_pytorch.common.config.config_base import ConfigBase
from hotwheels.amct_pytorch.common.config.config_base import GraphObjects
from hotwheels.amct_pytorch.common.config.config_base import check_config_quant_enable

from hotwheels.amct_pytorch.capacity import CAPACITY
from hotwheels.amct_pytorch.utils.vars import ACTIVATION_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import WEIGHT_QUANT_PARAMS
from hotwheels.amct_pytorch.utils.vars import QUANT_ENABLE

CONFIGURER = ConfigBase(
    GraphObjects(graph_querier=GraphQuerier, graph_checker=None), CAPACITY)


class Configuration:  # pylint: disable=attribute-defined-outside-init
    """
    Function: manage configuration of project including quant_config
              and record_file.
    APIs: get_quant_config, get_layer_config, get_record_file_path;
        create_quant_config, parse_quant_config
    """
    __instance = None

    def __new__(cls, *args, **kw):
        if cls.__instance is None:
            cls.__instance = object.__new__(cls, *args, **kw)
        return cls.__instance

    @staticmethod
    @check_params(config_file=str,
                  graph=Graph,
                  skip_modules=(list, type(None)),
                  batch_num=int,
                  activation_offset=bool,
                  config_defination=(type(None), str))
    def create_quant_config(  # pylint: disable=too-many-arguments
            config_file,
            graph,
            skip_modules=None,
            batch_num=1,
            activation_offset=True,
            config_defination=None):
        """
        Function: Create quant config.
        Inputs:
            config_file: a string, the file(including path information) to
                save quant config.
            graph: IR Graph, the graph to be quantized.
            skip_modules: a list, cell names which would not apply quantize,
                the skip layer type should be in ['Conv2D', 'MatMul'].
            batch_num: an integer indicating how many batch of data are used
                for calibration.
            activation_offset: a bool indicating whether there's offset or not
                in quantize activation.
            config_defination: a string, the simple config file path,
                containing the simple quant config according to proto.
        Returns: None
        """
        is_valid_name(config_file, 'config_file')
        GraphChecker.check_quant_behaviours(graph)

        if skip_modules is None:
            skip_modules = []
        if config_defination is not None:
            if len(skip_modules) != 0:
                LOGGER.logw(
                    "When setting 'config_defination' param of "
                    "'create_quant_config' API, 'skip_modules' need to be set "
                    "in simple quant config file!",
                    module_name="Configuration")
            CONFIGURER.create_config_from_proto(config_file, graph,
                                                config_defination)
        else:
            CONFIGURER.create_quant_config(config_file, graph, skip_modules,
                                           batch_num, activation_offset)

    @staticmethod
    def add_global_to_layer(quant_config):
        """add global quantize parameter to each layer"""
        CONFIGURER.add_global_to_layer(quant_config)

        LOGGER.logd("Add global params to layer's config success!",
                    "Configuration")

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def parse_quant_config(file_name, graph):
        """parse quantize configuration from config json file"""
        quant_config = CONFIGURER.parse_config_file(file_name, graph)
        check_config_quant_enable(quant_config)
        Configuration.add_global_to_layer(quant_config)
        nuq_config = {}

        for item in quant_config:
            if not isinstance(quant_config[item], dict):
                continue
            if item == 'bn_update_config':
                continue
            if item in GraphQuerier.get_support_no_weight_quant_layers(graph):
                continue
            if quant_config[item][WEIGHT_QUANT_PARAMS][
                'wts_algo'] == 'nuq_quantize':
                nuq_config[item] = quant_config[item]
        return quant_config, nuq_config

    @check_params(config_file=str, record_file=str, graph=Graph)
    def init(self, config_file, record_file, graph):
        """
        Function: init the Configuration.
        Inputs:
            config_file: a string, the file containing the quant config.
            record_file: a string, the file containing the scale and offset.
            graph: IR Graph
        Returns: None
        """
        self.__quant_config, self.__nuq_config = self.parse_quant_config(
            os.path.realpath(config_file), graph)
        self.__record_file_path = os.path.realpath(record_file)
        self.__skip_fusion_layers = \
            self.__quant_config.get('skip_fusion_layers')
        self.__initialized = True
        self.__record_file_name_update = False

    def uninit(self):
        '''uninit Configuration Class'''
        self.__skip_fusion_layers = None
        self.__quant_config = None
        self.__initialized = False

    def get_quant_config(self):
        """ get quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config

    def get_record_file_path(self):
        """ get record_file_path. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__record_file_path

    def get_layer_config(self, layer_name):
        """ get one lsyer's quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get(layer_name)

    def get_skip_fusion_layers(self):
        """Get layers that need to skip do fusion"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__skip_fusion_layers

    def get_global_config(self, global_params_name):
        """ get global quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get(global_params_name)

    def get_fusion_switch(self):
        """get global fusion switch state"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get('do_fusion')

    def get_update_bn_switch(self):
        """get global update bn switch state"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get('update_bn')

    def get_bn_update_config(self):
        """get global update bn switch state"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get('bn_update_config')

    def update_record_file(self, update_record_file):
        """Update record file path
        """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        new_record_file_path = os.path.realpath(update_record_file)
        if not Path(new_record_file_path).exists():
            raise RuntimeError('Cannot find new record file:{}'.format(
                new_record_file_path))
        self.__record_file_name_update = True
        self.__record_file_path = new_record_file_path

    def is_record_file_name_update(self):
        """return wether record file name has been updated in Configuration"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__record_file_name_update

    def update_quant_config(self, quant_config):
        """Update member quant_config to new input quant_config"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        self.__quant_config = quant_config

    def quant_enable(self, node_name):
        return self.get_layer_config(node_name).get(QUANT_ENABLE)
